<?php
/**
 * The animations page
 */
?>



<?php get_header('amp'); ?>


<hr>

  <div class="container">
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
      <?php the_content(); ?>
    <?php endwhile; endif; ?>
  </div>  <!-- container end -->

  <h1>hello1</h1>
  <h2>hello2</h2>
  <h3>hello3</h3>
  <h4>hello4</h4>
  <h5>hello5</h5>
  <h6>hellow6</h6>
  <p>hello</p>
  laksdjfkalsdkfjalsdkf

<ul>
  <li>hello1</li>
  <li>hello1</li>
  <li>hello1</li>
</ul>

  <div class="clearfix lg-pt-8">
    <div class="col-11 sm-col-10 md-col-12 lg-col-12 mx-auto container">
      <div class="col-12 md-col-6 lg-col-6 col">
        <div class="border">Column Left test</div>
      </div> <!-- .col-col -->
      <div class="col-12 md-col-6 lg-col-5 sm-col-12 col-right">
        <div class="border">Column Float lg-5 Right</div>
      </div> <!-- .col-col -->
    </div>  <!-- .mx-contain-col -->
  </div>

  <div class="clearfix lg-pt-8">
    <div class="mx-auto">
      <div class="sm-col-12 md-col-6 lg-col-6">
        <div class="border">Column Left test</div>
      </div> <!-- .col-col -->
      <div class="sm-col-12 md-col-6 lg-col-6">
        <div class="border">Column Float lg-5 Right</div>
      </div> <!-- .col-col -->
    </div>  <!-- .mx-contain-col -->
  </div>



<div class="container bg-p8 clearfix">
  <div class="mx-auto">
    <div class="mx-auto col-10 sm-col-10 md-col-right md-col md-col-5 lg-col-4 border">.sm-col.sm-col-6.md-col-5.lg-col-4</div>
    <div class="mx-auto col-12 sm-col-11 md-col md-col-7 lg-col-8 border">.sm-col.sm-col-6.md-col-7.lg-col-8</div>
  </div>
</div>

<div class="container max-width-4 clearfix py-1">
  <div class="mx-auto">
    <div class="mx-auto col-10 sm-col-10 md-col md-col-5 lg-col-5"><div class="px-1">
      <h6 class="tx-p3">Content Tools</h6>
      <h2 class="tx-g4 subhead-l mt-0">Improve fundraising</h2>
      <div class="tx-g3 pb-2">Energize donors, mobilize activists and improve prospecting with policy alerts, petitions, better engagement and more timely political content.</div>
      <a class="btn-p7 btn-md" href="<?php echo get_home_url(); ?>/about/">LEARN MORE &raquo;</a>
    </div> <!-- .card --></div>
    <div class="mx-auto col-12 sm-col-11 md-col md-col-7 lg-col-7 bg-p7 border">    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/fund-a.png" alt="political fundraising content strategy graphic" width="1440" height="960" layout="responsive"></amp-img>
      </div>
  </div>
</div>



  <div class="card-flex">
    <a href="#"><amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/image1.jpg" alt="image description" width="600" height="314" layout="responsive"></amp-img></a>
    <div class="card-body">
      <a href="#"><h4>Card title</h4></a>
      <p>Jamón ibérico con queso manchego.</p>
    </div>  <!-- body end -->
    <div class="card-footer">
      <a href="#">MORE &raquo;</a>
    </div> <!-- footer end -->
  </div>   <!--  col end -->


  <div class="container">
    <div class="clearfix">
      <div class="lg-col lg-col-1 px-1 mt-1">
      </div> <!--  lg-push-1 -->
       <div class="lg-col sm-col-11 md-col-8 lg-col-7 md-mx-auto sm-mx-auto content-content content-post px-1"> <!--  xs, sm, md center -->
      <h1>Page content</h1>
      </div>  <!-- column end -->
    </div> <!-- clearfix end -->
  </div> <!-- container -->

  <section class="wrapper">
    <div class="container">
        <h2>Flex Card Layout</h2>
        <p>Breakpoint-based flex (md, lg) with centered col on smaller devices</p>
        <div class="md-flex justify-between flex-wrap"> <!-- md-flex wrap -->
          <div class="md-px-1 lg-px-1 col-11 sm-col-10 md-col-6 border xs-mx-auto sm-mx-auto">
            <div class="bg-p7">
              Flexbox Card 1
            </div>
          <h1>Hamburger</h1></div>
          <div class="md-px-1 lg-px-1 col-11 sm-col-10 md-col-6 border xs-mx-auto sm-mx-auto">Hot Dog
            <div class="bg-p7">
            Flexbox Card 2
            </div>
        </div>
      </div>
    </div>
  </section> <!-- .wrap  -->

<div class="md-col-12 lg-col-10 mx-auto clearfix"> <!-- flex wrap -->
  <div class="sm-flex flex-wrap justify-center card-shadow"> <!-- flex row -->
    <div class="sm-col md-col-6 lg-col-6 card-flex">
      <a href="#"><amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/image1.jpg" alt="image description" width="600" height="314" layout="responsive"></amp-img></a>
      <div class="card-body">
        <a href="#"><h4>Card title</h4></a>
        <p>Jamón ibérico con queso manchego.</p>
      </div>  <!-- body end -->
      <div class="card-footer">
        <a href="#">MORE &raquo;</a>
      </div> <!-- footer end -->
    </div>   <!--  col end -->

    <div class="sm-col md-col-6 lg-col-5 card-flex">
      <a href="#"><amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/image1.jpg" alt="image description" width="600" height="314" layout="responsive"></amp-img></a>
      <div class="card-body">
        <a href="#"><h4>Card title</h4></a>
        <p> Prosciutto di Parma e parmigiano-reggiano.</p>
      </div>  <!-- body end -->
      <div class="card-footer">
        <a href="#">MORE &raquo;</a>
      </div> <!-- footer end -->
    </div>   <!--  col end -->
  </div>  <!-- row end -->
</div> <!--  wrap end -->


<div class="clearfix lg-pt-8">
  <div class="col-11 sm-col-10 md-col-12 lg-col-12 mx-auto container">
    <div class="border">Centered Column (container-width)</div>
    <div class="col-12 md-col-6 lg-col-6 col">
      <div class="border">Column Left</div>
    </div> <!-- .col-col -->
    <div class="col-12 md-col-6 lg-col-5 col col-right">
      <div class="border">Column Right</div>
    </div> <!-- .col-col -->
  </div>  <!-- .mx-contain-col -->
</div>


<div class="clearfix">
  <div class="col-11 sm-col-10 md-col-11 lg-col-12 mx-auto">
    <div class="border">Centered Column (full-width)</div>
  </div>  <!-- .container-col -->
</div>


<div class="clearfix">
  <div class="col-11 sm-col-10 md-col-12 lg-col-12 mx-auto container">
    <div class="border">Centered Column (container-width)</div>
  </div>  <!-- .container-col -->
</div>


<!-- index content  -->

<div class="clearfix mx-1 ml-md-5 lg-ml-5">  <!-- index row -->
  <div class="col col-12 md-col-4 lg-col-4 card-index">
    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/image1.jpg" alt="image description" width="600" height="314" layout="responsive"></amp-img></div> <!-- col end -->
    <div class="col col-12 md-col-7 lg-col-6">
    <p class="index-cat">The category</p>
     <p class="index-date">The date</p>
     <h4 class="index-title"><a href="">Prosciutto</a></h4>
     <p><?php the_excerpt(); ?>Jamón ibérico con queso manchego. Jamón ibérico con queso manchego.</p>
  </div> <!--  col end -->
</div>  <!-- row end -->

<h1 class="tx-g4">Unamuno</h1>
<h2 class="tx-g4">Valle-Inclán</h2>
<h3 class="tx-g4">Machado</h3>
<h4 class="tx-g4">Baroja</h4>
<h5 class="tx-g4">Azorín</h5>

<div class="container">
  <div class="md-flex justify-around">
  <div class="sm-col-10 md-col-6 lg-col-5 border mx-auto px-1">LG-4 md-5</div>
  <div class="sm-col-10 md-col-6 lg-col-5 border mx-auto px-1">LG45</div>
</div>

</div>
  <div class="md-flex flex-wrap justify-center">
  <div class="sm-col-12 md-col-6 lg-col-5 border mx-auto">Iberico</div>
  <div class="sm-col-12 md-col-6 lg-col-5 border mx-auto">di Parma</div>
</div>


  <div class="md-flex flex-wrap">
    <div class="sm-col-12 md-col-5 lg-col-4 border mx-auto">Prosciutto</div>
    <div class="sm-col-12 md-col-5 lg-col-4 border mx-auto">Jamon</div>
    <div class="sm-col-12 md-col-5 lg-col-4 border mx-auto">Iberico</div>
    <div class="sm-col-12 md-col-5 lg-col-4 border mx-auto">di Parma</div>
 </div>

<div class="container px-1">
 <div class="sm-flex flex-wrap">
   <div class="sm-col-5 md-col-5 lg-col-5 border mx-auto">Prosciutto</div>
   <div class="sm-col-5 md-col-5 lg-col-5 border mx-auto">Jamon</div>
   <div class="sm-col-12 md-col-5 lg-col-4 border mx-auto">Iberico</div>
   <div class="sm-col-12 md-col-5 lg-col-4 border mx-auto">di Parma</div>
</div>

</div>





 <div class="border">  <!-- centered columns -->
   <div class="md-col-8 lg-col-6 mx-auto">
     <div class="border">Centered Column 6</div>
   </div>
   <div class="md-col-9 lg-col-7 mx-auto">
     <div class="border">Centered Column 7</div>
   </div>
   <div class="md-col-10 lg-col-8 mx-auto">
     <div class="border">Centered Column 8</div>
   </div>
   <div class="md-col-10 lg-col-9 mx-auto">
     <div class="border">Centered Column 9</div>
   </div>
 </div>


<hr>




<!-- hack-col START -->
    <div class="clearfix border lg-pt-8">
      <div class="mx-auto container">
        <div class="col-12 md-col-6 lg-col-6 col bg-w3">
          <div class="xs-mx-6 sm-mx-8 bg-w2">
          <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/privacy-dash.png" alt="privacy square" width="1800" height="1400" layout="responsive"></amp-img>
          </div> <!-- .sub -->
         </div> <!-- .col-col -->
        <div class="col-12 sm-col-12 md-col-6 lg-col-6 col">
         <div class="xs-mx-2 sm-mx-6">
           <div class="px-1 py-1 lg-pl-2">
            <h6 class="tx-g6">SIMPLE TOOLS</h6>
            <h2 class="tx-h1 tx-g7 sub-head-l">Increase <strong>fundraising</strong></h2>
            <div class="tx-g7 mt-0">Fast, flexible, audience-focused tools—designed exclusively for political advocacy groups. vocacy groups.</div>
              <ul>
                <li><h5 class="mt-0">Client-controlled</h5></li>
                <li><h5 class="mt-0">Flexible, customizable fields</h5></li>
                <li><h5 class="mt-0">No orientation required</h5></li>
              </ul>
              <a class="btn-p7 pt-1" role="button" href="<?php echo get_home_url(); ?>/about/">LEARN MORE &raquo;</a>
            </div>
          </div>  <!-- .sub -->
        </div> <!-- .col-col -->
      </div>  <!-- .mx-col -->
    </div> <!-- .clearfix -->
<!-- .hack-col END -->

<!-- clean-col START -->
  <div class="clearfix border lg-pt-8">
    <div class="col-11 sm-col-10 md-col-12 lg-col-12 mx-auto container">
      <div class="col col-12 md-col-6 lg-col-6">
        <div class="border">
          <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/privacy-dash.png" alt="privacy square" width="1800" height="1400" layout="responsive"></amp-img>
          </div> <!-- .sub -->
        </div> <!-- .col-col -->
        <div class="col col-12 md-col-6 lg-col-6 col-right">
          <div class="border px-1">
            <h6 class="tx-p3">SIMPLE TOOLS</h6>
            <h2 class="tx-h1 tx-g7 sub-head-l">Increase <strong>fundraising</strong></h2>
            <div class="tx-g7">Fast, flexible, audience-focused tools—designed exclusively for political advocacy groups.</div>
            <ul class="list-unstyled tx-g7">
              <li><h5 class="mt-0">Client-controlled</h5></li>
              <li><h5 class="mt-0">Flexible, customizable fields</h5></li>
              <li><h5 class="mt-0">No orientation required</h5></li>
                <li><i class="material-icons md-18 tx-g1 mb-1">check</i><span class="align-top ml-05"> Flexible, customizable fields</span></li>
                <li><i class="material-icons md-18 tx-g1 mb-1">done</i><span class="align-top ml-05"> No orientation required</span></li>
                  <li><i class="material-icons md-18 tx-g1 mb-1">done</i><span class="align-top ml-05"> Client-controlled</span></li>
            </ul>
            <a class="btn-p7 pt-1" role="button" href="<?php echo get_home_url(); ?>/about/">LEARN MORE &raquo;</a>
          </div> <!-- .sub -->
        </div> <!-- .col-col -->
      </div>  <!-- .mx-col -->
    </div> <!-- .clearfix -->
    <!-- .clean-col END -->



  <div class="clearfix lg-pt-8 pb-4 mb-4">
    <div class="pb-4">
      <h1>test</h1>
      <h1>test</h1>
    </div>
  </div>


<hr>

<h2>Icons and Tables</h2>
<i class="material-icons md-36">cloud</i> <span class="align-bottom">Vote recommendation</span>
Vote recommendation
<i class="material-icons md-24">cloud</i>
<i class="material-icons md-20">cloud</i>
<i class="material-icons md-48">cloud</i>

    <table>
    <thead>
    <tr>
    <th>Head 1</th>
    <th>Head 2</th>
    <th>Head 3</th>
    </tr>
    </thead>
    <tfoot>
    <tr>
    <th>Footer 1</th>
    <th>Footer 2</th>
    <th>Footer 3</th>
    </tr>
    </tfoot>
    <tbody>
    <tr>
    <td>Description 1</td>
    <td>Description 2</td>
    <td>Description 3</td>
    </tr>
    <tr>
    <td>Description 1</td>
    <td>Description 2</td>
    <td>Description 3</td>
    </tr>
    <tr>
    <td>Description 1</td>
    <td>Description 2</td>
    <td>Description 3</td>
    </tr>
    </tbody>
    </table>
  <hr>

  <!-- .icons and table -->



       <div class="clearfix border mx-1">  <!-- media object start -->
         <div class="left pt-1 border"><amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/300/icon-cubes-300.svg" width="100" height="100" alt="state election icon"></amp-img></div>
         <div class="ml-2">
           <h3>Hello</h3>
           <p>Jamón ibérico con queso manchego. Jamón ibérico con queso manchego.</p>
         </div>
       </div>




<div class="clearfix pt-2">
  <div class="lg-col-7 md-col-8 mx-auto">
<?php get_search_form(); ?>
  </div>
</div>



<?php get_footer(); ?>
