<?php
/**
 * The sitemap
 */
?>


  <?php echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"; ?>

  <urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9'>

    <url>

      <loc>https://three-anchor.com/</loc>

      <lastmod>2020-03-05</lastmod>

    </url>

    <url>

      <loc>https://three-anchor.com/about/</loc>

        <lastmod>2020-03-05</lastmod>

    </url>

    <url>

      <loc>https://three-anchor.com/about/faq/</loc>

          <lastmod>2020-03-05</lastmod>

    </url>

    <url>

      <loc>https://three-anchor.com/about/contact/</loc>

          <lastmod>2020-02-05</lastmod>

    </url>

    <url>

      <loc>https://three-anchor.com/news/</loc>

      <lastmod>2020-01-07</lastmod>

    </url>

    <url>

      <loc>https://three-anchor.com/news/what-is-google-amp/</loc>

         <lastmod>2020-02-05</lastmod>

    </url>

    <url>

      <loc>https://three-anchor.com/news/amp-history-case-studies-facts/</loc>

        <lastmod>2020-02-05</lastmod>

    </url>


    <url>

      <loc>https://three-anchor.com/news/threeanchor-amp-political-website-us/</loc>

      <lastmod>2020-02-05</lastmod>

    </url>
    <url>

      <loc>https://three-anchor.com/news/google-english-language-referee/</loc>

      <lastmod>2019-12-11</lastmod>

    </url>
    <url>

      <loc>https://three-anchor.com/news/landing-page-case-study-trump-vs-clinton/</loc>

      <lastmod>2020-02-05</lastmod>

    </url>
    <url>

      <loc>https://three-anchor.com/profile/jack-sisson/</loc>

      <lastmod>2020-03-05</lastmod>

    </url>

  </urlset>
