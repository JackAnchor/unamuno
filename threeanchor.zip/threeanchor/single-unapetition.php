<?php
/**
 * The default template for petition posts
 *
 * Petition content  - Body content and excerpt "tease"
 *
 * Sidebar 4 - Static headline and form widget
 */
?>
<?php get_header( 'amp'); ?>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

    <main id="post-<?php the_ID(); ?>" <?php post_class(); ?>>


      <div class="peti-h">
          <div class="peti-i">
            <amp-img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title_attribute(); ?>" height="628" width="1200" layout="responsive" class="peti-fil"></amp-img>
          </div>

          <header class="absolute-hw peti-hh">
            <div class="container full-h">
              <div class="hero-flex-peti col-12 sm-col-9 md-col-6 lg-col-7 sm-mx-auto xs-mx-auto full-h">
                <div class="peti-hhw">
                  <?php the_title( '<h1 class="title">', ' </h1>' ); ?>

              </div>
             </div>
            </div>
        </header>
      </div>  <!-- .peti-h -->


    <?php get_template_part( 'templates/content', 'petition' );  ?>


  </main>
<?php endwhile; endif; ?>
  <?php get_footer(); ?>
