<?php
/**
 * Two button widget
 *
 * php if ( !is_singular( 'unaprofile' )) {
 *	 ?>
 *	<a class="btn-outline btn-lg mb-1" href="<?php echo get_home_url(); ?>/profile/jack-sisson/">CEO PROFILE &raquo;</a>
 *
 * php } ?>
 */
?>
<?php	if ( ! is_active_sidebar( 'sidebar-2' ) ) {
		return;
	}
	?>
	<aside id="cta-2">
	  <div class="texture2">
	    <div class="container">
	      <div class="col-12 sm-col-11 md-col-8 lg-col-7 mx-auto">
	        <div class="cta-h flex flex-wrap content-center px-w">
						<?php dynamic_sidebar('sidebar-2'); ?>
						<a class="btn-p5 btn-lg block mr-1" href="<?php echo get_home_url(); ?>/about/faq/">DETAILS &amp; FAQ &raquo;</a>
					</div>
  			</div>
	 		</div>
 		</div>
</aside>
