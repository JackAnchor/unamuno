<?php
/**
 * The front page
 *
 *  Hero: z6, bg-w4, bg-cut-r, hm-texture (hero-texture)
 *  Hero Card: z7, z8 (.lg-z)
 *  Message: z5, bg-cut-l, bg-p9
 *  Targeted: z4, bg-p9
 *  Tools:
 *  Updates:
 *  Section (neg margin, bg,  ) --> then "update" with bg, then container
 */
?>
<?php get_header( 'amp' ); ?>

<!-- Home Hero
–––––––––––––––––––––––––––––––––––––––––––––––––– -->
<main id="post-<?php the_ID(); ?>" class="frontpage">

<div class="hh bg-w3">
  <div class="top-0 left-0 right-0">
    <div class="hm-img">
      <div class="hm-geo pt-1">
       <div class="container-xl">
        <div class="clearfix pt-4">
          <div class="col-12 sm-col-12 md-col-12 lg-col-8 mx-auto lg-col-right lg-pl-4">
            <div class="hhi">
              <amp-img media="(min-width: 40em)" src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/screens-lg.png" alt="responsive political website" class="mx-auto" width="1960" height="1600" layout="responsive" sizes="(max-width: 54em) 75vw, (max-width: 75em) 70vw, (max-width: 81em) 61vw, (max-width: 89em) 54vw, 845px"></amp-img>
              <amp-img
              media="(max-width: 39.99em)"
              src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/screens-sm.png" alt="political website interface" width="1960" height="1600" layout="responsive" sizes="(max-width: 35em) 118vw, 117vw"></amp-img>
             </div>
           </div>
          </div>
        </div>
      </div> <!-- .geo -->
    </div>
  </div>
</div> <!-- .hh -->

  <div class="container-xl">
    <div class="sm-col sm-col-10 md-col-8 lg-col-7">
      <div class="hhc">
          <h2>Political advocacy website &amp; platform</h2>
          <div class="mt-05">Communicate, connect and grow with a website solution designed exclusively for political organizations.</div>
          <a class="btn-p5 btn-md mt-2" role="button" href="<?php echo get_home_url(); ?>/about/">LEARN MORE &raquo;</a>
      </div>
    </div>
  </div>   <!-- .hero-down -->

  <section class="message-mt bg-cut-ly">  <!-- .message  -->
    <div class="message bg-p9">
      <div class="container">
        <div class="lg-col-10 lg-px-1 mx-auto">
        <div class="clearfix pb-4">
          <div class="mx-auto col-11 sm-col-8 md-col-right md-col md-col-6 lg-col-7"> <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/fund.svg" alt="political fundraising content strategy graphic" width="1440" height="960" layout="responsive"></amp-img>
          </div>
          <div class="mx-auto col-11 sm-col-10 md-col md-col-5 lg-col-5 md-col-right lg-pt-1">
            <div class="pt-1 lg-pt-4">
            <h6 class="tx-p3">Content Tools</h6>
            <h2 class="tx-g4 subhead-l">Improve fundraising</h2>
            <div class="pb-2">Energize donors and mobilize activists with policy alerts, petitions and mobile-focused political content.</div>
            <a class="btn-p7 btn-md" href="<?php echo get_home_url(); ?>/about/">LEARN MORE &raquo;</a>
          </div> <!-- .card -->
        </div>
      </div>


      <div class="clearfix pb-4 lg-pt-3">
        <div class="mx-auto col-11 sm-col-8 md-col md-col-6 lg-col-7">
          <div class="xs-px-1 sm-px-1 md-px-1 lg-pr-4">
            <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/fast.svg" alt="political content management system" width="1440" height="960" layout="responsive"></amp-img>
        </div>
        </div>
        <div class="mx-auto col-11 sm-col-10 md-col md-col-5 lg-col-5">
          <div class="pt-1 lg-pt-4">
          <h6 class="tx-p3">Publishing Tools</h6>
          <h2 class="tx-g4 subhead-l">Save time</h2>
          <div class="pb-2">Increase productivity and minimize waste with flexible tools and built-in political publishing templates.</div>
          <a class="btn-p7 btn-md" href="<?php echo get_home_url(); ?>/about/">LEARN MORE &raquo;</a>
        </div> <!-- .card -->
      </div>
      </div>  <!-- .publish -->


        <div class="clearfix pb-1 lg-pt-4">
          <div class="mx-auto col-11 sm-col-8 md-col-right md-col md-col-6 lg-col-7"> <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/find.svg" alt="political seo graphic" width="1440" height="960" layout="responsive"></amp-img>
          </div>
          <div class="mx-auto col-11 sm-col-10 md-col md-col-5 lg-col-5 md-col-right"><div class="pt-1 lg-pt-4">
            <h6 class="tx-p3">Political SEO</h6>
            <h2 class="tx-g4 subhead-l">Get found</h2>
            <div class="pb-2">Maximize your visibility on Google with search engine optimization tools for politics.</div>
            <a class="btn-p7 btn-md" href="<?php echo get_home_url(); ?>/about/">LEARN MORE &raquo;</a>
          </div> <!-- .card -->
        </div>
      </div>
    </div> <!-- .mx -->
  </div> <!-- .cont -->
</div> <!-- .mess -->
</section>



  <!-- Targeted
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <section class="bg-cut-xi relative z8 mt-n12 bg-pg">
    <div class="targeted">
      <div class="container">
        <div class="col-12 sm-col-11 md-col-10 lg-col-9 mx-auto lg-pt-4">
          <div class="clearfix">
            <div class="px-w lg-pt-2">
              <div class="sm-flex md-flex lg-flex flex-wrap items-center overflow-hidden">
                <div class="sm-col-9 md-col-9">
                  <h6 class="tx-p3">Simple Tools</h6>
                  <h2 class="tx-g4 sm-tx-l tx-h1 subhead-l">Communicate smarter</h2>
                </div>
                <div class="sm-col-3 md-col-3 xs-hide"><a class="right btn-p7 btn-md" href="<?php echo get_home_url(); ?>/about/">GET DETAILS &raquo;</a>
                </div>
              </div>
              <div class="tx-g3 pb-4 lead lg-col-9">From policy updates to grassroots petitions, create smart, simple content in minutes.
              </div>
            </div>
          </div>
        </div>
      </div>  <!-- .container -->

      <div class="container">
        <div class="sm-flex flex-wrap">
          <div class="col-12 sm-col-11 md-col-11 lg-col-11 mx-auto">
            <div class="tar-tw lg-pb-1">
            <div class="tar-t tbl-shadow">
              <div class="header">
                <div class="flex">
                  <div class="left pl-1 col col-6 sm-col-6 md-col-6 lg-col-6">
                    <h4 class="">TOOL</h4>
                  </div> <!-- .left -->
                  <div class="col col-6 sm-col-6 md-col-6 lg-col-6">
                    <h4 class="pl-1">TARGET</h4>
                  </div> <!-- .right -->
                </div>  <!-- .flex -->
              </div>  <!-- .head -->
              <div class="flex plank">
                <div class="col col-6 sm-col-6 md-col-6 lg-col-6 pen">
                  <div class="clearfix">
                    <div class="left"><?php get_template_part( 'img/svg/blowhorn'); ?></div>
                    <div class="overflow-hidden">
                      <h5 class="ellipsis">Petition Alert</h5>
                    </div>
                  </div>
                </div>  <!-- .col -->
                <div class="col col-5 sm-col-5 md-col-5 lg-col-5 pen">
                  <h5 class="italic">Mobilize <span class="strong">Grassroots</span></h5>
                </div> <!-- .col -->
                <div class="col col-1 sm-col-1 md-col-1 lg-col-1 pop">
                  <div class="tx-c">
                    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/li-check-outline.svg" width="23" height="23" alt="checkbox"></amp-img>
                  </div>
                </div> <!-- .pop -->
              </div>  <!-- .plank -->

              <div class="flex plank">
                <div class="col col-6 sm-col-6 md-col-6 lg-col-6 pen">
                  <div class="clearfix">
                    <div class="left"><?php get_template_part( 'img/svg/alarm'); ?></div>
                    <div class="overflow-hidden">
                      <h5 class="ellipsis">Policy Update</h5>
                    </div>
                  </div>
                </div>  <!-- .col -->
                <div class="col col-5 sm-col-5 md-col-5 lg-col-5 pen">
                  <h5 class="italic">Engage <span class="strong">Donors</span></h5>
                </div> <!-- .col -->
                <div class="col col-1 sm-col-1 md-col-1 lg-col-1 pop">
                  <div class="tx-c">
                    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/li-check-outline.svg" width="23" height="23" alt="checkbox"></amp-img>
                  </div>
                </div> <!-- .i1 -->
              </div>  <!-- .plank -->
              <div class="flex plank">
                <div class="col col-6 sm-col-6 md-col-6 lg-col-6 pen">
                  <div class="clearfix">
                    <div class="left"><?php get_template_part( 'img/svg/news'); ?></div>
                    <div class="overflow-hidden">
                      <h5 class="ellipsis">Press Release</h5>
                    </div>
                  </div>
                </div>  <!-- .col -->
                <div class="col col-5 sm-col-5 md-col-5 lg-col-5 pen">
                  <h5 class="italic">Inform <span class="strong">Media</span></h5>
                </div> <!-- .i1 -->
                <div class="col col-1 sm-col-1 md-col-1 lg-col-1 pop">
                  <div class="tx-c">
                    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/li-check-outline.svg" width="23" height="23" alt="checkbox"></amp-img>
                  </div>
                </div> <!-- .i1 -->
              </div>  <!-- .plank -->
              <div class="flex plank">
                <div class="col col-6 sm-col-6 md-col-6 lg-col-6 pen">
                  <div class="clearfix">
                    <div class="left"><?php get_template_part( 'img/svg/profile'); ?></div>
                    <div class="overflow-hidden">
                      <h5 class="ellipsis">Staff Profile</h5>
                    </div>
                  </div>
                </div>  <!-- .col -->
                <div class="col col-5 sm-col-5 md-col-5 lg-col-5 pen">
                  <h5 class="italic">Educate <span class="strong">Public</span></h5>
                </div> <!-- .i1 -->
                <div class="col col-1 sm-col-1 md-col-1 lg-col-1 pop">
                  <div class="tx-c">
                    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/li-check-outline.svg" width="23" height="23" alt="checkbox"></amp-img>
                  </div>
                </div> <!-- .i1 -->
              </div>  <!-- .plank -->
              <div class="flex plank">
                <div class="col col-6 sm-col-6 md-col-6 lg-col-6 pen pen-l">
                  <div class="clearfix">
                    <div class="left"><?php get_template_part( 'img/svg/policy'); ?></div>
                    <div class="overflow-hidden">
                    <h5 class="ellipsis">Vote Recommendation</h5>
                    </div>
                  </div>
                </div>  <!-- .col -->
                <div class="col col-5 sm-col-5 md-col-5 lg-col-5 pen pen-l">
                  <h5 class="italic">Influence <span class="strong">Legislators</span></h5>
                </div> <!-- .col -->
                <div class="col col-1 sm-col-1 md-col-1 lg-col-1 pop pop-l">
                  <div class="tx-c">
                    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/li-check-outline.svg" width="23" height="23" alt="checkbox"></amp-img>
                  </div>
                </div> <!-- .i1 -->
              </div>  <!-- .plank -->
            </div>  <!-- .tar-t  -->

                <div class="clearfix mt-05 pt-1 lg-pb-4">
                  <div class="right pr-05 sm-pr-1 md-pr-1 lg-pr-2">
                    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/line-built.svg" width="81" height="43" alt="arrow right up"></amp-img>
                  </div>
                  <div class="overflow-hidden right pr-05 lg-pr-1">
                    <h6 class="tx-p1 pr-1 pt-2">Built-In</h6>
                  </div>
                </div> <!-- .object  -->
              </div> <!-- .wr  -->
            </div> <!-- .row  -->
          </div> <!-- .col-1  -->
        </div> <!-- .fx-wrap  -->
    </div>
  </section>

<section class="mt-n12 bg-p8gb">
  <div class="built">
    <div class="px-w container clearfix">
      <div class="col-12 sm-col-11 md-col-10 lg-col-9 mx-auto lg-pt-4 pb-1">
        <h6 class="tx-p3 pt-3">FOCUS</h6>
        <h2 class="sm-tx-l tx-g3 tx-h1 subhead-l subhead-l2">Built for politics</h2>
        <div class="lead tx-g2 sm-tx-l pb-2 lg-col-10">A turkey solution — designed for political teams and professionals on the move.</div>
      </div>
    </div>

    <div class="texture2">
      <div class="container">
        <div class="clearfix">
          <div class="mx-auto col-12 md-col-right md-col md-col-6 lg-col-5 sm-b-b">
            <div class="col-7 sm-col-5 md-col-9 lg-col-10 mx-auto">
              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/cta6.png" alt="threeanchor mobile navigation screenshot mockup" width="1330" height="1680" layout="responsive" sizes="(max-width: 54em) 300px, (max-width: 70em) 340px, 400px"></amp-img>
            </div>
          </div>
          <div class="mx-auto col-12 md-col md-col-6 lg-col-6">
            <div class="col-12 sm-col-9 md-col-12 mx-auto lg-pt-4 md-pt-3">
              <div class="card lg-pt-4">
                  <div class="clearfix">
                    <div class="left mr-15">
                      <i class="material-icons md-18">check</i>
                    </div>
                    <div class="overflow-hidden">
                      <h5>Flexible</h5>
                      <span>Customizable fields &amp; options</span>
                    </div>
                  </div> <!-- .ico-fx  -->
                  <div class="clearfix pt-2 lg-pt-2">
                    <div class="left mr-15">
                      <i class="material-icons md-18">check</i>
                    </div>
                    <div class="overflow-hidden">
                      <h5>Focused</h5>
                      <span>Designed for politics</span>
                    </div>
                  </div> <!-- .ico-fx  -->

                  <div class="clearfix pt-2 lg-pt-2">
                    <div class="left mr-15">
                      <i class="material-icons md-18">check</i>
                    </div>
                    <div class="overflow-hidden">
                      <h5>Easy-to-Use</h5>
                      <span>No orientation required</span>
                    </div>
                  </div> <!-- .ico-fx  -->
              </div> <!-- .card -->
            </div> <!-- .nested -->
          </div> <!-- .col -->
        </div>
      </div> <!-- .con -->
    </div>
  </div>
</section>

<aside id="cta-1">
  <div class="texture2">
    <div class="container">
      <div class="col-12 sm-col-11 md-col-9 lg-col-7 mx-auto">
        <div class="cta-h flex flex-wrap content-center px-w">
            <h2 class="title">Ready to start?</h2>
            <p class="lead">Find answers and discover whether our political website process is right for you.</p>
            <a class="btn-p5 btn-lg btn-block" href="<?php echo get_home_url(); ?>/about/">OUR PROCESS &raquo;</a>
        </div>
      </div>
    </div>
  </div>
</aside>
</main>
<?php get_footer(); ?>
