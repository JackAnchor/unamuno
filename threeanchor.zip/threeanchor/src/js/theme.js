// Toggle navigation
  jQuery(document).ready(function($) {

    // .toggle-overlay class exists in button (to open) & div (to close)
     $('.toggle-overlay').click(function() {

    // Expose .open class to nav
      $('nav').toggleClass('open');
    });
  });
