jQuery(document).ready(function($) {
       $("#trigger").click(function() {
           $("#demotrigger").html("Hello, World!");
       });
      });

jQuery(document).ready(function($) {
      $("#buttontrigger").click(function() {
            $("#jackModal").modal("show")
             });
            });

            jQuery(document).ready(function($) {
              $(".accordion").on("click", ".accordion-header", function() {
              $(this).toggleClass("active").next().slideToggle();
                });
               });
