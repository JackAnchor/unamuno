jQuery(document).ready(function($) {
       $("#trigger").click(function() {
           $("#demotrigger").html("Hello, World!");
       });
      });

  jQuery(document).ready(function($) {
    $(".accordion").on("click", ".accordion-header", function() {
    $(this).toggleClass("active").next().slideToggle();
      });
     });

 jQuery(document).ready(function($) {
   $(".open").on("click", function() {
  $(".overlay, .modal").addClass("active").html("Hello, GWorld!");
});
    });


    <nav class="navbar navbar-light bg-light  justify-content-between">
     <div class="container">
       <a class="navbar-brand" href="https://www.threeanchorgroup.com/">
     <img src="/wordpress/wp-content/themes/threeanchor/images/logos/anchor-text.svg" width="150" height="32" class="d-inline-block align-top" alt="three anchor group">
    </a>

       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
       </button>

       <div class="collapse navbar-collapse" id="navbarNav">
           <ul class="navbar-nav mr-auto">
             <li class="nav-item">
               <a class="nav-link" href="https://www.threeanchorgroup.com/about/contact/">Contact</a>
             </li>
           </ul>
         </div>
       </div>
     </nav>


     <!-- bootstrap alert -->
         <div class="alert alert-warning alert-dismissible fade show" role="alert">
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
           <strong>Holy guacamole!</strong> You should check in on some of those fields below.
         </div>

         <!-- bootstrap alert end -->



  <div class="container"><!-- jquery container -->
 <div class="row justify-content-center">
<div class="col-lg-7 push-lg-3">


 <!-- Button trigger modal -->
<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal">
Launch demo modal
</button>

<!-- modal -->
<div class="modal fade" id="exampleModal" tabindex="1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog" role="document">
   <div class="modal-content bg-light">
     <div class="modal-header bg-primary">
       <h4 class="modal-title text-white" id="exampleModalLabel">Insights &amp; anecdotes—never spam.</h4>
     </div>
<!-- gravity form short code -->
     <div class="modal-body">
 <?php echo do_shortcode('[gravityform id=3 title=false description=false]'); ?>
   <button type="button" class="close" data-dismiss="modal" aria-label="Close">
   <span aria-hidden="true">&times;</span>
   </button>
  </div>
  </div>
 </div>
 </div>

 </div>
</div>
</div> <!-- end jquery container -->
