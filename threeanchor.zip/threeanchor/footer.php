<?php
/**
 * The primary footer template
 */
?>
  <footer id="footer" class="footer-p">
     <div class="container mx-auto footer-pw">
       <div class="md-flex lg-flex flex-wrap">
         <div class="col-12 sm-col-12 md-col-6 lg-col-5">
            <a class="logo" href="<?php echo get_home_url(); ?>"><?php get_template_part( 'img/logos/logo-footer'); ?></a>
             <?php get_template_part( 'templates/components/social-contactphone' ); ?>
           </div>
         <div class="col-12 sm-col-12 md-col-6 lg-col-3 ml-auto xs-mx-auto sm-mx-auto">
            <h4>INFORMATION</h4>
           <?php wp_nav_menu( array(
             'menu_class' => 'list-reset menu-r',
             'theme_location' => 'right-menu',
             'container' => '',
             'menu_id' => 'menu-right'
           ) ); ?>
         </div>  <!-- .col2 -->
       </div> <!-- .fx-row -->
     </div> <!-- .footer-pw -->
      <div class="footer-b">
          <div class="footer-bw">
            <div class="container">
              <?php get_template_part( 'templates/components/social-follow' ); ?>
              <h6 class="copyright">Copyright &copy; 2020 — <?php bloginfo( 'name' ); ?></h6>
          </div>
          </div>
        </div> <!-- .footer-b  -->
      </footer> <!-- .footer-p  -->
      <?php wp_footer(); ?>
    </body>
</html>
