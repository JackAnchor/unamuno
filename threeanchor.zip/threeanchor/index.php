<?php
/**
 * Primary index page loop, functions as default.
 *
 * card-index:
 */
?>

<?php get_header('amp'); ?>

    <main id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <header class="container">
          <div class="lg-pt-1">
            <h1 class="pg-title"><?php wp_title(''); ?></h1>
          </div>  <!-- column end -->
        </header>

      <?php if (have_posts()) : ?>

        <section class="overflow-hidden entry"> <!-- bg -->
         <div class="container clearfix py-w px-w"> <!-- fx-con -->
           <div class="md-flex lg-flex flex-wrap card-shadow justify-between"> <!-- row -->
           <?php
           	// Start the loop
            while (have_posts()) : the_post(); ?>

             <?php get_template_part( 'templates/content', 'news' ); ?>

           <?php endwhile; ?>

           </div>  <!-- flex row end -->
         </div> <!--  flex container end-->


         <?php
          // Get pagination -->
          // get_template_part( 'templates/pagination' );
         ?>

      <?php else : ?>

         <?php get_template_part( 'templates/content', 'none' ); ?>

     <?php endif; ?>

   </section>   <!-- bg -->
 </main>

      <?php get_sidebar( '1' ); ?>

  <?php get_footer(); ?>
