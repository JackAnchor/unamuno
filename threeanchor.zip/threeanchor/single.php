<?php
/*
 * The default template for posts.
 * Enable comments with
 * <?php if ( comments_open() || get_comments_number() ) :
 * comments_template(); endif; ?>
 */
?>

<?php get_header( 'amp'); ?>

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

      <?php get_template_part( 'templates/content', 'single' ); ?>

    <?php endwhile; endif; ?>

     <?php if ( is_single( 'What is Google AMP?' )) : ?>

       <?php get_sidebar( '1' ); ?>

     <?php else : ?>

          <?php get_sidebar( '3' ); ?>

      <?php endif; ?>

<?php get_footer(); ?>
