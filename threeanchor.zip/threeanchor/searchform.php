<?php
/**
 * Template for displaying the search form
 *
 * Full-width container recommended
 * 'AMP form' component required
 * Change to: action="<?php echo esc_url( home_url( '/' ) ); ?>">
 * @version 1.0
 */

?>

<div class="pb-2">

    <form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>"   target="_top">       <!-- form method -->

      <input type="search" class="search-in mt-1" value="<?php echo get_search_query(); ?>" name="s">  <!-- input field, type, text, placeholders -->

      <input type="submit" class="btn-search mt-1" value="<?php echo esc_attr_x( 'Search', 'submit button' ) ?>" />

    </form>
</div>
