<?php
/**
 * One button widget
 *
 */
?>

<aside id="cta-3">
	<div class="container">
		<div class="col-12 sm-col-11 md-col-9 lg-col-7 mx-auto">
		 <div class="cta-h flex flex-wrap content-center px-w">
			 <?php dynamic_sidebar('sidebar-3'); ?>
			 <a href="<?php echo get_home_url(); ?>/news/what-is-google-amp/" class="btn-p5 btn-lg mr-05">Learn More &raquo;</a>
		 </div>
		</div>
		</div>
	</aside>

<?php
/**
 * Two-button widget
 *
 * Original portfolio preview button with icon
 * <button class="btn-p7 sm-btn-block mb-1" on="tap:lightbox1" role="button" tabindex="0"> PREVIEW WORK <i class="material-icons md-12 tx-g2">open_in_new</i></button>
* <aside id="cta-2">
* 	<div class="container">
* 		<div class="clearfix">
 *			<div class="col-12 sm-col-10 md-col-8 lg-col-7 mx-auto">
 *			<?php dynamic_sidebar('sidebar-2'); ?>
 *			 <a class="btn-p7 sm-btn-block mb-1 mr-1" href="<?php echo get_home_url(); ?>/about/contact/">GET PROPOSAL &raquo;</a>
 *				<a class="btn-white sm-btn-block mb-1" href="<?php echo get_home_url(); ?>/about/faq/">EXPLORE FAQ &raquo;</a>
 *			</div>
*   	</div>
*	</div>
* </aside>
 *
 */
?>
