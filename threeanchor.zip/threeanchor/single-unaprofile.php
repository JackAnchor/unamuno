<?php
/*
 * The default template for profile posts
 * Flex-start = top-alingment
 if (!empty($meta['text'])) {
  echo esc_attr($meta['text']);
 } else {
  echo " ";
 }
}
echo "<body class=\"page_bg\">";
 */
?>

<?php get_header( 'amp' ); ?>

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

      <?php $meta = get_post_meta( $post->ID, 'unaprofile_fields', true ); ?>

  <main id="post-<?php the_ID(); ?>">
    <header class="profile-h">
      <div class="bg-pg bg-cut-r">
      <div class="profile-h-bg">
        <div class="hero-box">
         <div class="container">
           <div class="col-12 sm-col-11 md-col-10 lg-col-8 mx-auto pl-1 pr-1">
              <div class="sm-flex md-flex lg-flex content-center">
                <div><amp-img src="<?php the_post_thumbnail_url(); ?>" title="<?php the_title_attribute(); ?>" class="profile-img xs-mx-auto sm-mx-auto" width="105" height="105" sizes="(max-width: 39.99em) 45vw, (max-width: 52em) 26vw, (max-width: 64em) 23vw, 260px"></amp-img></div>

                    <div class="self-center sm-pl-2 md-pl-2 lg-pl-3">
                      <div class="xs-flex justify-center">
                        <div>
                          <?php the_title( '<h1 class="title">', '</h1>' ); ?>
                          <?php if (!empty($meta['text'])) {
                            echo '<div class="position">';
                            echo esc_html($meta['text']);
                            echo '</div>';
                          }
                          if (!empty($meta['text2'])) {
                            echo '<a href="https://twitter.com/';
                            echo esc_attr($meta['text2']);
                            echo '"><p class="twitter">@';
                            echo esc_html($meta['text2']);
                            echo '</p></a>';
                          }

                          if (!empty($meta['text3'])) {
                            echo '<p class="linkedin">';
                            echo esc_html($meta['text3']);
                            echo '</p>';
                          } ?>

                        </div>
                        <div>
                        </div> <!-- .xs plug -->
                      </div> <!-- .xs -->
                    </div>
                  </div>


           </div>
         </div>   <!-- .container -->
        </div>
      </div>

        </div>
    </header>

    <?php get_template_part( 'templates/content', 'profile' );  ?>

</main>

  <?php endwhile; endif; wp_reset_postdata(); ?>


        <?php get_sidebar( '2' ); ?>


<?php get_footer(); ?>
