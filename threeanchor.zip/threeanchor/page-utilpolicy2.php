<?php
/**
 * Policy One-Pager
 * https://three-anchor.com/about/faq/utilpolicy2/
 */
?>

<!doctype html>
<html ⚡ lang="en">
<head><meta charset="utf-8">
    <title>Policy One-Pager | ThreeAnchor</title>
    <meta name="robots" content="noindex">
    <link rel="canonical" href="<?php echo get_home_url(); ?>/about/faq/utilpolicy2/">
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
    <meta name="description" content="Accelerate political content creation with fast, flexible publishing templates." />
    <link rel="shortcut icon" href="https://three-anchor.com/wp-content/themes/threeanchor/img/logos/favicon.png" />
  <!-- ThreeAnchor SEO -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:image" content="https://three-anchor.com/wp-content/uploads/2020/03/one-pager-1.png" />
    <meta name="twitter:site" content="https://twitter.com/threeanchor/" />
    <meta property="og:url" content="<?php echo get_home_url(); ?>/about/faq/utilpolicy2/" />
    <meta property="og:title" content="Policy One-Pager" />
    <meta property="og:description" content="Accelerate political content creation with fast, flexible publishing templates." />
    <meta property="og:image" content="https://three-anchor.com/wp-content/uploads/2020/03/one-pager-1.png" />
    <meta property="og:image:width" content="2400" />
    <meta property="og:image:height" content="1256" />
    <meta property="article:published_time" content="2020-02-1713:12" />
    <meta property="fb:app_id" content="444" />
    <meta property="og:site_name" content="ThreeAnchor" />
    <meta property="og:locale" content="en_US" />
    <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "Article",
      "mainEntityOfPage": "https://three-anchor.com/about/faq/utilpolicy2/",
      "headline": "Telephone Robocall Abuse Criminal Enforcement and Deterrence Act",
      "datePublished": "2020-03-10",
      "dateModified": "2020-03-10",
      "description": "Consumer protection bill to prohibit certain telemarketing practices and expand fines, penalties and enforcement tools for unsolicited robocalls and related advertisements.",
      "publisher": {
        "@type": "Organization",
        "name": "ThreeAnchor",
        "logo": {
          "@type": "ImageObject",
          "url": "https://three-anchor.com/amp-logo.png",
          "width": 600,
          "height": 60
          }
      },
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Washington",
        "addressRegion": "DC",
        "postalCode": "20002",
        "streetAddress": "50 Massachusetts Ave NE, #313"
      },
      "sameAs": [
        "facebookurl",
        "https://twitter.com/threeanchor/"
      ]},
      "image": {
        "@type": "ImageObject",
        "url": "https://three-anchor.com/wp-content/uploads/2020/03/one-pager-1.png",
        "height": 1256,
        "width": 2400
      }
    }
    </script>

    <style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
<script async src="https://cdn.ampproject.org/v0.js"></script>
<script async custom-element="amp-analytics" src="https://cdn.ampproject.org/v0/amp-analytics-0.1.js"></script> <!-- analytics --> <script async custom-element="amp-fit-text" src="https://cdn.ampproject.org/v0/amp-fit-text-0.1.js"></script> <!-- fit tx --> <script async custom-element="amp-fx-collection" src="https://cdn.ampproject.org/v0/amp-fx-collection-0.1.js"></script> <!-- parallax title --> <script async custom-element="amp-fx-flying-carpet" src="https://cdn.ampproject.org/v0/amp-fx-flying-carpet-0.1.js"></script> <!-- carpet -->
<script async custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js"></script> <!-- sidebar --> <script async custom-element="amp-accordion" src="https://cdn.ampproject.org/v0/amp-accordion-0.1.js"></script> <!-- accordion drop --> <script async custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.1.js"></script>
<!-- carousel --> <script async custom-element="amp-image-lightbox" src="https://cdn.ampproject.org/v0/amp-image-lightbox-0.1.js"></script> <!-- img lightbox --> <script async custom-element="amp-lightbox" src="https://cdn.ampproject.org/v0/amp-lightbox-0.1.js"></script> <!-- lightbox --> <script async custom-template="amp-mustache" src="https://cdn.ampproject.org/v0/amp-mustache-0.2.js"></script> <!-- mustache -->
<script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script> <!-- form -->
<script async custom-element="amp-youtube" src="https://cdn.ampproject.org/v0/amp-youtube-0.1.js"></script>
<link href="https://fonts.googleapis.com/css?family=Inconsolata|Montserrat:400,500,600,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style amp-custom>.tx-p9{color:#0d47a1}.tx-p8{color:#1565c0}.tx-p7{color:#1976d2}.tx-p6{color:#1e88e5}.tx-p5{color:#2196f3}.tx-p4{color:#42a5f5}.tx-p3{color:#64b5f6}.tx-p2{color:#90caf9}.tx-p1{color:#bbdefb}.tx-p1a{color:#e3f2fd}.tx-g9{color:#212529}.tx-g8{color:#495057}.tx-g7{color:#6c757d}.tx-g6{color:#828a91}.tx-g5{color:#adb5bd}.tx-g55{color:#aaa}.tx-g4{color:#ced4da}.tx-g3{color:#dee2e6}.tx-g2{color:#e9ecef}.tx-g1{color:#f8f9fa}.tx-w8{color:#aaa}.tx-w9{color:#78828a}.tx-danger{color:#dc3545}.tx-success{color:#28a745}html{line-height:1.15;-webkit-text-size-adjust:100%}body{margin:0}main{display:block}h1{font-size:2em;margin:.67em 0}pre{font-family:monospace,monospace;font-size:1em}a{background-color:transparent}abbr[title]{border-bottom:none;text-decoration:underline;-webkit-text-decoration:underline dotted;text-decoration:underline dotted}b,strong{font-weight:bolder}code,kbd,samp{font-family:monospace,monospace;font-size:1em}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}img{border-style:none}button,input,optgroup,select,textarea{font-family:inherit;font-size:100%;line-height:1.15;margin:0}button,input{overflow:visible}button,select{text-transform:none}[type=button],[type=reset],[type=submit],button{-webkit-appearance:button}[type=button]::-moz-focus-inner,[type=reset]::-moz-focus-inner,[type=submit]::-moz-focus-inner,button::-moz-focus-inner{border-style:none;padding:0}[type=button]:-moz-focusring,[type=reset]:-moz-focusring,[type=submit]:-moz-focusring,button:-moz-focusring{outline:1px dotted ButtonText}fieldset{padding:.35em .75em .625em}legend{box-sizing:border-box;color:inherit;display:table;max-width:100%;padding:0;white-space:normal}progress{vertical-align:baseline}textarea{overflow:auto}[type=checkbox],[type=radio]{box-sizing:border-box;padding:0}[type=number]::-webkit-inner-spin-button,[type=number]::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}[type=search]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}details{display:block}summary{display:list-item}[hidden],template{display:none}.border-box{box-sizing:border-box}.tx-l{text-align:left}.tx-c{text-align:center}.tx-r{text-align:right}@media (max-width:51.99em){.sm-tx-c{text-align:center}.sm-tx-l{text-align:left}.sm-tx-r{text-align:right}}@media (max-width:40em){.xs-tx-c{text-align:center}.xs-left{float:left}.xs-right{float:right}}@media (min-width:52em){.md-left{float:left}.md-right{float:right}.md-tx-r{text-align:right}.md-tx-c{text-align:center}}.text-bottom{vertical-align:text-bottom}.align-top{vertical-align:top}.align-middle{vertical-align:middle}.align-bottom{vertical-align:bottom}.border{border-style:solid;border-width:1px}.border-none{border:0}.border-top{border-top-style:solid;border-top-width:1px}.border-right{border-right-style:solid;border-right-width:1px}.border-b{border-bottom-style:solid;border-bottom-color:#ced4da;border-bottom-width:1px}.border-left{border-left-style:solid;border-left-width:1px}.rounded{border-radius:2px}.circle{border-radius:50%}.not-rounded{border-radius:0}.rounded-top{border-radius:2px 2px 0 0}.rounded-right{border-radius:0 2px 2px 0}.rounded-bottom{border-radius:0 0 2px 2px}.rounded-left{border-radius:2px 0 0 2px}@media (max-width:40em){.xs-border-hide{border:none}}@media (min-width:40em) and (max-width:52em){.sm-border-hide{border:none}}.flex{display:-ms-flexbox;display:flex}.flex-column{-ms-flex-direction:column;flex-direction:column}.flex-wrap{-ms-flex-wrap:wrap;flex-wrap:wrap}.items-start{-webkit-box-align:start;-webkit-align-items:flex-start;-ms-flex-align:start;-ms-grid-row-align:flex-start;align-items:flex-start}.items-end{-webkit-box-align:end;-webkit-align-items:flex-end;-ms-flex-align:end;-ms-grid-row-align:flex-end;align-items:flex-end}.items-center{-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;-ms-grid-row-align:center;align-items:center}.items-baseline{-webkit-box-align:baseline;-webkit-align-items:baseline;-ms-flex-align:baseline;-ms-grid-row-align:baseline;align-items:baseline}.items-stretch{-webkit-box-align:stretch;-webkit-align-items:stretch;-ms-flex-align:stretch;-ms-grid-row-align:stretch;align-items:stretch}.self-start{-ms-flex-item-align:start;align-self:flex-start}.self-end{-ms-flex-item-align:end;align-self:flex-end}.self-center{-ms-flex-item-align:center;align-self:center}.self-baseline{-ms-flex-item-align:baseline;align-self:baseline}.self-stretch{-ms-flex-item-align:stretch;align-self:stretch}.justify-start{-ms-flex-pack:start;justify-content:flex-start}.justify-end{-ms-flex-pack:end;justify-content:flex-end}.justify-center{-ms-flex-pack:center;justify-content:center}.justify-between{-ms-flex-pack:justify;justify-content:space-between}.justify-around{-ms-flex-pack:justify;justify-content:space-around}.content-start{-ms-flex-line-pack:start;align-content:flex-start}.content-end{-ms-flex-line-pack:end;align-content:flex-end}.content-center{-ms-flex-line-pack:center;align-content:center}.content-between{-ms-flex-line-pack:justify;align-content:space-between}.content-around{-ms-flex-line-pack:distribute;align-content:space-around}.content-stretch{-ms-flex-line-pack:stretch;align-content:stretch}.flex-auto{-ms-flex:1 1 auto;flex:1 1 auto;min-width:0;min-height:0}.flex-none{-ms-flex:none;flex:none}.order-0{-ms-flex-order:0;order:0}.order-1{-ms-flex-order:1;order:1}.order-2{-ms-flex-order:2;order:2}.order-3{-ms-flex-order:3;order:3}.order-last{-ms-flex-order:99999;order:99999}@media (max-width:52em){.sm-wrap{-ms-flex-wrap:wrap;flex-wrap:wrap}}@media (max-width:40em){.xs-flex{display:-ms-flexbox;display:flex}.xs-wrap{-ms-flex-wrap:wrap;flex-wrap:wrap}}@media (min-width:40em) and (max-width:52em){.sm-flex{display:-ms-flexbox;display:flex}}@media (min-width:52em){.md-flex{display:-ms-flexbox;display:flex}.md-order-last{-ms-flex-order:99999;order:99999}.md-justify-around{-ms-flex-pack:justify;justify-content:space-around}.md-justify-between{-ms-flex-pack:justify;justify-content:space-between}}@media (min-width:64em){.lg-flex{display:-ms-flexbox;display:flex}.lg-justify-start{-ms-flex-pack:start;justify-content:flex-start}.lg-order-last{-ms-flex-order:99999;order:99999}.lg-content-stretch{-ms-flex-line-pack:stretch;align-content:stretch}}@media (max-width:40em){.xs-br{display:block}}.col{float:left}.col-right{float:right}.col-1{width:8.3333%}.col-2{width:16.6667%}.col-3{width:25%}.col-4{width:33.3333%}.col-5{width:41.6667%}.col-6{width:50%}.col-7{width:58.3333%}.col-8{width:66.6667%}.col-9{width:75%}.col-10{width:83.3333%}.col-11{width:91.6667%}.col-12{width:100%}@media (min-width:40em){.sm-col{float:left}.sm-col-right{float:right}.sm-col-1{width:8.3333%}.sm-col-2{width:16.6667%}.sm-col-3{width:25%}.sm-col-4{width:33.3333%}.sm-col-5{width:41.6667%}.sm-col-6{width:50%}.sm-col-7{width:58.3333%}.sm-col-8{width:66.6667%}.sm-col-9{width:75%}.sm-col-10{width:83.3333%}.sm-col-11{width:91.6667%}.sm-col-12{width:100%}}@media (min-width:52em){.md-col{float:left}.md-col-right{float:right}.md-col-1{width:8.3333%}.md-col-2{width:16.6667%}.md-col-3{width:25%}.md-col-4{width:33.3333%}.md-col-5{width:41.6667%}.md-col-6{width:50%}.md-col-7{width:58.3333%}.md-col-8{width:66.6667%}.md-col-9{width:75%}.md-col-10{width:83.3333%}.md-col-11{width:91.6667%}.md-col-12{width:100%}}@media (min-width:64em){.lg-col{float:left}.lg-col-right{float:right}.lg-col-1{width:8.3333%}.lg-col-2{width:16.6667%}.lg-col-25{width:20.8333%}.lg-col-3{width:25%}.lg-col-4{width:33.3333%}.lg-col-5{width:41.6667%}.lg-col-6{width:50%}.lg-col-7{width:58.3333%}.lg-col-8{width:66.6667%}.lg-col-9{width:75%}.lg-col-10{width:83.3333%}.lg-col-11{width:91.6667%}.lg-col-12{width:100%}}@media (min-width:74em){.xl-col-l{float:left;width:calc(100vw - 70em + 25vw)}.xl-pad-l{margin-left:10.3333%}}.hide{position:absolute;height:1px;width:1px;overflow:hidden;clip:rect(1px,1px,1px,1px)}@media (max-width:40em){.xs-hide{display:none}}@media (min-width:40em) and (max-width:52em){.sm-hide{display:none}}@media (min-width:52em) and (max-width:64em){.md-hide{display:none}}@media (min-width:64em){.lg-hide{display:none}}.display-none{display:none}.inline{display:inline}.block{display:block}.inline-block{display:inline-block}.table{display:table}.table-cell{display:table-cell}.overflow-hidden{overflow:hidden}.overflow-scroll{overflow:scroll}.overflow-auto{overflow:auto}.clearfix:after,.clearfix:before{content:" ";display:table}.clearfix:after{clear:both}.left{float:left}.right{float:right}@media (min-width:64em){.lg-right{float:right}}.fit{max-width:100%}.max-width-2{max-width:40rem}.max-width-3{max-width:48rem}.max-width-4{max-width:64rem}.max-width-5{max-width:72rem}.mx-nw{margin-right:-1.2rem;margin-left:-1.2rem}.mt-0,.my-0{margin-top:0}.mt-02,.my-02{margin-top:.2rem}.mt-05,.my-05{margin-top:.5rem}.mt-1,.my-1{margin-top:1rem}.mt-2,.my-2{margin-top:2rem}.mt-3,.my-3{margin-top:3rem}.mt-4{margin-top:4rem}.mb-0,.my-0{margin-bottom:0}.mb-05{margin-bottom:.5rem}.mb-04{margin-bottom:.4rem}.mb-1,.my-1{margin-bottom:1rem}.mb-2,.my-2{margin-bottom:2rem}.mb-3,.my-3{margin-bottom:3rem}.my-auto{margin-top:150px}.mr-05,.mx-05{margin-right:.5rem}.mr-1,.mx-1{margin-right:1rem}.mr-15,.mx-15{margin-right:1.5rem}.mr-2,.mx-2{margin-right:2rem}.mr-3,.mx-3{margin-right:3rem}.ml-05,.mx-05{margin-left:.5rem}.ml-1,.mx-1{margin-left:1rem}.ml-15,.mx-15{margin-left:1.5rem}.ml-2,.mx-2{margin-left:2rem}.ml-3,.mx-3{margin-left:3rem}.ml-4{margin-left:4rem}.mr-auto,.mx-auto{margin-right:auto}.ml-auto,.mx-auto{margin-left:auto}.mt-n1{margin-top:-1rem}.mt-n2{margin-top:-2rem}.mt-n3{margin-top:-3rem}.mt-n5{margin-top:-5rem}.mt-n6{margin-top:-6rem}.mt-n7{margin-top:-7rem}.mt-n9{margin-top:-9rem}.mt-n10{margin-top:-10rem}.mt-n12{margin-top:-12rem}.mt-n15{margin-top:-15rem}.mt-n20{margin-top:-20rem}.mt-n25{margin-top:-25rem}.mt-n30{margin-top:-30rem}.mx-n1{margin-left:-1rem;margin-right:-1rem}.mx-n2{margin-left:-2rem;margin-right:-2rem}.mx-n3{margin-left:-1.5rem;margin-right:-1.5rem}.mx-n4{margin-right:-2rem;margin-left:-2rem}@media (max-width:40em){.xs-mt-n8{margin-top:-8rem}.xs-mb-5{margin-bottom:5rem}.xs-mx-2{margin-right:2rem;margin-left:2rem}.xs-mx-6{margin-right:6rem;margin-left:6rem}.xs-mt-1{margin-top:1rem}.xs-mx-auto{margin-right:auto;margin-left:auto}}@media (min-width:40em) and (max-width:52em){.sm-mt-n3{margin-top:-3rem}.sm-mt-n5{margin-top:-5rem}.sm-mt-n8{margin-top:-8rem}.sm-mt-1{margin-top:1rem}.sm-mb-1{margin-bottom:1rem}.sm-mb-2{margin-bottom:2rem}.sm-mb-3{margin-bottom:3rem}.sm-mr-1{margin-right:1rem}.sm-ml-1{margin-left:1rem}.sm-ml-2{margin-left:2rem}.sm-mr-auto,.sm-mx-auto{margin-right:auto}.sm-ml-auto,.sm-mx-auto{margin-left:auto}.sm-mx-n2{margin-right:-2rem;margin-left:-2rem}}@media (min-width:52em) and (max-width:64em){.md-mt-n6{margin-top:-6rem}.md-mb-3{margin-bottom:3rem}.md-mr-05{margin-right:.5rem}.md-mr-1{margin-right:1rem}.md-mr-2{margin-right:2rem}.md-mr-3{margin-right:3rem}.md-mr-4{margin-right:4rem}.md-ml-05{margin-left:.5rem}.md-ml-1{margin-left:1rem}.md-ml-2{margin-left:2rem}.md-ml-3{margin-left:3rem}.md-ml-4{margin-left:4rem}.md-mx-2{margin-right:2rem;margin-left:2rem}.md-mr-auto,.md-mx-auto{margin-right:auto}.md-ml-auto,.md-mx-auto{margin-left:auto}.md-mx-n1{margin-right:-1rem;margin-left:-1rem}}@media (min-width:64em){.lg-mt-n32{margin-top:-32rem}.lg-mt-n5{margin-top:-5rem}.lg-mt-n10{margin-top:-11rem}.lg-mt-n30{margin-top:-28rem}.lg-mr-05{margin-right:.5rem}.lg-mr-1{margin-right:1rem}.lg-mr-2{margin-right:2rem}.lg-mr-3{margin-right:3rem}.lg-mr-4{margin-right:4rem}.lg-ml-05{margin-left:.5rem}.lg-ml-1{margin-left:1rem}.lg-ml-2{margin-left:2rem}.lg-ml-3{margin-left:3rem}.lg-ml-4{margin-left:4rem}.lg-ml-10{margin-left:10rem}.lg-ml-auto,.lg-mx-auto{margin-left:auto}.lg-mx-auto{margin-right:auto}.lg-mx-n1{margin-right:-1rem;margin-left:-1rem}.lg-ml-n3{margin-left:-3rem}}.py-w{padding-top:1.5rem;padding-bottom:1.5rem}.px-w{padding-right:1.2rem;padding-left:1.2rem}.pt-06{padding-top:.6rem}.pt-05{padding-top:.5rem}.pb-05{padding-bottom:.5rem}.pt-25{padding-top:2.5rem}.pt-04{padding-top:.4rem}.pt-1,.py-1{padding-top:1rem}.pt-15{padding-top:1.5rem}.pt-2,.py-2{padding-top:2rem}.pt-3,.py-3{padding-top:3rem}.pt-4,.py-4{padding-top:4rem}.pb-1,.py-1{padding-bottom:1rem}.pb-2,.py-2{padding-bottom:2rem}.pb-3,.py-3{padding-bottom:3rem}.pb-4,.py-4{padding-bottom:4rem}.pr-05{padding-right:.5rem}.pr-06{padding-right:.6rem}.pr-08{padding-right:.8rem}.pr-1,.px-1{padding-right:1rem}.pr-015,.px-015{padding-right:1.5rem}.pr-2,.px-2{padding-right:2rem}.pr-3,.px-3{padding-right:3rem}.pr-4,.px-4{padding-right:4rem}.pl-05{padding-left:.5rem}.pl-08{padding-left:.8rem}.pl-1,.px-1{padding-left:1rem}.pl-015,.px-015{padding-left:1.5rem}.pl-2,.px-2{padding-left:2rem}.pl-3,.px-3{padding-left:3rem}.pl-4,.px-4{padding-left:4rem}@media (max-width:40em){.xs-pr-1,.xs-px-1{padding-right:1rem}.xs-pl-1,.xs-px-1{padding-left:1rem}.xs-pt-1{padding-top:1rem}.xs-px-2{padding-right:2rem;padding-left:2rem}}@media (min-width:40em) and (max-width:52em){.sm-pt-1{padding-top:1rem}.sm-pb-1{padding-bottom:1rem}.sm-pr-1,.sm-px-1{padding-right:1rem}.sm-pl-1,.sm-px-1{padding-left:1rem}.sm-pt-2{padding-top:2rem}.sm-pr-2{padding-right:2rem}.sm-pb-2{padding-bottom:2rem}.sm-pl-2{padding-left:2rem}.sm-px-5{padding-right:5rem;padding-left:5rem}.sm-pt-4{padding-top:4rem}.sm-pt-5{padding-top:5rem}.sm-pt-15{padding-top:15rem}}@media (min-width:52em) and (max-width:64em){.md-pr-1{padding-right:1rem}.md-pl-1{padding-left:1rem}.md-pl-2{padding-left:2rem}.md-px-1{padding-right:1rem;padding-left:1rem}.md-px-2{padding-right:2rem;padding-left:2rem}.md-pt-1{padding-top:1rem}.md-pt-2{padding-top:2rem}.md-pt-3{padding-top:3rem}.md-pt-5{padding-top:5rem}.md-pt-10{padding-top:12rem}.md-pb-1{padding-bottom:1rem}.md-pb-2{padding-bottom:2rem}}@media (min-width:64em){.lg-pr-1,.lg-px-1{padding-right:1rem}.lg-pl-1,.lg-px-1{padding-left:1rem}.lg-pl-2,.lg-px-2{padding-left:2rem}.lg-pr-2,.lg-px-2{padding-right:2rem}.lg-pr-3{padding-right:3rem}.lg-pl-3{padding-left:3rem}.lg-pr-4{padding-right:4rem}.lg-pl-4{padding-left:4rem}.lg-pl-5{padding-left:5rem}.lg-pt-1{padding-top:1rem}.lg-pt-2{padding-top:2rem}.lg-pt-3{padding-top:3rem}.lg-pt-4{padding-top:4rem}.lg-pt-5{padding-top:5rem}.lg-pt-8{padding-top:8rem}.lg-pt-22{padding-top:22rem}.lg-pb-1{padding-bottom:1rem}.lg-pb-2{padding-bottom:2rem}.lg-pb-3{padding-bottom:3rem}.lg-pb-4{padding-bottom:4rem}}.relative{position:relative}.absolute{position:absolute}.fixed{position:fixed}.top-0{top:0}.right-0{right:0}.bottom-0{bottom:0}.left-0{left:0}.z1{z-index:1}.z2{z-index:2}.z3{z-index:3}.z4{z-index:4}.z5{z-index:5}.z6{z-index:6}.z7{z-index:7}.z8{z-index:8}.zn1{z-index:-1}.zn2{z-index:-2}.font-family-inherit{font-family:inherit}.font-size-inherit{font-size:inherit}.text-decoration-none{text-decoration:none}.bold,.strong{font-weight:600}.light{font-weight:300}.regular{font-weight:400}.italic{font-style:italic;letter-spacing:.05rem}.caps{text-transform:uppercase;letter-spacing:.2rem}.tx-justify{text-align:justify}.nowrap{white-space:nowrap}.break-word{word-wrap:break-word}.line-h-0{line-height:.1}.line-h-1{line-height:1}.line-h-2{line-height:1.125}.line-h-3{line-height:1.25}.line-h-4{line-height:1.5}.list-style-none{list-style:none}.underline{text-decoration:underline}.ellipsis{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.material-icons{font-family:Material Icons;font-weight:400;font-style:normal;font-size:24px;display:inline-block;line-height:1;text-transform:none;letter-spacing:normal;word-wrap:normal;white-space:nowrap;direction:ltr;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;-moz-osx-font-smoothing:grayscale;-webkit-font-feature-settings:"liga";font-feature-settings:"liga"}.built .material-icons{background-color:#1e88e5;color:#e3f2fd}.material-icons.tres{font-size:15px;color:#bbdefb;vertical-align:middle;margin:1px 3px 3px 0;color:#bbb}*{box-sizing:border-box}p{line-height:1.6;margin-top:0;margin-bottom:2rem;font-family:Roboto,Oxygen,Ubuntu,Cantarell,Fira Sans,Droid Sans,Helvetica Neue,Arial,sans-serif}.textwidget p,p.lead{font-family:Montserrat}body{font-size:14px;font-weight:400;background-color:#fff;line-height:1.5;overflow-x:hidden;font-family:Montserrat,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Fira Sans,Droid Sans,Helvetica Neue,Arial,sans-serif;font-smooth:always;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility}p+p{margin-top:2.4rem}.tx-h1,.tx-h2,h1,h2,h3,h4,h5,h6{margin-top:0;margin-bottom:0}.tx-h1,h1{font-size:1.8rem;line-height:1.2}.tx-h2,h2{font-size:1.5rem;line-height:1.1}h3{font-size:1.25rem;line-height:1.3}blockquote,h3,h4{letter-spacing:.3px}blockquote,h4{font-size:.98rem;line-height:1.4;font-weight:700;word-spacing:.2em}h5{font-size:.91rem;letter-spacing:.05rem;font-weight:400}h5,h6{line-height:1.4}h6{font-size:.55rem;letter-spacing:.29em;text-transform:uppercase;font-weight:700}@media (min-width:52em){body{font-size:15px}.tx-h1,h1{font-size:2.4rem}.tx-h2,h2{font-size:1.8rem}h3{font-size:1.4rem}h4,h5{font-size:.96rem}}@media (min-width:64em){body{font-size:16px}h1{font-size:2.8rem}}a{color:#2196f3;text-decoration:none}p a:link,p a:visited{font-weight:400;color:#1e88e5}li a:link,li a:visited{font-weight:500;color:#2196f3}li a:hover,p a:hover{color:#1976d2}.no-decoration{text-decoration:none}blockquote{background-color:#f8f9fa;border-left:3.5px solid #2196f3;border-radius:1px;padding:6.5rem 1.2rem 1.5rem;margin:3rem 0 3rem .1rem;font-size:.98rem;line-height:1.65rem;font-weight:400;letter-spacing:-.1px;word-spacing:.12rem;text-transform:none;color:#828a91;font-family:Montserrat;background-image:url("<?php echo get_stylesheet_directory_uri(); ?>/img/logos/quote.png");background-position:10% 1.2%;background-size:70px;background-repeat:no-repeat;min-height:20px}blockquote.brand{background:#f9f9f9;border-left:3.5px solid #dee2e6;background-position:5% 5%;background-size:85px;font-size:.88rem;background-repeat:no-repeat;padding-top:3rem}@media (min-width:52em){blockquote{margin-left:1.5rem;padding-left:2.5rem}}blockquote footer{color:#6c757d;font-weight:500;font-size:85%;text-align:right;text-transform:uppercase;letter-spacing:.03rem;padding:.5rem 2rem .5rem 0}ol,pre,ul{margin-top:.6rem;margin-bottom:1rem;padding-top:0}.post-c ol li{list-style:upper-roman;margin-bottom:1rem}.list-inline,.list-unstyled{padding-left:0;list-style:none}.list-inline li{display:inline-block}.list-inline-item:not(:last-child){margin-right:.7rem}.list-lower-roman{list-style:lower-roman;padding-left:20%}.list-square{list-style-type:square}ul.brand{font-weight:500;font-size:90%;list-style-image:url("<?php echo get_stylesheet_directory_uri(); ?>/img/logos/li-square-600.svg")}.page-c ul,.post-c ul{list-style:none;padding-bottom:.5rem;margin-left:0}.page-c ul li,.post-c ul li{padding-left:.2rem;margin-bottom:.9rem;text-indent:-1.9rem}.page-c ul li:before,.post-c ul li:before{content:"";display:inline-block;height:1.15rem;width:1.15rem;margin-right:.8rem;background-image:url("<?php echo get_stylesheet_directory_uri(); ?>/img/logos/li-triangle.svg");opacity:.9;background-size:contain;background-repeat:no-repeat}@media (min-width:52em){.page-c ul,.post-c ul{margin-left:2rem;font-size:94%}}.unapost-c dl{margin:1.2rem 0 4.5rem;color:#495057;background-color:#fafafa;border-radius:.1rem;border:.05rem solid #e9ecef;padding-top:1.8rem;padding-bottom:1.3rem;padding-left:.8rem;font-size:90%}dt{float:left;clear:left;font-weight:600;text-overflow:ellipsis}dt:after{content:": "}.unapost-c dt{color:#495057}.unapost-c dd{color:#495057;padding:0 1rem .8rem 4.7rem;font-weight:400}@media (min-width:52em){.unapost-c dl{padding-left:1.8rem}.unapost-c dd{padding-left:7rem}}.list-reset{list-style:none;padding-left:0;margin-left:0}.list-reset li{text-indent:0}.page-c ol li{list-style-type:upper-roman;opacity:.95}table{border:.8px solid #e1e1e1;border-spacing:0;border-collapse:collapse;max-width:95%;width:95%}th{font-weight:600;text-align:left;color:#444;background-color:#f8f8f8}td,th{font-size:90%;border:.09rem solid #e1e1e1;padding:.4rem;margin-top:2rem;line-height:1.5rem}th{vertical-align:bottom}td{vertical-align:top}.bg-p9{background-color:#0d47a1}.bg-p8{background-color:#1565c0}.bg-p7{background-color:#1976d2}.bg-p75{background-color:#176ec9}.bg-p85{background-color:#1156b1}.bg-w4{background-color:#f5f5f5}.bg-w3{background-color:#f8f9fa}.bg-w2{background-color:#fafafa}.bg-w1{background-color:#fff}.bg-g3{background-color:#dee2e6}.bg-g2{background-color:#e9ecef}.bg-g1{background-color:#f8f9fa}.bg-hhs{background-image:linear-gradient(to top right,#053989,#0d47a1,#0d47a1)}.bg-pg{background-image:linear-gradient(to bottom right,#053989,#0d47a1,#0d47a1)}.bg-p9ga{background-image:linear-gradient(to bottom left,#053989,#0d47a1,#0d47a1,#1565c0)}.bg-p9gb{background-image:linear-gradient(270deg,#0d47a1,#053989,#0d47a1,#053989)}.bg-p8g{background-image:linear-gradient(to bottom right,#0d47a1,#1565c0,#0d47a1)}.bg-p8gb{background-image:linear-gradient(to bottom left,#0d47a1,#1565c0,#0d47a1)}#cta-1,#cta-2,#cta-3,.bg-p7g{background:linear-gradient(to bottom right,#1565c0,#1976d2,#1976d2,#1565c0)}.bg-cut-xi{clip-path:polygon(0 11%,100% 0,100% 89%,0 100%);-webkit-clip-path:polygon(0 11%,100% 0,100% 89%,0 100%)}.bg-cut-x{clip-path:polygon(0 0,100% 11%,100% 100%,0 89%);-webkit-clip-path:polygon(0 0,100% 11%,100% 100%,0 89%)}.bg-cut-r{clip-path:polygon(0 0,100% 0,100% 100%,0 89%);-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 89%)}.bg-cut-l{clip-path:polygon(0 0,100% 0,100% 89%,0 100%);-webkit-clip-path:polygon(0 0,100% 0,100% 89%,0 100%)}.bg-cut-ly{clip-path:polygon(0 0,100% 4%,100% 100%,0 100%);-webkit-clip-path:polygon(0 0,100% 4%,100% 100%,0 100%)}@media (max-width:52em){.bg-cut-xi{clip-path:polygon(0 5%,100% 0,100% 95%,0 100%);-webkit-clip-path:polygon(0 5%,100% 0,100% 95%,0 100%)}.bg-cut-x{clip-path:polygon(0 0,100% 5%,100% 100%,0 95%);-webkit-clip-path:polygon(0 0,100% 5%,100% 100%,0 95%)}.bg-cut-r{clip-path:polygon(0 0,100% 0,100% 100%,0 95%);-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 95%)}.bg-cut-l{clip-path:polygon(0 0,100% 0,100% 95%,0 100%);-webkit-clip-path:polygon(0 0,100% 0,100% 95%,0 100%)}.bg-cut-ly{clip-path:polygon(0 0,100% 2%,100% 100%,0 100%);-webkit-clip-path:polygon(0 0,100% 2%,100% 100%,0 100%)}}.border{border:.5px solid #ddd}.border-d{border:.3px solid #1e88e5}.btn-outline,.btn-p5,.btn-p7,.btn-p9,.btn-pg a,.btn-s5,.btn-t5,.btn-white{display:inline-block;min-width:4rem;padding:.25rem .92rem .15rem;text-align:center;font-size:.7rem;font-weight:700;line-height:2.5rem;letter-spacing:.12rem;word-spacing:.2rem;text-decoration:none;text-transform:uppercase;white-space:nowrap;background-color:transparent;transition:all .3s ease;border-radius:1px;cursor:pointer;box-sizing:border-box}@media (max-width:39.99em){.btn-sm-x{display:block;width:170px;padding:0 1.05rem}}.btn:focus{color:#333;outline:0}.no-outline{border:transparent}.btn-p5,.btn-p5:link,.btn-p5:visited{color:#fff;background-color:#2196f3}.btn-p5:focus,.btn-p5:hover{color:#fff;background-color:#1e88e5}.btn-p7,.btn-p7:link,.btn-p7:visited{color:#eee;background-color:#1976d2}.btn-p7:focus,.btn-p7:hover{background-color:#1565c0}.btn-p9,.btn-p9:link,.btn-p9:visited{color:#ddd;background-color:#0d47a1}.btn-p9:focus,.btn-p9:hover{background-color:#053989}.btn-s5,.btn-s5:link,.btn-s5:visited{color:#fff;background-color:#7519d2}.btn-s5:focus,.btn-s5:hover{color:#fff;background-color:#601fc7}.btn-outline,.btn-outline:link,.btn-outline:visited{color:#828a91;border:1.4px solid #adb5bd}.btn-outline:focus,.btn-outline:hover{color:#1e88e5;border-color:#1e88e5}.btn-sm{font-size:.6rem;min-width:none;line-height:2.8}.btn-md{font-size:.7rem;min-width:8rem;line-height:3}.btn-lg{font-size:.8rem;min-width:12rem;line-height:3.5}.btn-pg a:link,.btn-pg a:visited{line-height:1.8rem;min-width:13em;color:#888;background-color:#fafafa;border:1px solid #adb5bd;border-color:#e2e2e2;font-weight:600;margin:auto 3px}.btn-pg a:focus,.btn-pg a:hover{background-color:#f8f9fa}.menu-pgs li{display:inline-block}.btn-block{display:block;max-width:200px}.menu-pgs{text-align:center;padding:2.3rem 0}input[type=email],input[type=number],input[type=password],input[type=tel],input[type=text],input[type=url],select,textarea{height:38px;padding:6px 10px;background-color:#fff;border:1px solid #d1d1d1;border-radius:2px;box-shadow:none;box-sizing:border-box}textarea{min-height:5rem;width:100%;padding-top:1rem;padding-bottom:1rem}input[type=email]:focus,input[type=number]:focus,input[type=password]:focus,input[type=search]:focus,input[type=tel]:focus,input[type=text]:focus,input[type=url]:focus,select:focus,textarea:focus{border:1px solid #33c3f0;outline:0}label,legend{display:block;margin-bottom:.5rem;font-weight:600}fieldset{padding:0;border-width:0}.btn-outline:visited,.btn-search,.btn-search:link{background-color:#f8f9fa;color:#6c757d;font-size:.75rem;line-height:1.4rem;text-transform:uppercase;font-weight:600;letter-spacing:.12rem;border:1px solid #dee2e6;border-radius:2px;padding:.3rem;min-width:120px;min-height:45px;box-sizing:border-box}.btn-search:focus,.btn-search:hover{color:#6c757d;background-color:#f5f5f5}.search-in{background-color:#fff;margin-right:.1rem;font-size:1rem;letter-spacing:.1rem;line-height:1.4rem;border:1px solid #dee2e6;border-radius:2px;padding:.3rem 1.8rem .3rem .3rem;min-height:45px}.img-thumb{width:80px;height:80px;background:linear-gradient(-45deg,#f8f9fa,#e9ecef);border-radius:50%;display:-ms-flexbox;display:flex;-ms-flex-pack:center;justify-content:center}.card{border:1px solid #d6d6d6;border-radius:1px;margin:2rem 0 1rem}.card-index{border:1px solid #d6d6d6;border-radius:2px;background:#fff;box-shadow:2px 6px 25px rgba(0,0,0,.1);transition:all .5s ease;position:relative;margin-bottom:3rem}@media (min-width:52em){.card-index{max-width:calc(50% - 1.2rem)}}.card-index amp-img{border-radius:2px 2px 0 0;margin-bottom:0}.card-index .body{padding:1.5rem 1.4rem 3rem}.card-index p{margin:0;font-size:.85rem;color:#6c757d}.card-index footer{position:absolute;bottom:0;width:100%}.card-index .footer-d{padding:.1rem 1.4rem 2rem}@media (min-width:52em){.card-index .footer-d{padding-bottom:2rem}}.card amp-img{border-radius:4px 4px 0 0}.card-index h4,.card-index h5,.card-index h6{margin:0}.card-index .cat{font-size:.72em;letter-spacing:.18rem;text-transform:uppercase;text-decoration:none;word-spacing:.2rem}.card-index .title{margin:1rem 0 .2rem;font-size:1.3rem}.card-index .date{font-size:8px;line-height:1.1rem;color:#aaa;font-weight:800;letter-spacing:.2rem;word-spacing:2px;text-transform:uppercase}.card-index .author{margin:0;text-transform:uppercase;color:#bbb;font-weight:500;font-size:.7em}.card-index .cat a:link,.card-index .cat a:visited{color:#aaa}.card-index .cat a:hover{color:#1565c0}.card-index .title a:link,.card-index .title a:visited, .card-polifx .title a:link,.card-polifx .title a:visited{color:#5e5e65;text-decoration:none}.card-index .title a:hover,.card-polifx .title a:hover{color:#42a5f5}.card-index:hover{box-shadow:2px 6px 30px rgba(0,0,0,.3)}.card-profile{-ms-flex:1 1 auto;flex:1 1 auto;border:1px solid #d6d6d6;border-radius:2px;margin:1.2rem 1.1rem;min-height:140px;background:#fff;box-shadow:2px 6px 25px rgba(0,0,0,.12);transition:all .4s ease;font-size:.8rem}.card-profile .body{padding:1rem 1.1rem 0 .5rem}.card-profile .twitter{margin-bottom:0}.card-profile .position{font-size:1rem;text-transform:uppercase}.card-profile .title a:link,.card-profile .title a:visited{margin:0;color:#6c757d}.card-profile .title a:hover{color:#2196f3}.card .btn{display:block;margin:1rem auto 2rem;font-size:70%;border:1px solid #1976d2;color:#1976d2}.card-testimonials{border:1px solid #d6d6d6;color:#555;background:#f8f8f8;border-radius:2px;margin:2rem 1rem;padding:2rem 1.4rem 1.2rem}.card-shadow-l{box-shadow:2px 6px 25px hsla(0,0%,39%,.2)}.card .shadow{box-shadow:0 2px 5px 0 rgba(0,0,0,.2),0 3px 6px 0 rgba(0,0,0,.2)}.box-shadow{box-shadow:0 3px 5px 0 rgba(0,0,0,.12),0 3px 5px 0 rgba(0,0,0,.1)}.card-polifx{size:.88rem;background:#fafafa;position:relative;margin-bottom:1.9rem;box-shadow:2px 6px 25px rgba(0,0,0,.1);transition:all .4s ease;border:1px solid #e9ecef}@media (min-width:52em){.card-polifx{max-width:calc(50% - .8rem)}}@media (min-width:70em){.card-polifx{max-width:calc(50% - 1.2rem)}}.card-polifx .excerpt{color:#6c757d;font-size:95%;padding-bottom:1.5rem}.card-polifx .date{color:#bbb;margin:0 auto .15rem}.card-polifx .title{font-size:1.2rem;margin:0 auto .2rem}.card-polifx .cat{color:#828a91;margin:0 auto 1.9rem}.card-polifx .head{padding:1.1rem .65rem 0;float:left}.card-polifx .body{overflow:hidden;padding:1.3rem 1.25rem 4rem .3rem}.card-cta:hover,.card-hm:hover,.card-polifx:hover,.card-profile:hover{box-shadow:2px 6px 30px rgba(0,0,0,.25);transition:all .4s ease}.card-polifx footer{position:absolute;bottom:.8rem;width:100%;background-color:#fafafa}.tresfx{padding-left:4.3rem;width:100%;display:-ms-flexbox;display:flex;overflow:hidden;-ms-flex-direction:row;flex-direction:row;color:#999;font-size:83%}@media (max-width:52em){.card-polifx .tresfx{padding-left:60px}}.tresfx .it{-ms-flex:2 0;flex:2 0;display:inline-block;padding:10px 25px 12px 0;margin-bottom:0}.lightbox-box{box-shadow:2px 6px 30px rgba(0,0,0,.2);background-color:#212529;margin:.5rem 0 .9rem;max-height:633px}#lightbox1 .caro-wrap{margin-top:2rem;background-color:#212529;box-shadow:3px -6px 30px rgba(0,0,0,.2)}.lightbox-box .slide-caption{padding-top:.8rem}.card-portfolio{border:1px solid #d6d6d6;border-radius:1px;background:#fff;margin:2rem .9rem 0}.card-portfolio amp-img{border-radius:1px}#portfolio-wrap hr{margin-bottom:0}#portfolio-wrap .close{color:#888;background:none;border:none;float:right;font-size:90%;margin-right:0;clear:both}.amp-carousel{margin-bottom:2rem}.carousel-box{box-shadow:2px 4px 10px rgba(0,0,0,.3);border-bottom:1px solid #efefef;margin:3rem -.11rem 1rem;padding-bottom:1rem;background:#fff;border-right:.8px solid #e1e1e1;border-left:.8px solid #e1e1e1}.slide-caption{padding:1rem 1rem 0;line-height:1.3rem;color:#828a91;text-align:right;font-size:80%;font-weight:400}@media (min-width:40.06rem){.slide-caption{padding:2.5rem 1.5rem 0;font-size:85%}}.ahi-full{background-image:radial-gradient(rgba(13,71,161,.9),rgba(21,101,192,.8)),url("<?php echo get_stylesheet_directory_uri(); ?>/img/logos/factsheet-bg-image10.jpg");background-position:50%,50%;background-repeat:no-repeat;background-size:cover,cover}.page-about h6{margin-bottom:.7rem}.lg-mt-05{margin-top:.6rem}.mt-07{margin-top:.7rem}.pt-9{padding-top:9rem}.card .tx-small{font-size:.88rem;line-height:70%}.brand-box{color:#e9ecef;line-height:1.5rem;padding:calc(13vw + 60px) 1rem 4.5rem;min-height:calc(34vw + 100px)}.about-h{width:100%;position:relative;z-index:-1;margin-top:calc(-4rem - 1.5vw);max-height:750px}.about-h-bg{background-image:radial-gradient(rgba(13,71,161,.8),rgba(21,101,192,.4)),url("<?php echo get_stylesheet_directory_uri(); ?>/img/media/hero-about.svg");background-position:50%,50%;background-size:cover,cover;overflow:hidden}.about-fill,.about-h-bg{background-repeat:no-repeat}.about-fill{background-image:radial-gradient(rgba(13,71,161,.1),rgba(21,101,192,.1));background-size:cover}.about-h .hero-box{color:#e9ecef;padding:calc(13vw + 60px) 1.2rem 4.5rem;min-height:calc(31vw + 200px)}.about-h .title{opacity:.9;font-weight:600}.brand-h-bg{background-image:radial-gradient(rgba(13,71,161,.8),rgba(21,101,192,.4)),url("<?php echo get_stylesheet_directory_uri(); ?>/img/media/hero-about.svg");background-position:50%,50%;background-size:cover,cover}.brand-h-bg,.brand-h-fil{background-repeat:no-repeat}.brand-h-fil{background-image:radial-gradient(rgba(13,71,161,.1),rgba(21,101,192,.1));background-size:cover}.brand-h-bg{overflow:hidden}.brand-h{width:100%;position:relative;z-index:-1;margin-top:calc(-4rem - 1.5vw);max-height:750px}.plugin-h .lead{color:#eee}.plugin-h .hero-box{color:#e9ecef;opacity:.95;line-height:1.5rem}.brand-h .hero-box{color:#e9ecef;padding:calc(13vw + 60px) 1.2rem 4.5rem;min-height:calc(35vw + 100px)}.brand-h .title{opacity:.9;font-weight:600;text-shadow:.2px .2px .2px #ceee}.c-step{background-color:#0d47a1;padding:2rem 1.1rem 2rem 1.2rem;color:#bbdefb;font-size:.9rem}.steps-w{border:1px solid #1156b1}@media (max-width:52em){.steps-w .sxs-bb{border-bottom:.7px solid #1156b1}}@media (min-width:52em) and (max-width:64em){.steps-w .md-bb{border-bottom:.7px solid #1156b1}.steps-w .md-br{border-right:.7px solid #1156b1}}@media (min-width:64em){.steps-w .lg-br{border-right:.7px solid #1156b1}}.c-step p{line-height:1.2rem;margin-bottom:2.6rem}.c-step .details{display:block;letter-spacing:.11rem;padding:.3rem .8rem;color:#bbdefb;text-align:center;font-size:.65rem;font-weight:700;text-transform:uppercase;background-color:#1976d2;border-radius:2px;max-width:90px;margin-left:4.13rem}@media (min-width:52em){.c-step{position:relative}.c-step .details{position:absolute;bottom:1.35rem;right:2rem;left:2rem;width:90%;margin:auto}}.line-img{float:right;padding-top:6rem}@media (max-width:64em){.c-step amp-img{margin-right:1rem;float:left}}@media (min-width:64em){.c-step amp-img{margin-left:auto;margin-right:auto;display:block}}.website{padding:10rem 1.6rem 13rem}.process{padding:12rem 0 16rem}.tools{padding:9rem 1.2rem 12rem}.tools .border{border:0 solid #1156b1}.line-img amp-img{float:right}.single-unafactsheet{color:#444}.poli-h{width:100%;height:100%;margin-top:calc(-4rem - 1.5vw);position:relative;z-index:-1}.poli-iw{background-size:cover;background-image:linear-gradient(90deg,#065cd4,#0c65d8,#136edc);overflow:hidden}.poli-i{overflow:hidden;background-color:#0054d0}.poli-i amp-img{filter:brightness(30%) grayscale(99%) opacity(29%)}.poli-i>amp-img{width:auto;min-height:450px;max-height:calc(19vw + 23rem)}.poli-i>amp-img img{-o-object-fit:cover;object-fit:cover}.poli-hh{margin-top:calc(-195px - 11vw);padding-right:1.2rem;padding-left:1.2rem;font-size:85%;text-align:center}.poli-hh .title{padding-bottom:1.8rem;opacity:.99}.poli-hh{color:#e3f2fd}.snap-w{padding:1.5rem .5rem}.snap{background:#1565c0;color:#bbdefb;color:#e3f2fd;padding-bottom:0;border-radius:.1rem;opacity:1;box-shadow:2px 6px 20px rgba(0,0,0,.4)}.snap .cat{text-transform:uppercase;font-weight:500;color:#64b5f6;font-size:1rem;margin-bottom:.2rem}.snap .title{max-width:41rem;font-size:1.45rem;opacity:.99;color:#e3f2fd;margin-bottom:1.5rem}.snap .bar:after{content:"";display:block;margin:2rem 0;height:2px;width:3rem;background:#2196f3}.snap-ex{font-size:108%;margin-bottom:1.5rem}.snap .label,.snap h6{color:#64b5f6}.snap h6{padding-bottom:.1rem}.snap .date{margin-bottom:1.2rem;font-size:.6rem;font-weight:500;letter-spacing:.5px;color:#bbdefb}.snap .date .dd{font-weight:600}.snap .date .dt{float:left;padding-right:.3rem}.snap-s2 .label{border:1px solid #176ec9;background:#1669c5;padding:1.4rem 1rem;border-bottom:none}.dl-fx-2{padding:.9rem 1rem;font-size:88%;background:#1872ce;border-top:1.2px solid #1669c5}.dl-fx-2:last-of-type{border-bottom:1px solid #1669c5}.snap .pol{padding-right:1.3rem}.material-icons.pol{font-size:1.15rem;color:#42a5f5}.material-icons.pfc{font-size:1rem;vertical-align:middle;margin-right:.6rem;color:#42a5f5;color:#2196f3;color:#adb5bd}.snap-v{display:-ms-flexbox;display:flex;-ms-flex-pack:start;justify-content:flex-start;-ms-flex-align:center;align-items:center;background:#1976d2;border:none;padding:1rem .9rem 1rem .5rem}.snap-v>div{text-transform:capitalize;font-weight:600;margin-right:auto;padding-left:.5rem;color:#e3f2fd}.snap-v .label{color:#bbdefb}.snap .snap-s svg{opacity:1;fill:#bbdefb;transition:all .4s ease}.snap-h{padding-top:1rem}.snap-s1{padding:1rem 1.2rem 0}.snap-m{padding:0}.snap-s2{padding:.5rem .6rem 0}.snap-f1{padding:0 .6rem 1.2rem}.snap-f2{padding:0 1.2rem 1.2rem}@media (min-width:52em){.snap-f1,.snap-s2{padding-right:1rem;padding-left:1.2rem}.snap-fw,.snap-m{display:-ms-flexbox;display:flex}.snap-f2,.snap-s1{margin-right:2.5rem}.snap-s1{width:58%}.snap-s2{width:42%}div.snap-s1{display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column}.snap-f1{width:42%}.snap-f2{width:58%}}div.snap-f2{display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;-ms-flex-pack:end;justify-content:flex-end}.snap-s ul{list-style:none;padding:0;margin-bottom:0}.snap-s li{display:inline-block;margin-bottom:0;margin-top:0}.snap-s li:not(:last-child){margin-right:.7rem}.snap-s svg{width:1.6rem;height:auto}@media (min-width:52em){.snap-s svg{width:1.8rem}}.snap .snap-s svg:hover{fill:#2196f3;opacity:1}.byline .snap-s svg{opacity:.8;fill:#6c757d;transition:all .4s ease}.byline .snap-s svg:hover{fill:#1e88e5;opacity:1}


  .single-unafactsheet .content ul li:before{background-image:url("<?php echo get_stylesheet_directory_uri(); ?>/img/logos/li-triangle.svg")}.single-unafactsheet .content ul li{margin-left:-.5rem}

  .footer-p{background-color:#053989;font-weight:400;color:#aaa;margin:0}.footer-pw{padding:3rem 1.2rem}.footer-b{background-color:#00286c;padding:1.5rem 1rem}.contactphone{font-size:.75rem;padding:.2rem 1rem 1rem 0}.contactphone svg{fill:#1976d2;margin:.2rem .4rem .2rem .1rem;vertical-align:middle}.footer-p .logo{max-width:275px;width:100%;height:auto;opacity:1;margin-top:1.5rem}.footer-p h4{margin:1.5rem 0 .5rem;letter-spacing:.1rem}@media (min-width:60.01em){.footer-p .logo{max-width:300px}}.footer-p a:link,.footer-p a:visited{color:#adb5bd;opacity:1;font-weight:500;letter-spacing:.15rem;text-decoration:none}.footer-p a:hover{color:#2196f3}.copyright{color:#828a91;font-size:.5rem;text-transform:uppercase;letter-spacing:2.3px;margin:.7rem}.copyright,.pg-title{text-align:center;font-weight:600}.pg-title{color:#495057;padding-top:2.5rem;padding-bottom:.5rem;border-bottom:1px solid #e9ecef;margin-right:1.2rem;margin-left:1.2rem}body{width:100%}.hm-img,.hm-img2{background-image:url("<?php echo get_stylesheet_directory_uri(); ?>/img/media/h-img.png");background-size:contain;background-repeat:no-repeat;background-position:50% 50%;min-height:350px;max-width:100%}@media (min-width:40em){.hm-geo{background-image:url("<?php echo get_stylesheet_directory_uri(); ?>/img/media/h-geo.png");background-size:contain;background-repeat:no-repeat;background-position:50% 50%;min-height:350px;max-width:100%}}@media (max-width:39.99em){.hm-img{background-image:url("<?php echo get_stylesheet_directory_uri(); ?>/img/media/h-img-3.png")}.hm-geo{background-image:url("<?php echo get_stylesheet_directory_uri(); ?>/img/media/h-geo-1.png");background-size:contain;background-repeat:no-repeat;background-position:50% 50%;min-height:350px;max-width:100%}}.texture,.texture2{background-image:url("<?php echo get_stylesheet_directory_uri(); ?>/img/media/h-geo-2.png");background-size:contain;background-repeat:no-repeat;background-position:75% 50%;min-height:380px;width:100%;background-attachment:fixed}.texture2{background-image:url("<?php echo get_stylesheet_directory_uri(); ?>/img/media/h-geo-1.png")}.frontpage h6{margin-bottom:.6rem}.hh{height:calc(83vw + 340px);width:100%;overflow:hidden;margin:-7rem 0 0;position:relative;z-index:-1}.hhc{width:96%;right:2%;left:2%;padding:2rem 1.3rem 2.5rem;border-radius:2px;box-shadow:3px 10px 15px rgba(50,50,50,.25);transition:all .3s ease;letter-spacing:0;background:#fff;color:#6c757d;position:absolute;z-index:2}.hhi{padding-top:3rem}@media (max-width:39.99em){.hhi{margin-left:9vw;overflow:hidden}.hhc{background:#1565c0;border:1px solid #1565c0;color:#e9ecef;margin:-8.5rem auto 0;box-shadow:4px 6px 30px rgba(9,9,9,.4)}.hh{background:linear-gradient(to bottom right,#053989,#1565c0,#1156b1)}}@media (min-width:40em){.hhc{right:50%;left:50%}}@media (min-width:40em) and (max-width:63.99em){.hh{height:calc(65vw + 300px)}.hhc{margin:-11.5rem -17.25rem auto;width:34.5rem}}@media (min-width:64em){.hh{height:860px;width:100%;margin:-7rem 0 0}.hhc{width:26rem;padding:2.5rem 1.6rem;margin:-40rem 0 auto -47.5%}}@media (min-width:74em){.hh{height:900px}.hhc{right:48%;margin:-40rem -33rem auto}}.message-mt{margin-top:-4rem}@media (max-width:39.99em){.message-mt{margin-top:-4rem}}.message{color:#dee2e6;padding:17rem 1.2rem}@media (min-width:64em){.message{padding-top:15rem}}.targeted{padding:10rem 0;color:#888}.tbl-shadow{box-shadow:2px 4px 25px rgba(0,0,0,.4)}.tar-t{color:#fafafa;background-color:#1565c0;border-radius:2px}.tar-tw{margin:0 .6rem}.tar-t .header{background-color:#0d47a1;border-bottom:1px solid #053989;color:#bbdefb;padding:1.4rem 1rem 1rem 1.2rem}.tar-t .pen{border-bottom:1px solid #0d47a1;padding:1.3rem .8rem .3rem}.tar-t .pop{background-color:#1976d2;box-shadow:0 2px 6px rgba(0,0,0,.25);border-bottom:1px solid #1156b1;border-left:1px solid #1565c0;padding-top:1.3rem;padding-bottom:.45rem}.tar-t .pen-l,.tar-t .pop-l{border-bottom:1px solid #1565c0}.tar-t h5{font-size:.8rem;font-weight:400;letter-spacing:.02rem}.tar-t svg{fill:#42a5f5;opacity:1;margin:0 1.6rem .1rem .8rem}@media (max-width:42em){.tar-t .pen svg{margin:.1rem .7rem .2rem .2rem;height:17px;width:17px}}@media (min-width:42em){.tar-t .pen svg{height:22px;width:22px}}@media (min-width:52em){.tar-t h5{font-size:.9rem}}.tar-t{border:1px solid #0d47a1}.updates{padding:12rem 0 5rem}.built{padding:14rem 0 0;border-bottom:1.2px solid #1565c0}.built span{padding-bottom:3rem;font-size:.9em}.built h5{font-weight:700;font-size:1.1rem;margin-top:-.2rem;color:#e9ecef}.built .card{background:#1565c0;color:#f8f9fa;margin:0 1rem 2.5rem;border:2px solid #1565c0;box-shadow:2px 6px 25px hsla(0,0%,8%,.35);padding:2.4rem 1.2rem}.peti-h{width:100%;height:100%;margin-top:calc(-4rem - 3vw);position:relative;z-index:-1}.peti-iw{background-image:linear-gradient(90deg,#00286c 50%,#0d47a1 51%,#0d47a1);overflow:hidden}.peti-i{overflow:hidden;background-color:#0d47a1}.peti-i amp-img{filter:brightness(41%) grayscale(90%) contrast(92%) opacity(21%)}.peti-i>amp-img{width:auto;min-height:500px;max-height:calc(20vw + 23rem)}.peti-i>amp-img img{-o-object-fit:cover;object-fit:cover}.peti-nms{margin-top:-230px;background-color:green}.peti-hh{margin-top:calc(-210px - 5vw)}.peti-hhh{margin-top:calc(-210px - 11vw);padding:.1rem 1.2rem;font-size:85%;text-align:center}.peti-hhh .cat{font-weight:500;text-transform:uppercase;margin:.5rem auto .3rem}.peti-hhh .title{padding:1.5rem 1rem 0}.peti-hhh .date{font-weight:600;margin:.3rem auto 2.5rem}.peti-hhh{color:#e9ecef}.peti-layout{position:relative;display:block}@media (min-width:52em){.stick-w{display:-ms-flexbox;display:flex;-ms-flex-pack:justify;justify-content:space-between;max-width:100%;margin:0 auto}.stick-col{background:red;display:inline-block;position:relative}.stick-col-c{top:30px;position:-webkit-sticky;position:sticky;margin-bottom:10px}}.petition-we{background-color:#31383f;background-color:#bbb;padding:5rem 0 .1rem;font-size:1.03rem}.petition-w p:first-of-type{font-size:1.1rem;font-style:italic}#cta-4{color:#f8f8f8;background-color:#3a4cb1;text-align:center;padding:2rem 0 5.5rem}.peti-headline{text-align:center;color:#eee;font-size:240%;padding:2rem 0 1rem;font-weight:400;vertical-align:text-top}p+h2,p+h3{margin-top:3rem}p+h2{margin-top:4rem}.page-c h2,.page-c h3,.page-c h4,.page-c h5,.page-c h6,.post-c h2,.post-c h3,.post-c h4,.post-c h5,.post-c h6{margin-bottom:.2rem}.material-icons.md-18{font-size:1em}.page-c h4,.post-c h4{text-transform:uppercase}.page-c{margin-top:2rem}.post-c li strong{font-weight:600}.page-c,.post-c{padding:1rem 1.2rem;color:#495057}.profile-c{padding:5rem 1.2rem}.post-c .content strong{opacity:.95}.page-c h2,.page-c h3,.page-c h4,.page-c h5,.post-c h2,.post-c h3,.post-c h4,.post-c h5{color:#495057;opacity:.96}.post-c p>small{line-height:0;font-size:70%;margin:0;color:#6c757d}.post-c hr{margin:2rem 0 1rem}.post-h{padding:3rem 1.2rem 2rem}@media (max-width:40em){.h-img{margin:auto -1.2rem}}.post-h hr{margin:auto 1.2rem;border-width:0;border-top:.8px solid #e1e1e1;max-width:67em}.post-h .title{color:#495057;opacity:1;font-weight:700;max-width:825px;margin-bottom:.8rem}@media (min-width:52em){.post-h .title{margin-bottom:1.2rem}.post-h .caption{margin-right:.2rem}}@media (min-width:79.5em){.post-h .title{padding-right:0;padding-left:0}}.dateline-t .cat{margin:0 auto .2rem;text-transform:uppercase}.dateline-t{color:#adb5bd;padding-top:2rem}.dateline-s ul{list-style:none;padding:0}.dateline-s svg{fill:#adb5bd;height:auto;width:1.9rem;margin-bottom:.6rem}@media (max-width:51.99em){.dateline-s li{display:inline-block}.dateline-s li:not(:last-child){margin-right:.7rem}.dateline-s svg{width:1.6rem;height:auto}.dateline-s ul{margin:.3rem auto}}.post-h .caption,.website .caption{font-weight:500;font-size:.62rem;letter-spacing:.05rem}.post-h .caption{color:#aaa;text-align:right;padding:.4rem 0 0 1rem}.byline{padding:.5rem 0 4rem}.byline .author{font-weight:500;display:overflow-hidden;color:#555;padding-right:.6rem;margin-bottom:.2rem}.byline .twitter{color:#555;font-size:80%;font-weight:400;padding-right:.6rem;display:block;letter-spacing:.08rem;text-transform:uppercase}.byline amp-img{float:left;margin-right:1rem;border-radius:3px}.social-w{padding:0 1.2rem}.social svg{fill:#828a91;transition:.3s ease}.social svg:hover{fill:#1565c0;opacity:1;transition:all .3s ease}.byline .tags,.posttags .tags{color:#aaa}.related-ul a:link,.related-ul a:visited{color:#999}.related-ul a:hover{color:#1e88e5}.byline .tags a:link,.byline .tags a:visited,.posttags .tags a:link,.posttags .tags a:visited{text-decoration:none;text-transform:uppercase;color:#bbb;background-color:#f8f9fa;padding:.05rem .2rem;font-size:87%;font-weight:400}.byline .tags a:active,.byline .tags a:hover,.posttags .tags a:active,.posttags .tags a:hover{color:#1976d2}.brand-label{font-size:79%;margin-top:.2rem;letter-spacing:.06rem}.brand-label,.post-label{font-weight:600;text-transform:uppercase}.post-label{color:#69737c;text-align:right;margin-top:1rem;padding-right:.5rem}.post-label:before{content:" "}.post-label:after{display:block;content:" ";background-color:#1976d2;margin:1rem .3rem 1rem auto;height:.15rem;width:5rem}.byline .label,.posttags .label,.related .label{color:#aaa;text-decoration:none;text-transform:uppercase;font-weight:700;line-height:.8;font-size:.68rem;letter-spacing:.18rem;margin:0;padding-bottom:.5rem;margin-top:2rem}figure{margin:1rem -1.25rem 1.5rem}figure amp-img{border:1px solid #dee2e6}@media (min-width:40em){figure{margin:2.5rem 0 2rem}}figure figcaption{line-height:1.8;max-width:450px;color:#adb5bd;font-weight:500;direction:rtl;text-align:justify;padding:.6rem 1.2rem 0;margin-left:auto;font-size:.68rem}@media (min-width:40em){figure figcaption{padding:.5rem .1rem}}@media (min-width:64em){figure{margin-right:-4.2rem;margin-left:-4rem}}.data{background-color:#fcfcfc;margin:3rem -1.2rem;padding:1.5rem 1.4rem;font-size:95%;color:#6c757d}@media (max-width:40em){.data{border-top:1px solid #ddd;border-bottom:1px solid #ddd}}@media (min-width:40em){.data{border-radius:.2rem;border:1px solid #ddd}}@media (min-width:52em){.data{margin:2.4rem 0 3rem;padding-left:3rem}}.data h5{font-size:72%;letter-spacing:.11rem;word-spacing:.2rem;text-transform:uppercase;text-align:right;color:#1e88e5;padding:.2rem .1rem}.data strong{display:block;color:#1e88e5;font-size:275%;font-weight:400;margin-top:1rem}@media (min-width:52em){.data strong{font-size:300%;margin-top:3rem}}.unapost-c{padding-top:2rem}.unapost-layout{position:relative;display:block}@media (min-width:52em){.unapost-wrap{display:-ms-flexbox;display:flex;max-width:100%;margin:0 auto}.unapost-side{display:inline-block;position:relative;padding-right:1.2rem;padding-left:1.2rem}.unapost-stick{top:80px;position:-webkit-sticky;position:sticky;margin-bottom:210px}}.profile-h{margin-top:-4.5rem;width:100%;position:relative;z-index:-1;overflow:hidden}@media (min-width:64em){.profile-h{margin-top:-5rem;height:auto}}.profile-h-bg{background-image:radial-gradient(rgba(13,71,161,.8),rgba(21,101,192,.3)),url("<?php echo get_stylesheet_directory_uri(); ?>/img/media/hero-about.svg");background-position:50%,50%;background-repeat:no-repeat;background-size:cover,cover;overflow:hidden}.profile-h .hero-box{padding:23% 1rem 12%}@media (min-width:40em){.profile-h .hero-box{padding:18% 1rem 16%}.profile-h .title{margin-top:-2rem}}@media (min-width:52em){.profile-h .hero-box{padding-top:15%;padding-bottom:11%}}.profile-img{border-radius:1px;margin-bottom:1rem;border:3px solid #0d47a1;border-bottom:3px solid #0d47a1;border-right:3px solid #0d47a1}.profile-h .title{color:#ced4da;font-weight:600;letter-spacing:.04rem}.profile-h .position{font-weight:400;color:#ced4da;font-size:108%;text-transform:uppercase;letter-spacing:.09rem}.profile-h .twitter{font-size:90%;letter-spacing:.12rem;line-height:1rem;margin:0;color:#2196f3}@media (min-width:30em){.about-h .position,.profile-h .position{font-size:130%}}@media (min-width:52em){.about-h .position,.profile-img .profile-h .position{font-size:155%}}.cta-h{min-height:375px}#cta-1,#cta-2,#cta-3{color:#f8f9fa;max-height:25rem;overflow:hidden}#cta-1 .title,#cta-2 .title,#cta-3 .title{font-size:2rem;margin:1rem 0 .2rem -1px;font-weight:600;opacity:.95;word-spacing:.1rem}#cta-1 .textwidget,#cta-2 .textwidget,#cta-3 .textwidget{font-size:1.08rem}@media (min-width:52em){#cta-1 .title,#cta-2 .title,#cta-3 .title{font-size:2.9rem}.cta-h{min-height:475px}#cta-1,#cta-2,#cta-3{max-height:40rem;overflow:hidden}}.navbar{margin:0;padding:0;box-shadow:0 2px 6px 0 rgba(0,0,0,.12),inset 0 -1px 0 0 #e9ecef}.nav-logo svg{max-width:200px;padding-top:.6rem;margin-left:-.7rem;fill:#6c757d;opacity:.8}@media (max-width:50em){.nav-logo svg{max-width:175px}}@media (max-width:39.99em){.home .navbar svg{opacity:.8;fill:#ced4da}}.page-about .navbar svg,.page-template-page-faq .navbar svg,.single-unafactsheet .navbar svg,.single-unaprofile .navbar svg{fill:#ced4da;opacity:.9}.page-about .navbar,.page-template-page-faq .navbar,.single-unaprofile .navbar{background-color:transparent;box-shadow:0 2px 6px 0 rgba(0,0,0,.12),inset 0 -1px 0 0 #0d47a1}.single-unafactsheet .navbar{background-color:transparent;box-shadow:none}.home .navbar{background-color:transparent;box-shadow:0 2px 6px 0 rgba(0,0,0,.12),inset 0 -.1px 0 0 #0d47a1}@media (min-width:52em){.home .navbar{background-color:transparent;box-shadow:none}}.navbar-w{margin:0 auto;padding:.2rem 1.2rem;max-width:64em}.menu-b li,.menu-l li,.menu-p li,.menu-r li{list-style:none;font-size:.76rem;line-height:2.2rem;margin-top:.2rem;text-transform:uppercase;word-spacing:.2rem;letter-spacing:.1rem;font-weight:600}.navbar a:link,.navbar a:visited{color:#aaa}.menu-p a:link,.menu-p a:visited{color:#aaa;text-decoration:none}.menu-p a:active,.menu-p a:hover{color:#ccc;text-decoration:none}@media (min-width:52em){.menu-p li:not(:last-child){margin-right:2.2rem}}#navbar-sidebar{background-color:#f8f9fa;width:14rem}.navbar-x{color:#bbb;padding:.45rem 1rem 0}.navbar-btn{margin-bottom:.1rem;font-weight:500;padding:0 18px;line-height:29px;text-align:center;text-decoration:none;border:.7px solid #bbb;border-radius:2px;font-size:12px;float:right;color:#aaa}.navbar-btn:focus{color:#ccc}.navbar-btn-fill{background:transparent}.nav-accordion{margin-top:3rem}.nav-accordion section[expanded]{margin:1rem 0 2.7rem;background-color:inherit;color:#495057}.nav-accordion h4{border:none;color:#6c757d}.nav-accordion h4,.nav-accordion h4[expanded]{background-color:inherit}.nav-accordion h4:after{content:"";display:block;margin:.3rem 0;width:3rem;border-bottom:.15rem solid #ccc}.nav-accordion section:not([expanded]) h4{color:#828a91;background-color:inherit;margin:1.5rem 0}.nav-accordion section:not([expanded]) h4:after{border:none}.nav-accordion li a:link,li a:visited{font-weight:500;font-size:85%;color:#6c757d}.nav-accordion li a:hover{color:#1565c0}.pt-10{padding-top:10rem}.faq-layout{display:block}.faq-c h4{text-transform:none;letter-spacing:.01rem}.faq-wrap h2 a,.faq-wrap h4 a{color:#495057}.faq-wrap h2:after{content:"";display:block;height:1px;margin:.5rem auto 0;background:#e9ecef;bottom:0}.faq-c h5{letter-spacing:-.2px;font-size:1.2rem;line-height:1.65rem;font-weight:600}.faq-c h6{margin-top:4rem}.faq-c h6+h5{margin-top:.8rem}.faq-c h2+h6{margin-top:3rem}@media (min-width:52em){.faq-wrap{display:-ms-flexbox;display:flex;max-width:100%;margin:0 auto}.faq-side{display:block;position:relative;z-index:-2;margin-top:-8rem;padding-top:6rem;background-color:#fff;box-shadow:5px 0 5px -5px rgba(0,0,0,.4);min-width:170px}.nav-stick{top:0;padding:2rem;position:-webkit-sticky;position:sticky}}.shadow{text-shadow:0 1px 0 #000}.min-h{height:1px}hr{box-sizing:content-box;height:0;overflow:visible;margin:.1rem 0 1rem;border-width:0;border-top:1px solid #e9ecef}.lead{font-size:106%}@media (min-width:52em){.lead{font-size:1.13rem}}.container{max-width:64em}.container,.container-65{margin-left:auto;margin-right:auto}.container-65{max-width:65em}.container-72{max-width:72em}.container-72,.container-xl{margin-left:auto;margin-right:auto}.container-xl{max-width:1800px}.icon-flex{color:#e9ecef;padding:2rem 0 0 1rem;display:-ms-flexbox;display:flex}.icon-flex h3{margin-top:0;color:#dee2e6}.icon-fx-tx{font-size:93%;line-height:1.4rem;padding:0 1rem}.z200{z-index:200}.subhead-r:after{content:"";display:block;margin:1.2rem 0 1.2rem auto;height:2px;width:3rem;background:#1e88e5;bottom:0}@media (max-width:52em){.subhead-r:after{margin:1.2rem 0 1.2rem auto}}.subhead-l:after{margin:.8rem 0}.subhead-c2:after,.subhead-c:after,.subhead-l:after{content:"";display:block;height:2px;width:3rem;background:#1e88e5;bottom:0}.subhead-c2:after,.subhead-c:after{margin:.55rem auto .7rem}.subhead-c2:after{background:#42a5f5}@media (max-width:52em){.sm-subhead-l:after{margin:.8rem 0;background:#1e88e5}}.subhead-l2:after{background:#42a5f5}.subhead-l3:after{background:#dee2e6;margin-bottom:1.5rem}.spacer{padding:0 0 14rem;height:400px}.web-wrap{margin-top:-12rem}.web{margin-top:-10rem;padding:17rem 1rem 10rem}

</style></head><body class="unafactsheet-template-default single single-unafactsheet postid-4722 logged-in wp-custom-logo">
<amp-analytics type="googleanalytics">
<script type="application/json">
{
"vars": {
"account": "UA-74732283-10"
},
"triggers": {
"trackPageview": {
  "on": "visible",
  "request": "pageview"
},
"trackEvent": {
  "selector": "#event-test",
  "on": "click",
  "request": "event",
  "vars": {
    "eventCategory": "ui-components",
    "eventAction": "click"
  }
}
}
}
</script>
</amp-analytics> <!-- Google Analytics end -->
<header id="navbar" class="navbar navbar-primary">



<div class="navbar-w flex items-center justify-center">


<button aria-label="open sidebar" id="btn-id" on="tap:navbar-sidebar.toggle" tabindex="0" class="mt-05 navbar-btn navbar-btn-fill md-hide lg-hide flex-item mr-auto">☰
</button> <!-- .button -->

<div id="target-element-right" class="toolbar-target-shown">
</div> <!-- .lg menu-primary -->
</div> <!-- .wrap -->
</header>

<!-- Responsive sidebar menu  -->
<amp-sidebar id="navbar-sidebar" layout="nodisplay" class="md-hide lg-hide" side="left">
<div class="">    <!-- menu content -->
  <div role="button" aria-label="close sidebar" on="tap:navbar-sidebar.toggle" tabindex="0" class="navbar-x">✕</div>
</div>

<nav toolbar="(min-width:52em)" toolbar-target="target-element-right">
   <ul id="menu-primary" class="menu-p"><li id="menu-item-1453" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1453"><a href="<?php echo get_home_url(); ?>">Legislation</a></li>
     <li id="menu-item-1454" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1454"><a href="<?php echo get_home_url(); ?>">Issues</a></li>
     <li id="menu-item-1454" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1454"><a href="<?php echo get_home_url(); ?>">News</a></li>
<li id="menu-item-1455" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-1455"><a href="<?php echo get_home_url(); ?>">Alerts</a></li>
<li id="menu-item-2182" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2182"><a href="<?php echo get_home_url(); ?>">About</a></li>
</ul>       </nav>
</amp-sidebar> <!-- .sidebar -->


<main id="post-4722" class="psty-support"> <!-- .conditional  -->

<div class="poli-h">
  <div class="poli-iw">
    <div class="poli-i">
      <amp-img alt="policy background image" src="https://three-anchor.com/wp-content/themes/threeanchor/img/logos/factsheet-bg-image10a.jpg" height="628" width="1200" layout="responsive"></amp-img>
      </div>
    </div>

      <header class="container poli-hh sm-pt-2 md-pt-1 md-pb-1 lg-pt-1 md lg-pb-2">
        <div class="clearfix">
          <div class="sm-col-9 md-col-9 lg-col-9 mx-auto">
            <h1 class="title">The TRACED Act</h1>
          </div>  <!-- .col -->
        </div>  <!-- .row -->
      </header>  <!-- .sub -->
    </div>  <!-- .poli-h rel -->


<div class="clearfix">  <!-- rel wrap  -->
  <div class="container">
    <div class="col-12 sm-col-11 md-col-12 lg-col-12 mx-auto snap-w">
      <div class="snap lg-pt-1">
        <div class="snap-h"></div><!-- .head -->

<div class="lg-px-2">
<div class="snap-m">
<div class="snap-s1">

  <div>
      <h5 class="cat">Policy</h5>


   <div class="date">
     <div class="dt">Updated:</div>
     <div class="dd">March 10, 2020</div>
  </div>


          <h3 class="title bar">Telephone Robocall Abuse Criminal Enforcement and Deterrence Act</h3>
   <!-- .title -->
</div>    <!-- .cat/d/t -->


<div class="bg-des">
                <h6 class="label">Description</h6>
       <div class="snap-ex">Consumer protection law that expands fines, penalties and enforcement tools for abusive telemarketing practices, robocalls and caller-ID "spoofing".</div>
       </div>

</div>  <!-- .s1 -->

<div class="snap-s2">

  <div>
      <h6 class="label">Details</h6>
               <div class="flex col-12 dl-fx-2 items-center">
        <div class="dl-fx-i"><i class="material-icons pol">description</i></div>
        <div><h6>Number</h6><span>P.L. 116-105</span></div>
      </div>


      <div class="flex col-12 dl-fx-2 items-center">
        <div class="dl-fx-i"><i class="material-icons pol">account_balance</i></div>
        <div><h6>Category</h6>
          <span>Federal</span>
      </div>
    </div>
    <!-- .federal -->

    <!-- .2 -->

        <div class="flex col-12 dl-fx-2 items-center">
    <div class="dl-fx-i"><i class="material-icons pol">today</i></div>
    <div><h6>Year</h6><span>2019</span></div>
  </div>
    <!-- .3 -->

   <!-- .4 -->

        <div class="flex col-12 dl-fx-2 items-center">
    <div class="dl-fx-i"><i class="material-icons pol">people</i></div>
    <div><h6>Sponsors</h6><span>Sen. John Thune, Rep. Frank Pallone</span></div>
  </div>
    <!-- .5 -->

    </div>
 </div> <!-- .s2 -->
</div>   <!-- .m -->
</div>

<div class="lg-px-2 lg-pb-1">
<div class="snap-fw">
  <div class="snap-f1 order-2">
    <div class="snap-v">
      <div>
        <h6 class="label">


              Our Position</h6>
              Under Review</div>


            <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-m3.svg" width="26" height="26" sizes="(max-width: 50em) 42px, (max-width: 80em) 60px, 60px" alt="policy review"></amp-img>

          </div>

          <!-- .position-->

    </div>  <!-- .f1 -->

    <div class="snap-f2 order-1">

       <div class="snap-s">

<ul>
<li>
<a rel="nofollow" aria-label="Facebook Share" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="23.6" viewbox="0 0 53 49"><title>Facebook Share</title><path d="M47.5 43c0 1.2-.9 2.1-2.1 2.1h-10V30h5.1l.8-5.9h-5.9v-3.7c0-1.7.5-2.9 3-2.9h3.1v-5.3c-.6 0-2.4-.2-4.6-.2-4.5 0-7.5 2.7-7.5 7.8v4.3h-5.1V30h5.1v15.1H10.7c-1.2 0-2.2-.9-2.2-2.1V8.3c0-1.2 1-2.2 2.2-2.2h34.7c1.2 0 2.1 1 2.1 2.2V43" class="icon-social fb" style="fill-opacity:.9"></path></svg></a>
</li>
<li>
  <a rel="nofollow" target="_blank" aria-label="Twitter Share" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="24.4" height="22.6" viewbox="0 0 53 49">
  <title>Twitter Share</title>
  <path d="M45 6.9c-1.6 1-3.3 1.6-5.2 2-1.5-1.6-3.6-2.6-5.9-2.6-4.5 0-8.2 3.7-8.2 8.3 0 .6.1 1.3.2 1.9-6.8-.4-12.8-3.7-16.8-8.7C8.4 9 8 10.5 8 12c0 2.8 1.4 5.4 3.6 6.9-1.3-.1-2.6-.5-3.7-1.1v.1c0 4 2.8 7.4 6.6 8.1-.7.2-1.5.3-2.2.3-.5 0-1 0-1.5-.1 1 3.3 4 5.7 7.6 5.7-2.8 2.2-6.3 3.6-10.2 3.6-.6 0-1.3-.1-1.9-.1 3.6 2.3 7.9 3.7 12.5 3.7 15.1 0 23.3-12.6 23.3-23.6 0-.3 0-.7-.1-1 1.6-1.2 3-2.7 4.1-4.3-1.4.6-3 1.1-4.7 1.3 1.7-1 3-2.7 3.6-4.6" class="icon-social twitter" style="fill-opacity:.9"></path></svg></a>
  </li>
<li><a href="#" target="_blank" aria-label="Email share">
  <svg xmlns="http://www.w3.org/2000/svg" width="25" height="19" viewbox="0 0 56 43">
    <title>Email Share</title>
    <path d="M10.5 6.4C9.1 6.4 8 7.5 8 8.9v21.3c0 1.3 1.1 2.5 2.5 2.5h34.9c1.4 0 2.5-1.2 2.5-2.5V8.9c0-1.4-1.1-2.5-2.5-2.5H10.5zm2.1 2.5h30.7L27.9 22.3 12.6 8.9zm-2.1 1.4l16.6 14.6c.5.4 1.2.4 1.7 0l16.6-14.6v19.9H10.5V10.3z" class="icon-social mail" style="fill-opacity:.9"></path></svg></a>
  </li>
</ul>
       </div>  <!-- .so-->

      </div>  <!-- .f2 -->
    </div>   <!-- .fw -->
  </div>   <!-- .lg -->

</div> <!-- .snap -->
</div> <!-- .snap-w -->
</div>  <!-- .con -->
</div>    <!-- .rel -->



<section class="post-w">
<div class="clearfix container">
  <div class="col-11 sm-col-10 md-col-8 lg-col-7 px-w mx-auto post-c content factsheet-c">
  <h2 class="pt-1">Robocall abuse</h2>
<p>The TRACED Act is the first federal law designed to curb robocalls and &#8220;spoofing&#8221; — where telemarketers disguise calls to appear to come from trusted numbers. The law was passed with broad, bipartisan support and signed into law by President Trump.</p>
<ul>
<li>There are <strong>5 billion robocalls</strong> in the U.S. each month</li>
<li>Nearly <strong>65-70% of Americans ignore calls</strong> from unrecognized numbers</li>
<li>The Federal Trade Commission receives <strong>200,000 consumer complaints</strong> regarding robocalls each month</li>
</ul>
<h2>FCC enforcement tools</h2>
<p>The TRACED Act directs the FCC to strengthen protections against robocalls and caller-ID spoofing.  Under the law, telemarketers can now face a $10,000 fine per call. It also requires the Department of Justice and the FCC to create an interagency working group to research existing telemarketing laws, regulations and enforcement tools, and provide Congress with ongoing policy recommendations.</p>
<blockquote><p>Robocall scams are more than just a nuisance to folks, they&#8217;re a shameful tactic to prey on the vulnerable.</p>
<footer>&#8211;<strong>Sen. John Thune</strong> (R—S.D)</footer>
</blockquote>
<h3>Consumer protections &#038; &#8220;spoofing&#8221;</h3>
<p>The Trace Act also requires voice service providers to implement call authentication technology to address &#8220;spoofing&#8221;. The law prevents carriers from charging consumers for anti-spoofing technology relating to this legislation.</p>
<blockquote class="brand"><p>
&#8220;The Federal Communications Commission (FCC) shall promulgate rules establishing when a provider may block a voice call based on information provided by the call authentication framework&#8230; The FCC shall also initiate a rulemaking to help protect a subscriber from receiving unwanted calls or texts from a caller using an unauthenticated number.&#8221;</p>
<footer>-TRACED Act (P.L. 116-105)</footer>
</blockquote>
 </div>  <!-- .col -->
</div>

<div class="clearfix container">    <!-- byline -->
<div class="col-11 sm-col-10 md-col-9 lg-col-8 px-w mx-auto">
  <div class="byline">
    <hr>
    <div class="clearfix mx-auto">
      <div class="md-col md-col-7 lg-col-6">
        <div class="clearfix">  <!-- media object -->
          <h5 class="label">Share</h5>
          <div class="snap-s">

<ul>
<li>
<a rel="nofollow" aria-label="Facebook Share" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="23.6" viewbox="0 0 53 49"><title>Facebook Share</title><path d="M47.5 43c0 1.2-.9 2.1-2.1 2.1h-10V30h5.1l.8-5.9h-5.9v-3.7c0-1.7.5-2.9 3-2.9h3.1v-5.3c-.6 0-2.4-.2-4.6-.2-4.5 0-7.5 2.7-7.5 7.8v4.3h-5.1V30h5.1v15.1H10.7c-1.2 0-2.2-.9-2.2-2.1V8.3c0-1.2 1-2.2 2.2-2.2h34.7c1.2 0 2.1 1 2.1 2.2V43" class="icon-social fb" style="fill-opacity:.9"></path></svg></a>
</li>
<li>
  <a rel="nofollow" target="_blank" aria-label="Twitter Share" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="24.4" height="22.6" viewbox="0 0 53 49">
  <title>Twitter Share</title>
  <path d="M45 6.9c-1.6 1-3.3 1.6-5.2 2-1.5-1.6-3.6-2.6-5.9-2.6-4.5 0-8.2 3.7-8.2 8.3 0 .6.1 1.3.2 1.9-6.8-.4-12.8-3.7-16.8-8.7C8.4 9 8 10.5 8 12c0 2.8 1.4 5.4 3.6 6.9-1.3-.1-2.6-.5-3.7-1.1v.1c0 4 2.8 7.4 6.6 8.1-.7.2-1.5.3-2.2.3-.5 0-1 0-1.5-.1 1 3.3 4 5.7 7.6 5.7-2.8 2.2-6.3 3.6-10.2 3.6-.6 0-1.3-.1-1.9-.1 3.6 2.3 7.9 3.7 12.5 3.7 15.1 0 23.3-12.6 23.3-23.6 0-.3 0-.7-.1-1 1.6-1.2 3-2.7 4.1-4.3-1.4.6-3 1.1-4.7 1.3 1.7-1 3-2.7 3.6-4.6" class="icon-social twitter" style="fill-opacity:.9"></path></svg></a>
  </li>
<li><a href="#" target="_blank" aria-label="Email share">
  <svg xmlns="http://www.w3.org/2000/svg" width="25" height="19" viewbox="0 0 56 43">
    <title>Email Share</title>
    <path d="M10.5 6.4C9.1 6.4 8 7.5 8 8.9v21.3c0 1.3 1.1 2.5 2.5 2.5h34.9c1.4 0 2.5-1.2 2.5-2.5V8.9c0-1.4-1.1-2.5-2.5-2.5H10.5zm2.1 2.5h30.7L27.9 22.3 12.6 8.9zm-2.1 1.4l16.6 14.6c.5.4 1.2.4 1.7 0l16.6-14.6v19.9H10.5V10.3z" class="icon-social mail" style="fill-opacity:.9"></path></svg></a>
  </li>
</ul>
          </div>  <!-- .so-->
        </div>
      </div>
      <div class="md-col md-col-7 lg-col-6">
        <div class="clearfix">  <!-- tag -->
            <div class="tags"><h5 class="label">Tagged </h5><a href="#" rel="tag">FTC</a> <a href="#" rel="tag">Robocalls</a> <a href="#" rel="tag">TRACED Act</a></div>
        </div>
      </div>
    </div>  <!--  .clear -->
  </div>
</div> <!-- col -->
</div> <!-- clearfix -->
</section>


<!-- More Content
–––––––––––––––––––––––––––––––––––––––––––––––––– -->
<div class="bg-w2 pt-4 pb-2">
  <div class="container clearfix">
    <h3 class="col-12 sm-col-11 md-col-12 tx-g7 mx-auto pr-08 pl-08">Trending</h3>

    <section class="entry"> <!-- bg -->
        <div class="container clearfix py-w pr-08 pl-08"> <!-- fx-con -->
          <div class="md-flex lg-flex flex-wrap card-shadow justify-between"> <!-- fx-row -->

            <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto under support">
              <div class="head support">
                <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-y.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy support"></amp-img>
                </div> <!-- .h -->
                  <div class="body">
                    <h6 class="date">Policy</h6>
                    <h3 class="title"><a href="#">Agriculture Appropriations Act</a></h3>
                    <p class="excerpt">A year-long funding package for federal agriculture and nutrition programs, which includes $23.5 billion for rural development, food safety and the FDA.</p>
                  </div> <!-- .b -->
                  <footer>
                    <div class="tresfx">
                      <div class="it">
                        <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                      </div>
                      <div class="it">
                    <div><i class="material-icons tres">description</i>S. 2522</div>
                  <div><i class="material-icons tres">account_balance</i>Federal
                  </div>
                   </div>  <!-- .it -->
                  </div> <!-- .tres -->
                </footer>
              </article>

            <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto under support">
                  <div class="head support">
                    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-y.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy review"></amp-img>
                      </div> <!-- .h -->
                      <div class="body">
                    <h6 class="date">Policy</h6>
                    <h3 class="title"><a href="#">Financial Services Innovation Act</a></h3>
                    <p class="excerpt">Bill to streamline coordination among financial services regulators and support new entrants.</p>
                  </div> <!-- .b --><footer>
                    <div class="tresfx">
                      <div class="it">
                        <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                      </div>
                      <div class="it">
                          <div><i class="material-icons tres">description</i>
                            H.R. 4767</div>
                            <div><i class="material-icons tres">account_balance</i>
                              Federal
                            </div>
                          </div>  <!-- .it -->
                            </div> <!-- .tres -->
                          </footer>
                        </article>

            <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto under review"> <!-- .conditional -->
            <div class="head review">
              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-m3.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy support"></amp-img>
                      </div> <!-- .h -->
                      <div class="body">
                     <h6 class="date"> Vote Recommendation</h6>
                    <h3 class="title"><a href="#">Lymphedema Treatment Act</a></h3>
                    <p class="excerpt">Medicare reform proposal to extend Part B coverage for certain lymphedema compression treatments as durable medical equipment.</p>
                  </div> <!-- .b --><footer>
                    <div class="tresfx">
                      <div class="it">
                        <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                      </div>
                      <div class="it">
                          <div><i class="material-icons tres">description</i>
                            H.R. 1948</div>
                            <div><i class="material-icons tres">account_balance</i>
                              Federal
                            </div>
                          </div>  <!-- .it -->
                            </div> <!-- .tres -->
                          </footer>
                        </article>



                        <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto under review"> <!-- .conditional -->
                          <div class="head review">
                            <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-m3.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy support"></amp-img>
                              </div> <!-- .h -->
                              <div class="body">
                                <h6 class="date">Vote Recommendation</h6>
                                <h3 class="title"><a href="#">Calif. Cannabis Banking Bill, SB-51</a></h3>
                                <p class="excerpt">California legislation to integrate legal cannabis businesses into the banking system and authorize state-issued banking licenses.</p>
                              </div> <!-- .b -->
                              <footer>
                                <div class="tresfx">
                                  <div class="it">
                                    <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                                  </div>
                                  <div class="it">
                                      <div><i class="material-icons tres">description</i>
                                        SB-51</div>
                                        <div><i class="material-icons tres">account_balance</i>
                                      California
                                        </div>
                                      </div>  <!-- .it -->
                                        </div> <!-- .tres -->
                                      </footer>
                                    </article>


            <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto under review"> <!-- .conditional -->
              <div class="head review">
                <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-m3.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy support"></amp-img>
                  </div> <!-- .h -->
                  <div class="body">
                    <h6 class="date">Policy</h6>
                    <h3 class="title"><a href="#">Lower Health Care Costs Act</a></h3>
                    <p class="excerpt">Bipartisan healthcare legislation to promote healthcare billing transparency, restrict 'surprise billing', and improve access to generic drugs.</p>
                  </div> <!-- .b -->
                  <footer>
                    <div class="tresfx">
                      <div class="it">
                        <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                      </div>
                      <div class="it">
                          <div><i class="material-icons tres">description</i>
                            S. 1895</div>
                            <div><i class="material-icons tres">account_balance</i>
                              Federal
                            </div>
                          </div>  <!-- .it -->
                            </div> <!-- .tres -->
                          </footer>
                        </article>



                <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto support"> <!-- .conditional -->
                  <div class="head support">
                    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-y.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy support"></amp-img>
                  </div> <!-- .h -->
                <div class="body">
                  <h6 class="date"> Vote Recommendation</h6>
                  <h3 class="title"><a href="#">Tax Cuts and Jobs Act of 2019</a></h3>
                  <p class="excerpt">Bipartisan tax law that reduced tax brackets, lowered tax rates, streamlined deductions and eliminated personal exemptions.</p>
                </div> <!-- .b -->
                <footer>
                          <div class="tresfx">
                            <div class="it">
                              <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                            </div>

                            <div class="it">

                                <div><i class="material-icons tres">description</i>
                                  P.L. 115–97</div>


                                  <div><i class="material-icons tres">account_balance</i>
                                    Federal
                                  </div>

                                                            </div>  <!-- .it -->
                                  </div> <!-- .tres -->
                                </footer>
                              </article>


            <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto oppose"> <!-- .conditional -->
              <div class="head oppose">
                <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-n.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy oppose"></amp-img>
              </div> <!-- .h -->

                    <div class="body">
                    <h6 class="date"> Vote Recommendation</h6>
                    <h3 class="title"><a href="#">The GROW Act</a></h3>
                    <p class="excerpt">Multiemployer pension reform proposal that would authorize defined benefits and contribution retirement plans.</p>
                  </div> <!-- .b -->
                  <footer>
                    <div class="tresfx">
                      <div class="it">
                        <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                      </div>

                      <div class="it">

                          <div><i class="material-icons tres">description</i>
                            H.R. 4997</div>

                            <div><i class="material-icons tres">account_balance</i>
                              Federal
                            </div>
                              </div>  <!-- .it -->
                            </div> <!-- .tres -->
                          </footer>
                        </article>

                        <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto oppose"> <!-- .conditional -->
                          <div class="head oppose">
                            <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-n.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy oppose"></amp-img>
                          </div> <!-- .h -->

                                <div class="body">
                                <h6 class="date">Policy</h6>
                                <h3 class="title"><a href="#">Texas Hemp Law</a></h3>
                                <p class="excerpt">Legislation authorizing Texas hemp production, distribution and sales–with oversight from the Texas Department of Agriculture.</p>
                              </div> <!-- .b -->
                              <footer>
                                <div class="tresfx">
                                  <div class="it">
                                    <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                                  </div>

                                  <div class="it">

                                      <div><i class="material-icons tres">description</i>
                                        HB-1325</div>

                                        <div><i class="material-icons tres">account_balance</i>
                                          Texas
                                        </div>
                                          </div>  <!-- .it -->
                                        </div> <!-- .tres -->
                                      </footer>
                              </article>

                    </div>  <!-- .fx-rowf -->
                  </div> <!--  fx-con -->
                </section>
            </div>
          </div>
        </main>


<aside id="cta-1">
    <div class="container">
      <div class="col-12 sm-col-11 md-col-9 lg-col-7 mx-auto">
        <div class="cta-h flex flex-wrap content-center px-w">
            <h2 class="title">Policy loren</h2>
            <p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunua.</p>
            <a class="btn-p5 btn-lg btn-block" href="<?php echo get_home_url(); ?>/about/">LOREN LI &raquo;</a>
        </div>
      </div>
    </div>
</aside>



<footer id="footer" class="bg-pg">
  <div class="">
      <div class="footer-bw bg-g5 pb-2">
        <div class="container pt-3">
            <ul class="list-inline tx-c mb-0 ml-1">
<li class="mb-0 mr-05">
  <a href="#" target="_blank" class="inline-block" aria-label="Link to Facebook">
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="23.6" viewbox="0 0 53 49">
  <title>Facebook</title><path d="M47.5 43c0 1.2-.9 2.1-2.1 2.1h-10V30h5.1l.8-5.9h-5.9v-3.7c0-1.7.5-2.9 3-2.9h3.1v-5.3c-.6 0-2.4-.2-4.6-.2-4.5 0-7.5 2.7-7.5 7.8v4.3h-5.1V30h5.1v15.1H10.7c-1.2 0-2.2-.9-2.2-2.1V8.3c0-1.2 1-2.2 2.2-2.2h34.7c1.2 0 2.1 1 2.1 2.2V43" class="icon-style icon-fb" style="fill:#ddd;fill-opacity:.8">
  </path></svg></a>
</li>
<li class="mb-0">
  <a href="#" target="_blank" class="inline-block" aria-label="Link to Twitter">
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="22.2" viewbox="0 0 53 49">
  <title>Twitter</title>
  <path d="M45 6.9c-1.6 1-3.3 1.6-5.2 2-1.5-1.6-3.6-2.6-5.9-2.6-4.5 0-8.2 3.7-8.2 8.3 0 .6.1 1.3.2 1.9-6.8-.4-12.8-3.7-16.8-8.7C8.4 9 8 10.5 8 12c0 2.8 1.4 5.4 3.6 6.9-1.3-.1-2.6-.5-3.7-1.1v.1c0 4 2.8 7.4 6.6 8.1-.7.2-1.5.3-2.2.3-.5 0-1 0-1.5-.1 1 3.3 4 5.7 7.6 5.7-2.8 2.2-6.3 3.6-10.2 3.6-.6 0-1.3-.1-1.9-.1 3.6 2.3 7.9 3.7 12.5 3.7 15.1 0 23.3-12.6 23.3-23.6 0-.3 0-.7-.1-1 1.6-1.2 3-2.7 4.1-4.3-1.4.6-3 1.1-4.7 1.3 1.7-1 3-2.7 3.6-4.6" class="icon-style icon-twitter"  style="fill:#ddd;fill-opacity:.8">
  </path></svg></a>
</li>
</ul>
          <h6 class="tx-c tx-g4 pt-05">Copyright &copy; 2020</h6>
      </div>
      </div>
    </div> <!-- .footer-b  -->
  </footer> <!-- .footer-p  -->
  </body>
</html>
