<?php
/**
 * Template Name: Plugins
 *
 */
?>

<?php get_header(''); ?>

  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

  <main id="post-<?php the_ID(); ?>">
    <div class="plugin-wrap">

    <header class="bg-pg plugin-h bg-cut-r">
      <div class="h-jpg">
        <div class="plugin-h-bg">
              <div class="container">
                <div class="hero-flex col-11 sm-col-9 md-col-7 lg-col-7 full-h mx-auto">
                  <?php the_title( '<h1 class="title tx-center subhead-c">', ' </h1>' ); ?>
                  <?php if (has_excerpt( $post->ID ) ): ?>
                    <div class="tx-center lead"><?php echo wp_strip_all_tags( get_the_excerpt(), true ); ?></div>
                  <?php endif; ?>
                </div>  <!-- .col  -->
              </div>  <!-- .con  -->
        </div> <!-- background -->
      </div> <!-- full -->
    </header>


        <?php if (is_page( array( 'about-me' , 'Contact' ) ) ) {
          ?>
        <section class="page-w">
          <div class="container">
              <div class="clearfix">
                <div class="sm-col-12 md-col-9 lg-col-7 mx-auto contact-w"> <!--  .wrap -->
                  <div class="page-c content div-shadow"> <!--  .card -->
                    <div class="col-12 sm-col-12 md-col-10 lg-col-11 contact-body mx-auto sm-mx-auto">  <!--  .body -->
                <!-- .form -->
                <?php the_content(); ?>
                </div>
            </div>
          </div>  <!--  .sm-11 -->
        </div>  <!--  .sm-11 -->
      </div>
    </section>


        <?php }
        else {?>

      <section class="page-w">
          <div class="container">
              <div class="clearfix">
                 <div class="col-11 sm-col-10 md-col-8 lg-col-7 mx-auto page-c content">
                   <?php the_content(); ?>
                </div>  <!-- column end -->
              </div> <!-- clearfix end -->
            </div>
        </section>

          <?php }
          ?>

    </div>
  </main>     <!-- page wrap -->
    <?php endwhile; endif; ?>

<?php get_footer(); ?>
