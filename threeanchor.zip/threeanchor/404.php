<?php get_header( 'amp' ); ?>

<div class="four">
	<header class="clearfix">
		<div class="sm-col-12 md-col-9 lg-col-8 mx-auto">
			<h1 class="pg-title">404 Problem</h1>
		</div>
	</header>
	    <?php get_template_part( 'templates/content', 'none' ); ?>
</div>
	<?php get_sidebar( '1' ); ?>

<?php get_footer(); ?>
