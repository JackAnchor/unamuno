<?php
/**
 *
 * Background color: .about-h
 * Background image: .about-h-bg
 * AMP prohibits z-index application to navbar
 * Negative z-index required for hero to "slide under" navbar
 * Navbar cannot be styled without "slide under"
 * Hero buttons/links do not work with negative z-index
 * Body container must "slide over" hero content to enable links
 * Sidebar nav must be positioned to work properly
 * Section slides under hero (negative margins, cut + background), via relative + z-index
 * Section-sub (texture, relative z9, padding)
 * section class="mt-n3 lg-mt-n5 bg-cut-ly bg-w1">
 */
?>

<?php get_header('amp'); ?>

  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

<main id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
   <header class="about-h bg-cut-r">
     <div class="bg-w2">
      <div class="container">
        <div class="hero-flex col-11 sm-col-9 md-col-7 lg-col-7 full-h mx-auto">
            <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/logo-threeanchor-login-3.svg" alt="threeanchor logo" class="mx-auto pb-2" width="28" height="28" sizes="(max-width: 52em) 90px,(max-width: 64em) 110px, 110px"></amp-img>
          <?php if (has_post_thumbnail( $post->ID ) ): ?>
            <amp-img src="<?php the_post_thumbnail_url(); ?>" title="<?php the_title_attribute(); ?>" height="628" width="1200" layout="responsive"></amp-img>
          <?php endif; ?>
          <?php the_title( '<h1 class="title subhead-c2">', '</h1>' ); ?>
          <?php if (has_excerpt( $post->ID ) ): ?>
            <div class="lead tx-c"><?php echo wp_strip_all_tags( get_the_excerpt(), true ); ?></div>
          <?php endif; ?>
        </div>   <!-- .fx-col -->
      </div>   <!-- .row -->
    </div> <!-- .bg -->
  </header> <!-- .hero/cut/color -->

    <!-- Website
    ––––––––––––––––––––––––––––––––––––––––––––––––––  -->
    <section class="mt-n3 lg-mt-n11 bg-cut-ly bg-w1">
    <div class="website">
     <div class="lg-pt-3 lg-pb-2">
      <div class="container pb-4">
         <div class="clearfix">
           <div class="flex flex-wrap justify-between content-center">
             <div class="col-12 sm-col-9 md-col-6 lg-col-6 pt-1 pr-0 pl-05 mx-auto md-order-last">
               <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/policy-screenshot.png" alt="policy post webpage template" class="mx-auto" width="2000" height="1600" layout="responsive"></amp-img>
               <div class="caption tx-g5 tx-r mr-1">Policy Template</div>
                </div> <!-- .fx-col -->
                <div class="col-12 sm-col-10 md-col-6 lg-col-5">
                  <div class="lg-pt-4 lg-pr-1 lg-pl-1">
                     <h6 class="tx-p4 mb-1 pt-3">Political Websites</h6>
                     <h2 class="title subhead-l">Mobile-focused</h2>
                     <p>Leverage clean, clear message-driven websites — optimized for mobile users and search engine rankings.</p>
                     <a class="btn-p7 btn-md" href="<?php echo get_home_url(); ?>/about/faq/utilpolicy1/">See example &raquo;</a>
                </div> <!-- .card -->
             </div>  <!-- .fx-col-2 -->
             </div>  <!--  .fx- wrap -->
            </div>
          </div>

          <div class="container">
             <div class="clearfix">
               <div class="flex flex-wrap justify-between content-center">
                 <div class="col-12 sm-col-10 md-col-6 lg-col-6 mx-auto">
                   <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/petition-interface.png" alt="petition advocacy post" class="mx-auto" width="2500" height="2000" layout="responsive"></amp-img>
                    <div class="caption tx-g5 px-1 sm-tx-r">Petition Interface</div>
                  </div> <!-- .fx-col -->

                  <div class="col-12 sm-col-10 md-col-6 lg-col-5 mx-auto">
                      <div class="lg-pt-4 mb-2">
                       <h6 class="tx-p4 pt-2">Political Publishing</h6>
                       <h2 class="title subhead-l">More content, less work</h2>
                       <p>Accelerate content creation with fast, flexible publishing templates — intuitive, easy-to-use, and no orientation required.</p>
                       <a class="btn-p7 btn-md" href="<?php echo get_home_url(); ?>/about/faq/utilpolicy2/">Alternate style &raquo;</a>
                    </div> <!-- .card -->
                 </div>  <!-- .fx-col-2 -->
                 </div>  <!--  .fx- wrap -->
                </div>
              </div>
            </div>  <!--  .texture -->
          </div>
        </section>


<!-- screen 2 end -->

<!-- Process Start
–––––––––––––––––––––––––––––––––––––––––––––––––– -->

<section class="bg-cut-x mt-n10 bg-pg relative z">
<div class="process">
  <div class="container">
    <div class="clearfix mx-15">
      <div class="col-12 sm-col-10 md-col-10 lg-col-8 mx-auto">
        <h6 class="sm-tx-l tx-p3">PROCESS</h6>
        <h2 class="tx-g4 tx-h1 subhead-l subhead-l2 pb-1">Simple, streamlined process</h2>
        <div class="lead tx-g2 pb-4">Revamp your identity and relaunch your political website - <span class="italic">in six weeks.</span>  Our turn-key process is simple and efficient.</div>
      </div>

      <div class="col col-10 sm-col-8 md-col-12 lg-col-12 col-right sm-pr-2">
        <div class="steps-w md-flex flex-wrap tbl-shadow">
          <div class="lg-col-3 md-col-6 c-step card-shadow-l md-pb-2 sxs-bb md-bb md-br lg-br">
            <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/400/icon-map.svg" width="48" height="48" alt="organize icon" class="xs-mb-5 sm-mb-3 md-mb-3"></amp-img>
            <h4 class="mt-1">Plan</h4>
            <p class="">Finalize sitemap, structure and customization options.</p>
            <div class="details">Week 1</div>
          </div>

          <div class="lg-col-3 md-col-6 c-step sxs-bb md-bb lg-br">
            <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/400/icon-design.svg" width="48" height="48" alt="design icon" class="xs-mb-5 sm-mb-2 md-mb-3"></amp-img>
            <h4 class="mt-1">Design</h4>
            <p>Organize existing content, integrate brand specifications and details.</p>
            <div class="details">Week 3</div>
          </div>

          <div class="lg-col-3 md-col-6 c-step sxs-bb md-br lg-br">
            <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/400/icon-code.svg" width="52" height="52" alt="code icon" class="xs-mb-5 sm-mb-3 md-mb-3"></amp-img>
            <h4 class="mt-1">Develop</h4>
            <p>Finalize website optimizations, edits and enhancements.</p>
            <div class="details">Week 5</div>
          </div>

          <div class="lg-col-3 md-col-6 c-step">
            <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/400/icon-rocket.svg" width="51" height="51" alt="launch icon" class="xs-mb-5 sm-mb-2 md-mb-3"></amp-img>
            <h4 class="mt-1">Launch</h4>
            <p>Deploy site and provide ongoing technical support services.</p>
            <div class="details">Week 6</div>
          </div>
        </div> <!-- .flex -->

      </div> <!-- .col1 -->
      <div class="col col-1 sm-col-3 md-col-12 lg-col-12 mr-auto md-hide lg-hide">
        <div class="line-img">
          <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/line-process.svg" width="32" height="717.5" class="mx-auto" alt="line indicating process"></amp-img>
        </div>
      </div>  <!-- .col2 -->
    </div>   <!-- .row -->
  </div> <!-- .container -->
</div> <!-- .process -->
</section>


<!-- Tools
–––––––––––––––––––––––––––––––––––––––––––––––––– -->

<section class="bg-cut-x relative z1 mt-n10 bg-pg">
  <div class="tools">

        <div class="clearfix mx-05 lg-pt-4 pb-1">
          <div class="col-12 sm-col-10 md-col-8 lg-col-8 mx-auto">
            <h6 class="sm-tx-l tx-c tx-p3">Objectives</h6>
            <h2 class="tx-g4 tx-c tx-h1 sm-tx-l subhead-c2 sm-subhead-l">Reach your audience &amp; grow</h2>
          </div>
        </div>

    <div class="container lg-pt-1">
      <div class="sm-flex md-flex lg-flex flex-wrap lg-pb-2 border">
        <div class="col-11 sm-col-8 md-col-5 lg-col-4 mx-auto">
          <div class="icon-flex">
            <div>
              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/300/icon-timer-300.svg" width="36" height="36" alt="timer icon"></amp-img>
            </div>
            <div class="icon-fx-tx">
              <h3>Save time</h3>
              <p class="mt-02">Fast, flexible, intuitve— no orientation required.</p>
            </div>
          </div> <!-- .ico-fx  -->
          <div class="icon-flex">
            <div>
              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/300/icon-publish-300.svg" width="36" height="36" alt="publish icon"></amp-img>
            </div>
            <div class="icon-fx-tx">
              <h3>Publish</h3>
              <p class="mt-02">Produce more content with integrated tools and templates.</p>
            </div>
          </div> <!-- .ico-fx  -->
          <div class="icon-flex">
            <div>
              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/300/icon-cycle-300.svg" width="36" height="36" alt="cycle icon"></amp-img>
            </div>
            <div class="icon-fx-tx">
              <h3>Simplify</h3>
              <p class="mt-02">Build faster websites with pre-built infrastructure.</p>
            </div>
          </div> <!-- .ico-fx  -->
        </div> <!-- .flex col  -->

        <div class="col-11 sm-col-8 md-col-5 lg-col-4 mx-auto">
          <div class="icon-flex">
            <div>
              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/300/icon-bullet-300.svg" width="36" height="36" alt="search icon"></amp-img>
            </div>
            <div class="icon-fx-tx">
              <h3>Get found</h3>
              <p class="mt-02">Maximize visibility with Google best-practices and SEO.</p>
            </div>
          </div> <!-- .ico-fx  -->

          <div class="icon-flex">
            <div>
              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/300/icon-tools-300.svg" width="36" height="36" alt="wrench icon"></amp-img>
            </div>
            <div class="icon-fx-tx">
              <h3>Modernize</h3>
              <p class="mt-02">Make smarter decisions with Google Analytics &amp; strategic digital planning.</p>
            </div>
          </div> <!-- .ico-fx  -->
          <div class="icon-flex">
            <div>
              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/300/icon-chart-300.svg" width="36" height="36" alt="analytics icon"></amp-img>
            </div>
            <div class="icon-fx-tx">
              <h3>Fundraise</h3>
              <p class="mt-02">Engage donors and members with clean, clear, mobile-focused content.</p>
            </div>
          </div> <!-- .icon flex  -->
        </div> <!-- .flex col  -->
      </div> <!-- .flex wrap  -->
    </div> <!-- .container  -->
  </div> <!-- .tools -->
</section>




     <!-- News Start
     –––––––––––––––––––––––––––––––––––––––––––––––––– -->



     <section class="bg-w">
       <div class="updates texture">
          <div class="container">
            <div class="clearfix">
             <div class="col-12 sm-col-8 md-col-8 lg-col-7 mx-auto px-1">
             <h6 class="tx-c tx-p4">RESOURCES</h6>
             <h2 class="tx-g7 tx-c tx-h1 subhead-c2 pb-3">News &amp; updates</h2>
           </div>
         </div>
       <?php get_template_part( 'templates/content', 'homenews' ); ?>
        </div>
      </div>
   </section>
</main>

<!-- page end -->

   <?php endwhile; endif; ?>

     <?php get_sidebar( '2' ); ?>

<?php get_footer(); ?>
