<?php
/*
 * AMP Fonts
 *
 * Fonts are not enqued via Wordpress
 –––––––––––––––––––––––––––––––––––––––––––––––
 *
 */
?>
<link href="https://fonts.googleapis.com/css?family=Inconsolata|Montserrat:400,500,600,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
