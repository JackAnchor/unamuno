<?php
/**
 * The default template for factsheet posts
 * Flexbox
 */
?>

<?php get_header('amp'); ?>

  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

      <?php $meta = get_post_meta( $post->ID, 'unafactsheet_fields', true ); ?>

      <main id="post-<?php the_ID(); ?>" class="psty-<?php if( isset($meta['selectposition']) && $meta['selectposition'] != 'default') {
      echo strtolower($meta['selectposition']); } ?>"> <!-- .conditional  -->


    <div class="poli-h">
        <div class="poli-i">
          <amp-img alt="policy background image" src="<?php echo get_stylesheet_directory_uri() . '/img/logos/factsheet-bg-image11.jpg'; ?>" height="628" width="1200" layout="responsive"></amp-img>
        </div>

        <header class="absolute-hw poli-hh">
          <div class="container full-h">
              <div class="flex flex-column col-12 sm-col-11 md-col-10 lg-col-12 mx-auto justify-center full-h">
            <?php the_title( '<h1 class="title md-pt-1">', '</h1>' ); ?>
              </div>
          </div>
      </header>
    </div>  <!-- .poli-h -->

    <div class="clearfix">  <!-- rel wrap  -->
      <div class="container">
        <div class="col-12 sm-col-11 md-col-11 lg-col-12 mx-auto snap-w">
          <div class="snap lg-pt-00">
            <div class="snap-h"></div><!-- .head -->
             <div class="lg-px-1">
              <div class="snap-m">
                <div class="snap-s1">

      <div>
       <?php if ( isset($meta['checkboxvoterec']) && $meta['checkboxvoterec'] === 'checkbox') { ?>
         <!-- <i class="material-icons pfc">how_to_vote</i> -->
         <h5 class="cat">Vote Recommendation</h5>
       <?php } else { ?>
       <h5 class="cat">Policy</h5>

       <?php } ?>

       <div class="date">
         <div class="dt">Updated:</div>
         <div class="dd"><?php the_date(); ?></div>
      </div>
      </div>    <!-- .cat/d -->
      <div>
      <?php if (!empty($meta['text'])) { ?>
        <h3 class="title"><?php echo esc_attr($meta['text']); ?></h3>
      <?php } else { ?>
        <h3 class="title"><?php echo the_title(); ?></h3> <!-- .def -->
      <?php } ?> <!-- .title -->
    </div>    <!-- .cat/d/t -->


    <div class="bg-des">
         <?php if (has_excerpt( $post->ID ) ): ?>
          <h5 class="label">Description</h5>
           <div class="snap-ex"><?php echo wp_strip_all_tags( get_the_excerpt(), true ); ?></div>
         <?php endif; ?>
       </div>
     </div>  <!-- .s1 -->

     <div class="snap-s2">
       <div>
         <!-- <h6 class="label">Policy Details</h6> -->
         <?php
         // Bill number -->
         if (!empty($meta['text2'])): ?>
         <div class="flex col-12 dl-fx-2 items-center">
           <div class="dl-fx-i"><i class="material-icons pol">description</i></div>
           <div><h6>Number</h6><span><?php echo esc_attr($meta['text2']); ?></span></div>
         </div>
       <?php endif; ?>

       <?php
       // Government level  -->
       if ( isset($meta['selectgovt']) && $meta['selectgovt'] != 'default' && $meta['selectgovt'] != 'State' && $meta['selectgovt'] != 'Local') { ?>

         <div class="flex col-12 dl-fx-2 items-center">
           <div class="dl-fx-i"><i class="material-icons pol">account_balance</i></div>
           <div><h6>Category</h6>
             <span><?php echo $meta['selectgovt']; ?>
               <?php if ( isset($meta['selectstate']) && $meta['selectstate'] != 'default') { ?>— State of <?php echo $meta['selectstate']; ?>
             <?php } ?></span>
           </div>
         </div>
         <?php
         // End federal
       } ?>

     <?php if ( isset($meta['selectstate']) && $meta['selectstate'] != 'default') { ?>
       <?php if ( isset($meta['selectgovt']) && $meta['selectgovt'] != 'default' && $meta['selectgovt'] != 'Federal') { ?>
         <div class="flex col-12 dl-fx-2 items-center">
           <div class="dl-fx-i"><i class="material-icons pol">account_balance</i></div>
           <div><h6>Category</h6>
             <span><?php echo $meta['selectgovt']; ?>-level, <?php echo $meta['selectstate']; ?></span>
           </div>
         </div>
         <?php
         // End state/local
       }
       // End government level
     } ?>

     <?php
     // Year -->
     if (!empty($meta['selectyear'])): ?>
     <div class="flex col-12 dl-fx-2 items-center">
       <div class="dl-fx-i"><i class="material-icons pol">today</i></div>
       <div><h6>Year</h6><span><?php /* load default year */ echo $meta['selectyear']; ?></span></div>
     </div>
   <?php endif; ?>  <!-- .3 -->

   <?php
   // Scorecard -->
   if ( isset($meta['checkboxscore']) && $meta['checkboxscore'] === 'checkbox') { ?>
     <div class="flex col-12 dl-fx-2 items-center">
       <div class="dl-fx-i"><i class="material-icons pol">beenhere</i></div>
       <div><h6>Scorecard</h6><span>Yes</span></div>
     </div>
   <?php } ?> <!-- .4 -->

   <?php
   // Sponsors -->
   if (!empty($meta['text3'])): ?>
   <div class="flex col-12 dl-fx-2 items-center">
     <div class="dl-fx-i"><i class="material-icons pol">people</i></div>
     <div><h6>Sponsors</h6><span><?php echo esc_attr($meta['text3']); ?></span></div>
   </div>
 <?php endif; ?>  <!-- .5 -->

</div>
</div> <!-- .s2 -->
    </div>   <!-- .m -->
  </div>






  <div class="lg-px-1 lg-pb-1">
    <div class="snap-fw">
      <div class="snap-f1 order-2">
        <div class="snap-v">
          <?php if ( isset($meta['selectposition'])) { ?>
            <?php switch ( $meta['selectposition'] ) {

              case 'Support' : ?>

              <div class="head support">
                <h6 class="label">Our Position</h6>
                Support
              </div>
              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-y.svg" width="28" height="28" sizes="(max-width: 52em) 54px, (max-width: 64em) 42px, 70px" alt="policy support"></amp-img>

              <?php break;
              case 'Oppose' : ?>

              <div class="oppose">
                <h6 class="label">Our Position</h6>
                Oppose
              </div>
              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-n.svg" width="28" height="28" sizes="(max-width: 52em) 54px, (max-width: 64em) 42px, 70px" alt="policy oppose"></amp-img>

              <?php break;
              default : ?>

              <div class="review">
                <h6 class="label">Our Position</h6>
                <?php if ( isset($meta['selectposition']) && $meta['selectposition'] != 'default') { ?>
                  <?php echo $meta['selectposition']; ?>
                </div>
                <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-m.svg" width="28" height="28" sizes="(max-width: 52em) 54px, (max-width: 64em) 42px, 70px" alt="policy review"></amp-img>

              <?php } ?>  <!-- .default  -->
              <?php break;
            } ?>

          <?php } ?> <!-- .endif-->

        </div>  <!-- .v -->
      </div>  <!-- .f1 -->
      <div class="snap-f2 order-1">
          <div class="snap-s"><?php get_template_part( 'templates/components/social-unapost' ); ?></div>  <!-- .so-->
      </div>  <!-- .f2 -->
    </div>   <!-- .fw -->
  </div>   <!-- .lg -->

    </div> <!-- .snap -->
    </div> <!-- .snap-w -->
  </div>  <!-- .con -->
 </div>    <!-- .rel -->



  <section class="post-w">
    <div class="clearfix container">
      <div class="col-11 sm-col-10 md-col-8 lg-col-7 px-w mx-auto post-c content factsheet-c">
      <?php the_content(); ?>
     </div>  <!-- .col -->
   </div>

  <div class="clearfix container">    <!-- byline -->
    <div class="col-11 sm-col-10 md-col-8 lg-col-7 px-w mx-auto">
      <div class="byline">
        <hr>
        <div class="clearfix mx-auto">
          <div class="md-col md-col-7 lg-col-6">
            <div class="clearfix">  <!-- media object -->
              <h5 class="label">Share</h5>
              <div class="snap-s">
                 <?php get_template_part( 'templates/components/social-unapost' ); ?>
              </div>  <!-- .so-->
            </div>
          </div>
          <div class="md-col md-col-7 lg-col-6">
            <div class="clearfix">  <!-- tag -->
                <div class="tags"><?php the_tags( '<h5 class="label">Tagged </h5>', ' ', '' ); ?></div>
            </div>
          </div>
        </div>  <!--  .clear -->
      </div>
    </div> <!-- col -->
   </div> <!-- clearfix -->
</section>



    <!-- More Content
    –––––––––––––––––––––––––––––––––––––––––––––––––– -->
    <div class="bg-w2 pt-4 pb-2">
      <div class="container clearfix">
        <h3 class="col-12 sm-col-11 md-col-12 tx-g8 mx-auto py-w px-w">Trending</h3>

        <section class="entry"> <!-- bg -->
            <div class="container card-shadow clearfix py-w pr-08 pl-08"> <!-- fx-con -->
              <div class="md-flex lg-flex flex-wrap justify-between"> <!-- fx-row -->

                <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto under support">
                  <div class="head support">
                    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-y.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy support"></amp-img>
                  </div> <!-- .h -->
                  <div class="body">
                    <h6 class="date">Policy</h6>
                    <h3 class="title"><a href="#">Agriculture Appropriations Act</a></h3>
                    <p class="excerpt">A year-long funding package for federal agriculture and nutrition programs, which includes $23.5 billion for rural development, food safety and the FDA.</p>
                  </div> <!-- .b -->
                  <footer>
                    <div class="tresfx">
                      <div class="it">
                        <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                      </div>
                      <div class="it">
                        <div><i class="material-icons tres">description</i>S. 2522</div>
                        <div><i class="material-icons tres">account_balance</i>Federal
                        </div>
                      </div>  <!-- .it -->
                    </div> <!-- .tres -->
                  </footer>
                </article>

                <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto under support">
                  <div class="head support">
                    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-y.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy review"></amp-img>
                  </div> <!-- .h -->
                  <div class="body">
                    <h6 class="date">Policy</h6>
                    <h3 class="title"><a href="#">Financial Services Innovation Act</a></h3>
                    <p class="excerpt">Bill to streamline coordination among financial services regulators and support new entrants.</p>
                  </div> <!-- .b --><footer>
                    <div class="tresfx">
                      <div class="it">
                        <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                      </div>
                      <div class="it">
                        <div><i class="material-icons tres">description</i>
                          H.R. 4767</div>
                          <div><i class="material-icons tres">account_balance</i>
                            Federal
                          </div>
                        </div>  <!-- .it -->
                      </div> <!-- .tres -->
                    </footer>
                  </article>

                  <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto under review"> <!-- .conditional -->
                    <div class="head review">
                      <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-m3.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy support"></amp-img>
                    </div> <!-- .h -->
                    <div class="body">
                      <h6 class="date"> Vote Recommendation</h6>
                      <h3 class="title"><a href="#">Lymphedema Treatment Act</a></h3>
                      <p class="excerpt">Medicare reform proposal to extend Part B coverage for certain lymphedema compression treatments as durable medical equipment.</p>
                    </div> <!-- .b --><footer>
                      <div class="tresfx">
                        <div class="it">
                          <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                        </div>
                        <div class="it">
                          <div><i class="material-icons tres">description</i>
                            H.R. 1948</div>
                            <div><i class="material-icons tres">account_balance</i>
                              Federal
                            </div>
                          </div>  <!-- .it -->
                        </div> <!-- .tres -->
                      </footer>
                    </article>


                    <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto under review"> <!-- .conditional -->
                      <div class="head review">
                        <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-m3.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy support"></amp-img>
                      </div> <!-- .h -->
                      <div class="body">
                        <h6 class="date">Vote Recommendation</h6>
                        <h3 class="title"><a href="#">California Cannabis Banking Bill (SB-51)</a></h3>
                        <p class="excerpt">California legislation to integrate legal cannabis businesses into the banking system and authorize state-issued banking licenses.</p>
                      </div> <!-- .b -->
                      <footer>
                        <div class="tresfx">
                          <div class="it">
                            <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                          </div>
                          <div class="it">
                            <div><i class="material-icons tres">description</i>
                              SB-51</div>
                              <div><i class="material-icons tres">account_balance</i>
                                California
                              </div>
                            </div>  <!-- .it -->
                          </div> <!-- .tres -->
                        </footer>
                      </article>


                      <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto under review"> <!-- .conditional -->
                        <div class="head review">
                          <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-m3.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy support"></amp-img>
                        </div> <!-- .h -->
                        <div class="body">
                          <h6 class="date">Policy</h6>
                          <h3 class="title"><a href="#">Lower Health Care Costs Act</a></h3>
                          <p class="excerpt">Bipartisan healthcare legislation to promote healthcare billing transparency, restrict 'surprise billing', and improve access to generic drugs.</p>
                        </div> <!-- .b -->
                        <footer>
                          <div class="tresfx">
                            <div class="it">
                              <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                            </div>
                            <div class="it">
                              <div><i class="material-icons tres">description</i>
                                S. 1895</div>
                                <div><i class="material-icons tres">account_balance</i>
                                  Federal
                                </div>
                              </div>  <!-- .it -->
                            </div> <!-- .tres -->
                          </footer>
                        </article>



                        <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto support"> <!-- .conditional -->
                          <div class="head support">
                            <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-y.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy support"></amp-img>
                          </div> <!-- .h -->
                          <div class="body">
                            <h6 class="date"> Vote Recommendation</h6>
                            <h3 class="title"><a href="#">Tax Cuts and Jobs Act of 2019</a></h3>
                            <p class="excerpt">Bipartisan tax law that reduced tax brackets, lowered tax rates, streamlined deductions and eliminated personal exemptions.</p>
                          </div> <!-- .b -->
                          <footer>
                            <div class="tresfx">
                              <div class="it">
                                <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                              </div>

                              <div class="it">

                                <div><i class="material-icons tres">description</i>
                                  P.L. 115–97</div>


                                  <div><i class="material-icons tres">account_balance</i>
                                    Federal
                                  </div>

                                </div>  <!-- .it -->
                              </div> <!-- .tres -->
                            </footer>
                          </article>


                          <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto oppose"> <!-- .conditional -->
                            <div class="head oppose">
                              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-n.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy oppose"></amp-img>
                            </div> <!-- .h -->

                            <div class="body">
                              <h6 class="date"> Vote Recommendation</h6>
                              <h3 class="title"><a href="#">The GROW Act</a></h3>
                              <p class="excerpt">Multiemployer pension reform proposal that would authorize defined benefits and contribution retirement plans.</p>
                            </div> <!-- .b -->
                            <footer>
                              <div class="tresfx">
                                <div class="it">
                                  <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                                </div>
                                <div class="it">
                                  <div><i class="material-icons tres">description</i>
                                    H.R. 4997</div>

                                    <div><i class="material-icons tres">account_balance</i>
                                      Federal
                                    </div>
                                  </div>  <!-- .it -->
                                </div> <!-- .tres -->
                              </footer>
                            </article>

                            <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto oppose"> <!-- .conditional -->
                              <div class="head oppose">
                                <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-n.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy oppose"></amp-img>
                              </div> <!-- .h -->

                              <div class="body">
                                <h6 class="date">Policy</h6>
                                <h3 class="title"><a href="#">Texas Hemp Law</a></h3>
                                <p class="excerpt">Legislation authorizing Texas hemp production, distribution and sales–with oversight from the Texas Department of Agriculture.</p>
                              </div> <!-- .b -->
                              <footer>
                                <div class="tresfx">
                                  <div class="it">
                                    <a class="btn-outline btn-sm" role="button" href="#">READ MORE &raquo;</a>
                                  </div>
                                  <div class="it">
                                    <div><i class="material-icons tres">description</i>
                                      HB-1325
                                    </div>
                                    <div><i class="material-icons tres">account_balance</i>
                                      Texas</div>
                                    </div>  <!-- .it -->
                                  </div> <!-- .tres -->
                                </footer>
                              </article>
                        </div>  <!-- .fx-rowf -->
                      </div> <!--  fx-con -->
                  </section>
                </div>
              </div>
            </main>

    <?php endwhile; endif; ?>

    <aside id="cta-1">
        <div class="container">
          <div class="col-12 sm-col-11 md-col-9 lg-col-7 mx-auto">
            <div class="cta-h flex flex-wrap content-center px-w">
                <h2 class="title">Policy. It matters.</h2>
                <p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunua.</p>
                <a class="btn-p5 btn-lg btn-block" href="#">Take Action &raquo;</a>
            </div>
          </div>
        </div>
    </aside>



    <footer id="footer" class="bg-w4">
      <div class="">
          <div class="footer-bw bg-g5 pb-2">
            <div class="container pt-2">
                <ul class="list-inline tx-c mb-0 ml-1">
    <li class="mb-0 mr-05">
      <a href="#" target="_blank" class="inline-block" aria-label="Link to Facebook">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="23.6" viewbox="0 0 53 49">
      <title>Facebook</title><path d="M47.5 43c0 1.2-.9 2.1-2.1 2.1h-10V30h5.1l.8-5.9h-5.9v-3.7c0-1.7.5-2.9 3-2.9h3.1v-5.3c-.6 0-2.4-.2-4.6-.2-4.5 0-7.5 2.7-7.5 7.8v4.3h-5.1V30h5.1v15.1H10.7c-1.2 0-2.2-.9-2.2-2.1V8.3c0-1.2 1-2.2 2.2-2.2h34.7c1.2 0 2.1 1 2.1 2.2V43" class="icon-style icon-fb" style="fill:#aaa;fill-opacity:.8">
      </path></svg></a>
    </li>
    <li class="mb-0">
      <a href="#" target="_blank" class="inline-block" aria-label="Link to Twitter">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="22.2" viewbox="0 0 53 49">
      <title>Twitter</title>
      <path d="M45 6.9c-1.6 1-3.3 1.6-5.2 2-1.5-1.6-3.6-2.6-5.9-2.6-4.5 0-8.2 3.7-8.2 8.3 0 .6.1 1.3.2 1.9-6.8-.4-12.8-3.7-16.8-8.7C8.4 9 8 10.5 8 12c0 2.8 1.4 5.4 3.6 6.9-1.3-.1-2.6-.5-3.7-1.1v.1c0 4 2.8 7.4 6.6 8.1-.7.2-1.5.3-2.2.3-.5 0-1 0-1.5-.1 1 3.3 4 5.7 7.6 5.7-2.8 2.2-6.3 3.6-10.2 3.6-.6 0-1.3-.1-1.9-.1 3.6 2.3 7.9 3.7 12.5 3.7 15.1 0 23.3-12.6 23.3-23.6 0-.3 0-.7-.1-1 1.6-1.2 3-2.7 4.1-4.3-1.4.6-3 1.1-4.7 1.3 1.7-1 3-2.7 3.6-4.6" class="icon-style icon-twitter"  style="fill:#aaa;fill-opacity:.8">
      </path></svg></a>
    </li>
    </ul>
              <h6 class="tx-c tx-g5">Copyright &copy; 2020 — ThreeAnchor</h6>
          </div>
          </div>
        </div> <!-- .footer-b  -->
      </footer> <!-- .footer-p  -->
      </body>
    </html>
