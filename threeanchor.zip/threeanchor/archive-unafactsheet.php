<?php
/*
* Policy factsheet archive
*
* 1. Overflow hidden on wrapper container
* 2. Flex declaration on main container with -1 x margin
* 3. Avoid "card "max-width" settings Define size col-6+
* 4. Apply flex wrap to spill-over
* 4. Over Apply sm and mx margins at article level
* Year: <div class=""><div><i class="material-icons tres">today</i><?php echo $meta['selectyear']; ?></div>
* <!-- Apply mx-auto, xs-mx-auto, sm-mx-auto at article-level -->
* <!-- Avoid margin right/left declarations in stylesheet  -->
* <!-- Absolute block content will "glue to bottom"  -->
* <!-- Absolute content restricts left  "full"  -->
*/
?>
<?php get_header( 'amp' ); ?>

<main id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  <header id="header">
    <div class="container">
      <div class="lg-pt-1">
        <h1 class="pg-title"><?php wp_title(''); ?></h1>
      </div>  <!-- .col -->
    </div>  <!-- .row -->
  </header>


  <?php

  // The Arguments
  $args = array(
    'post_type'      => 'unafactsheet',
    'posts_per_page' => 8,
    'orderby' => 'date',
    'order' => 'DESC'
  );

  // The Query
  $parent = new WP_Query( $args ); ?>

  <section class="entry"> <!-- bg -->
    <div class="container clearfix py-w px-w"> <!-- fx-con -->
      <div class="md-flex lg-flex flex-wrap card-shadow justify-between"> <!-- fx-row -->
        <?php
        // Start the loop
        if ( $parent->have_posts() ) : while ( $parent->have_posts() ) : $parent->the_post();

        // Include fields
        $meta = get_post_meta( $post->ID, 'unafactsheet_fields', true ); ?>

        <article class="col-12 sm-col-11 card-polifx clearfix sm-mx-auto xs-mx-auto <?php if( isset($meta['selectposition']) && $meta['selectposition'] != 'default') {
          echo strtolower($meta['selectposition']); } ?>"> <!-- .conditional -->

          <?php if ( isset($meta['selectposition'])) { ?>
            <?php switch ( $meta['selectposition'] ) {

              case 'Support'  : ?>
              <div class="head support">
                <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-y.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy support"></amp-img>
              </div> <!-- .h -->
              <div class="body">
                <?php break;
                case 'Oppose'   : ?>
                <div class="head oppose">
                  <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-n.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy oppose"></amp-img>
                </div> <!-- .h -->
                <div class="body">

                  <?php break;
                  default          : ?>
                  <div class="head review">

                    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/poli-m.svg" width="26" height="26" sizes="(max-width: 40em) 38px, (max-width:64em) 40px, (max-width: 80em) 42px, 42px" alt="policy review"></amp-img>

                  </div> <!-- .h -->
                  <div class="body">

                    <?php break;
                  }
                  ?>
                <?php } ?> <!-- .position-->


                <?php if ( isset($meta['checkboxvoterec']) && $meta['checkboxvoterec'] === 'checkbox') { ?>
                  <h6 class="date"> Vote Recommendation</h6>
                <?php } else { ?>
                  <h6 class="date">Policy</h6>
                <?php } ?> <!-- .rec -->

                <h3 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                <p class="excerpt"> <?php echo wp_strip_all_tags( get_the_excerpt() ); ?></p>
              </div> <!-- .bod -->

    <footer>
      <div class="tresfx">
        <div class="it">
          <a class="btn-outline btn-sm" role="button" href="<?php the_permalink(); ?>">READ MORE &raquo;</a>
        </div>

        <div class="it overflow-hidden">
          <?php if (!empty($meta['text2'])): ?>

            <div><i class="material-icons tres">description</i>
              <?php echo esc_attr($meta['text2']); ?></div>

            <?php endif; ?>

            <?php
            // Govt level
            if ( isset($meta['selectgovt']) && $meta['selectgovt'] != 'default' && $meta['selectgovt'] != 'State' && $meta['selectgovt'] != 'Local') { ?>

              <div><i class="material-icons tres">account_balance</i>
                <?php echo $meta['selectgovt']; ?>
                <?php if ( isset($meta['selectstate']) && $meta['selectstate'] != 'default' && isset($meta['selectgovt']) && $meta['selectgovt'] != 'Federal') { ?>
                  <?php echo $meta['selectstate']; ?>
                <?php } ?>
              </div>
              <?php /* end govt level, federal */ } ?>
              <?php if ( isset($meta['selectstate']) && $meta['selectstate'] != 'default') { ?>
                <?php if ( isset($meta['selectgovt']) && $meta['selectgovt'] != 'default' && $meta['selectgovt'] != 'Federal') { ?>
                  <div><i class="material-icons tres">account_balance</i>
                    <?php
                    // Load State
                    echo $meta['selectgovt']; ?>, <?php echo $meta['selectstate']; ?></div>
                  <?php /* end local, state */ } ?>
                  <?php /* end govt-level */ } ?>
                </div>  <!-- .it -->
              </div> <!-- .tres -->
            </footer>
        </article>


                  <?php endwhile; ?>

                </div>  <!-- .fx-row -->

                  <?php
                   // Get pagination -->
                    get_template_part( 'templates/pagination' );
                  ?>

                <?php endif; wp_reset_postdata(); ?>

              </div> <!--  fx-con -->
          </section>
        </main>
  <?php get_footer( 'amp' ); ?>
