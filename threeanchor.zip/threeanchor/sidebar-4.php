<?php
/**
 * Petition form widget and static headline
 *
 */
?>


<?php	if ( ! is_active_sidebar( 'sidebar-4' ) ) {
		return;
	}
	?>

<section id="cta-4" class="form-petition">
		<div class="clearfix">
			<h2 class="peti-headline">Sign the Petition </h2><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/icon-arrow-down-petition.svg" width="50" height="60" alt="icon arrow down" />
		 <div class="sm-col-10 md-col-7 lg-col-5 px-1 mx-auto">
		   <?php dynamic_sidebar( 'sidebar-4' ); ?>
			</div>
		</div>
	</section>
