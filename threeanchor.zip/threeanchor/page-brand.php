<?php
/**
 * Template Name: Brand
 *
 */
?>
<?php get_header('amp'); ?>

  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

<main id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
   <header class="brand-h bg-cut-r bg-p9">
     <div class="brand-h-bg">
      <div class="container">
        <div class="hero-flex col-11 sm-col-9 md-col-7 lg-col-7 full-h mx-auto">
          <?php if (has_post_thumbnail( $post->ID ) ): ?>
            <amp-img src="<?php the_post_thumbnail_url(); ?>" title="<?php the_title_attribute(); ?>" height="628" width="1200" layout="responsive"></amp-img>
          <?php endif; ?>
          <?php the_title( '<h1 class="title subhead-c2">', '</h1>' ); ?>
          <?php if (has_excerpt( $post->ID ) ): ?>
            <div class="lead tx-c"><?php echo wp_strip_all_tags( get_the_excerpt(), true ); ?></div>
          <?php endif; ?>
        </div>   <!-- .fx-col -->
      </div>   <!-- .row -->
    </div> <!-- .bg -->
  </header> <!-- .hero/cut/color -->

  <?php get_template_part( 'templates/content', 'page' ); ?>

</main>     <!-- page end -->

  <?php endwhile; endif; ?>

  <?php get_sidebar( '1' ); ?>

  <?php get_footer(); ?>
