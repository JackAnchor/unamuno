<?php
/**
 * Template for staff page
 *
 */
?>

<?php get_header('amp'); ?>

  <main id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
   <header class="clearfix">
     <div class="col-12 sm-col-10 md-col-10 lg-col-8 mx-auto">
      <?php the_title( '<h1 class="pg-title">', '</h1>' ); ?>
     </div>  <!-- column end -->
   </header>

   <?php get_template_part( 'templates/content', 'page' ); ?>


 <?php

   // The Arguments
  // Custom field is not a legit "meta key"
  // I tried doing meta_query => array
  //  'orderby' => 'menu_order',
  //   'orderby' => 'modified',

//   $args = array(
//     'post_type'      => 'unaprofile',
//     'tag' => 'staff',
//     'posts_per_page' => 20,
//     'orderby' => 'menu_order',
//     'orderby' => 'modified',
//      'order' => 'ASC'
//      'order' => 'DESC'
//      unaprofile_fields[numberorder]
//      'menu_order' => 'DESC'
//      'meta_query' => array(


// The Arguments (two sorting rules with parameters)
// $args = array(
//   'post_type'  => 'unaprofile',
//   'posts_per_page' => 20,
//    'orderby' => array( 'modified' => 'DESC', 'menu_order' => 'DESC' )
// );
//  $query = new WP_Query( $args );   unaprofile_fields[numberorder]


  $args = array(
      'post_type' => 'unaprofile',
      'tag' => 'staff',
      'posts_per_page' => 20,
      'orderby' => 'modified',
      'order'	=> 'DESC'
    );
      $parent = new WP_Query( $args );
?>


   <section class="page-wc">
    <div class="container page-c">
                <h2>Flex Card Layout</h2>
                <p>Breakpoint-based flex (md, lg) with centered col on smaller devices</p>
                <div class="mx-n1 sm-flex md-flex flex-wrap card-shadow"> <!-- md-flex, lg-flex and mx-auto cols on sm, xs -->
 <?php
 // Start the loop
 if ( $parent->have_posts() ) : while ( $parent->have_posts() ) : $parent->the_post();


    // Get profile template
    get_template_part( 'templates/content', 'newsprofile' ); ?>


     <?php endwhile; endif; wp_reset_postdata(); ?>


      </div> <!--  wrap end -->
     </div>   <!-- parent div end -->
   </section>  <!-- bg -->
   </main>


   <?php get_sidebar( '1' ); ?>

<?php get_footer( 'amp' ); ?>
