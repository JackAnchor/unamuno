<?php
/*
 * The default template for pages
 *
 */
?>

<?php get_header( 'amp' ); ?>

  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

  <main id="post-<?php the_ID(); ?>">

      <header id="page-header" class="container">

        <div class="clearfix">

         <?php if (has_post_thumbnail( $post->ID ) ): ?>

           <div class="sm-col-12 md-col-10 lg-col-9 mx-auto pt-1">
            <amp-img src="<?php the_post_thumbnail_url(); ?>" title="<?php the_title_attribute(); ?>" height="628" width="1200" layout="responsive"></amp-img>
           </div>

         <?php endif; ?>

         <div class="col-12 sm-col-11 md-col-10 lg-col-9 mx-auto">

           <?php the_title( '<h1 class="pg-title">', '</h1>' ); ?>

        </div>  <!-- .column -->
        </div>
      </header>  <!-- .header -->

      <?php get_template_part( 'templates/content', 'page' ); ?>

    </main>     <!-- page wrap -->

    <?php endwhile; endif; ?>

      <?php get_sidebar( '1' ); ?>

<?php get_footer(); ?>
