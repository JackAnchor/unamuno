<?php
/**
 * Template Name: Category
 *
 * Template for primary service page (includes query) and pulls-in related category news
 * posts.
 */
?>

<?php get_header('amp'); ?>

<main id="post-<?php the_ID(); ?>"<?php post_class(); ?>>

  <header id="page-header" class="service-h pb-1">
    <div class="col-8 sm-col-7 md-col-4 lg-col-3 mx-auto pt-3 px-1">
      <?php if (has_post_thumbnail( $post->ID ) ): ?>
        <amp-img src="<?php the_post_thumbnail_url(); ?>" title="<?php the_title_attribute(); ?>" height="628" width="1200" layout="responsive"></amp-img>
      <?php endif; ?>
    </div>

    <div class="col-12 md-col-9 lg-col-8 mx-auto">
      <div class="pg-title">
          <?php the_title( '<h1 class="title">', '</h1>' ); ?>
        <p class="lead tx-g1"><?php echo wp_strip_all_tags( get_the_excerpt(), true ); ?></p>
      </div>  <!-- title end -->
    </div>  <!-- column end -->
  </header>  <!-- header end -->




    <?php
      // The Arguments
      $args = array(
        'post_type'      => 'page',
        'posts_per_page' => -1,
        'post_parent'    => $post->ID,
        'order'          => 'ASC',
        'orderby'        => 'menu_order'
       );

      // The Query
      $parent = new WP_Query( $args ); ?>

      <?php
      // Test
      if ( $parent->have_posts() ) : ?>

      <div id="parent-<?php the_ID(); ?>" class="parent-page pb-2"> <!-- div -->
       <div class="container"> <!-- flex container -->
         <div class="flex flex-wrap justify-center card-shadow"> <!-- row -->

      <?php
         // Start the loop
         while ( $parent->have_posts() ) : $parent->the_post(); ?>


        <?php get_template_part( 'templates/content', 'newscategory' ); ?>

        <?php endwhile; ?>

            </div>  <!-- flex row end -->
          </div> <!--  wrap end -->
        </div>   <!-- parent div end -->
      <?php endif; wp_reset_postdata(); ?>



<?php
   // Get news posts
   get_template_part( 'templates/content', 'categorynews' ); ?>

     <?php
        // Get staff posts
        get_template_part( 'templates/content', 'categorystaff' ); ?>

</main>

      <?php get_sidebar( 'secondary' ); ?>


<?php get_footer(); ?>
