<?php
/*
 * The default template for attachment posts
 */
?>

<?php get_header('amp'); ?>


  <main id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <header class="container"> <!-- page wrap  -->
      <div class="clearfix">
      <?php get_template_part( 'templates/content', 'post' ); ?>
    </div>
      <div class="clearfix pb-4 px-1">
        <div class="sm-col-12 md-col-9 lg-col-7 mx-auto pb-4">
        <?php the_title( '<h3 class="pb-4">', '</h3>' ); ?>
          <hr>
        </div>  <!-- col end -->
      </div>  <!-- col end -->
    </header>
  <?php endwhile; endif; ?>
</main>


      <?php get_sidebar( '3' ); ?>


<?php get_footer(); ?>
