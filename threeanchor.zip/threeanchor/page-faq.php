<?php
/**
 * Template Name: FAQ
 *
 *
 */
?>

<?php get_header('amp'); ?>

  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

<main id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <header class="brand-h bg-cut-r bg-p9">
      <div class="brand-h-bg">
       <div class="container">
         <div class="hero-flex flex flex-column col-11 sm-col-9 md-col-10 lg-col-7 justify-center full-h mx-auto">
        <?php the_title( '<h1 class="title subhead-c2">', '</h1>' ); ?>
          <?php if (has_excerpt( $post->ID ) ): ?>
            <div class="lead tx-c"><?php echo wp_strip_all_tags( get_the_excerpt(), true ); ?></div>
          <?php endif; ?>
         </div>   <!-- .row -->
     </div> <!-- .hero-box -->
   </div> <!-- background -->
  </header>
  <aside class="faq-layout mt-n10">
    <div class="faq-wrap pt-10 clearfix">
      <div class="col-11 sm-col-9 md-col-4 lg-col-3 faq-side px-1 sm-mx-auto xs-mx-auto">
        <div class="nav-stick">
          <amp-accordion class="nav-accordion">
            <section expanded>
              <h4>Information</h4>
              <ul class="list-unstyled">
                <li><a href="#about">About</a></li>
                <li><a href="#political-seo">Political SEO</a></li>
                <li><a href="#amp">AMP</a></li>
                <li><a href="#mobile">Mobile</a></li>
                <li><a href="#contact">Contact</a></li>
              </ul>
            </section>
            <section expanded>
              <h4>Process</h4>
              <ul class="list-unstyled">
                <li><a href="#web-development">Website Development</a></li>
                <li><a href="#service">Service &amp; Support</a></li>
                <li><a href="#content">Content</a></li>
                <li><a href="#learning">Learning</a></li>
                <li><a href="#timeline">Timeline</a></li>
              </ul>
            </section>
            <section expanded>
              <h4>Specifications</h4>
              <ul class="list-unstyled">
                <li><a href="#analytics">Analytics</a></li>
                <li><a href="#hosting">Web Hosting</a></li>
                <li><a href="#users">Users</a></li>
                <li><a href="#migrations">Migrations</a></li>
                <li><a href="#social-media">Social Media</a></li>
                <li><a href="#fundraising">Fundraising</a></li>
                <li><a href="#email-marketing">Email Marketing</a></li>
              </ul>
            </section>
          </amp-accordion>
        </div>
      </div> <!-- .col1 -->
      <div class="page-w col-11 sm-col-9 md-col-7 lg-col-7 sm-mx-auto md-mx-auto xs-mx-auto mx-auto">
        <div class="max-width-2 pb-4 pt-1 page-c faq-c content">
          <?php the_content(); ?>
        </div>
      </div> <!-- .col2 -->
    </div>
  </aside>
</main>

   <?php endwhile; endif; ?>

     <?php get_sidebar( '1' ); ?>

<?php get_footer(); ?>
