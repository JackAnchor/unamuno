<?php
/**
 * Template for pagination
 *
 */
?>
<div class="lg-col-8 md-col-9 mx-auto px-1">
    <div class="pagination-w">
      <hr>
      <ul class="menu-pg menu-pgs btn-pg mx-auto">
        <li><?php previous_posts_link( '&laquo; Previous ' ); ?></li>
        <li><?php next_posts_link( 'Next &raquo;' ); ?></li>
      </ul>
   </div>
 </div>
