<?php
/**
 * Template for displaying factsheet cards (no query)
 *
 */
?>

<?php
// Include fields
$meta = get_post_meta( $post->ID, 'unafactsheet_field', true ); ?>


      <article class="sm-col-9 md-col-5 lg-col-6 card-polifx clearfix <?php if( isset($meta['selectposition']) && $meta['selectposition'] != 'default') {
         echo strtolower($meta['selectposition']); } ?>"> <!-- .conditional -->

          <div class="polifx-left">
            <?php if ( isset($meta['selectposition'])) { ?>
              <?php switch ( $meta['selectposition'] ) {

               case 'Support'  : ?>

                <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/policy-clipyes-f.svg" width="30" height="30" sizes="(max-width: 38em) 8vw, (max-width: 65em) 6vw, (max-width: 80em) 4vw, 42px" alt="policy support"></amp-img>

               <?php break;
               case 'Oppose'   : ?>

              <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/policy-clipn.svg" width="30" height="30" sizes="(max-width: 38em) 8vw, (max-width: 65em) 6vw, (max-width: 80em) 4vw, 42px" alt="policy oppose"></amp-img>

              <?php break;
              default          : ?>
                <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/policy-clipsearch-f.svg" width="30" height="30" sizes="(max-width: 38em) 8vw, (max-width: 65em) 6vw, (max-width: 80em) 4vw, 42px" alt="policy review"></amp-img>
                <?php break;
              }
             ?>
          <?php } ?> <!-- .position -->

          </div> <!-- .left -->



          <div class="polifx-center">
            <?php if ( isset($meta['checkboxvoterec']) && $meta['checkboxvoterec'] === 'checkbox') { ?>
              <h6 class="date">Vote Recommendation</h6>
            <?php } else { ?>
            <h6 class="date">Policy</h6>
            <?php } ?> <!-- .rec -->
            <h3 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            <h5 class="cat"><?php echo $meta['text2']; ?></h5>
            <p class="excerpt"> <?php echo wp_strip_all_tags( get_the_excerpt() ); ?></p>

            <footer>
              <div class="footer-d">
                <a class="btn-p7 btn-sm bt-sm-x" role="button" href="<?php the_permalink(); ?>">READ MORE &raquo;</a>
              </div>
            </footer> <!-- footer end -->
          </div> <!-- .center -->

      </article>   <!--  .card -->
