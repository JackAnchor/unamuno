<?php
/**
 * Default template for post content. Not currently used.
 *
 * .post-c, .page-c { default padding}
 * Section: post-w + petition-w
 * Section: page-w + about-w
 *
 * Content: page-c + content + about-c
 * Content: post-c + content + profile-c
 * Content: post-c + content + petition-c
 * Content: post-c + content + unapost-c
 * Content: post-c + content + factsheet-c
*/
?>
<section class="post-w">
    <div class="clearfix container">
       <div class="sm-col-10 md-col-8 lg-col-7 mx-auto post-c content">
         <?php the_content(); ?>
      </div>  <!-- .col -->
    </div> <!-- .clear -->
</section>
