<?php
/**
 * Template for displaying news page posts (no query)
 *
 * card-index: Template for home and news page cards
 * index-news: news card styling
 * index-home: homenews card styling
 *
 * Removed  <p class="index-author">By <strong><?php the_author(); ?></strong></p>
 * <div class="clearfix index-byline">
 *  <div class="index-category"><?php the_category(' | ') ?></div>
 *  <div class="left"> | </div>
 *  <div class="overflow-hidden">
 *    <div class="index-date"><?php the_date(); ?></div>
 *  </div>
 * </div>
 *
*/
?>

    <article class="col-12 sm-col-9 card-index xs-mx-auto sm-mx-auto clearfix pb-4">

      <?php
       // Profile Post Test
       if ( 'unaprofile' == get_post_type() ): ?>

        <?php if (has_post_thumbnail( $post->ID ) ): ?>

          <div class="bg-w4">

          <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><amp-img src="<?php the_post_thumbnail_url(); ?>" height="210" width="210" sizes="(max-width: 40em) 210px, (max-width:64em) 250px, (max-width: 80em) 300px, 300px" alt="profile thumbnail" class="mx-auto"></amp-img></a>


        </div>
        <?php endif; ?>

        <?php
         // All other post types
        else: ?>
        <?php if (has_post_thumbnail( $post->ID ) ): ?>
          <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><amp-img src="<?php the_post_thumbnail_url(); ?>" height="628" width="1200" layout="responsive"></amp-img></a>
        <?php endif; ?>

      <?php
      // End Profile / Non-Profile Test
      endif; ?>


        <div class="body">
          <h5 class="cat"><?php the_category(' | ') ?></h5>
          <h6 class="date"><?php the_date(); ?></h6>
          <h3 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
          <p><?php the_excerpt(); ?></p>
        </div>  <!-- body end -->
          <footer>
            <div class="footer-d">
            <a class="btn-p7 btn-md" role="button" href="<?php the_permalink(); ?>">READ MORE &raquo;</a>
           </div>
         </footer>
      </article> <!-- .card -->
