<?php
/**
 * Template for displaying service category news posts (includes query)
 *
 */
?>

  <?php
    // The Arguments
    $args = array(
      'post_type'      => 'post',
      'posts_per_page' => 2,
    );

    // The Query
    $parent = new WP_Query( $args ); ?>

    <?php
    // Test
    if ( $parent->have_posts() ) : ?>

    <!-- Nested inline cards (parent) -->

    <div class="container pb-4">
      <div class="clearfix">
        <div class="sm-col-11 md-col-11 lg-col-10 mx-auto">


      <?php
      // Start the loop
      while ( $parent->have_posts() ) : $parent->the_post(); ?>


     <?php get_template_part( 'templates/content', 'newsinline' ); ?>


       <?php endwhile; ?>

         </div>  <!-- parent col end -->
        </div> <!-- parent row end -->
      </div>   <!-- parent container -->


       <?php endif; wp_reset_postdata(); ?>
