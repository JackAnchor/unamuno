<?php
/**
 * Template for petition body content, excerpt "tease" and sidebar "4"
 *
 */
?>

<div class="peti-w">
  <div class="stick-layout container">
    <div class="md-flex lg-flex justify-between">
      <div class="sm-col-10 md-col-6 lg-col-7 order-2 xs-mx-auto sm-mx-auto px-w">  <!-- .peti-w -->
        <div class="peti-cw">
          <p class="peti-lead relative">
            <?php echo wp_strip_all_tags( get_the_excerpt(), true ); ?>
          </p>

          <div class="post-c content peti-c">
            <?php the_content(); ?>
            <blockquote>
              <?php echo wp_strip_all_tags( get_the_excerpt(), true ); ?>
            </blockquote>
          </div>
        </div>
      </div> <!-- .col1 -->


      <div class="sm-col-12 md-col-6 lg-col-5 stick-col order-2">
        <div class="stick-head">
          <!-- <h5 class="cat">Action Center</h5> -->
        </div>
        <div id="cta-4" class="stick-body form-petition">
          <!-- <div class="head flex flex-column items-center content-center"><h4 class="subtitle">TAKE ACTION:</h4></div> -->
          <div class="body col-11 sm-col-9 md-col-12 mx-auto">
            <form class="px-1 pt-1 col-11 sm-col-9 md-col-12 mx-auto" id="gform_55" action="#/subscribe" target="_top">

                      <h3 class="title">Act now. Add <strong><em>your name</em></strong> today.</h3>
              <p class="hide">Speak out and send Washington a message. Make <strong> <em>your voice</em> </strong> heard.</p>
              <p class="lead"><?php echo wp_strip_all_tags( get_the_excerpt(), true ); ?></p>
              <div class="clearfix mx-n05">
                <div class="col col-6 px-05"><input type="text" class="" placeholder="First name"></div>
                <div class="col col-6 px-05"><input type="text" class="" placeholder="Last name"></div>
                <div class="col col-12 px-05"><input type="text" class="" placeholder="Address"></div>
                <div class="col col-8 px-05"><input type="email" class="form-control" id="exampleFormControlInput1" placeholder="@email.com"></div>
                <div class="col col-4 px-05"><input type="text" class="" placeholder="Zip"></div>
              </div><!-- .row -->
              <label class="block mb-1">
                <input type="checkbox" checked>
                <small>E-newsletter sign-up</small>
              </label>
              <button type="submit" class="btn no-outline btn-p5 btn-lg col-12 sm-col-5">SUBMIT</button>
            </form>

            <div class="snap-s">
              <?php get_template_part( 'templates/components/social-unapost' ); ?>
            </div>
          </div> <!-- .body -->
        </div>  <!-- .cta -->
      </div> <!-- .col2 -->
    </div>
  </div>  <!-- .layout -->
</div>     <!-- .peti-w -->
