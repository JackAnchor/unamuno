<?php
/**
 * Template for displaying no content
 *
 */
?>

<section class="page-w">
  <div class="container">
    <div class="clearfix">
       <div class="col-11 sm-col-10 md-col-8 lg-col-7 mx-auto page-c content">
         <p>Sorry, no content matched your criteria. <br>Please explore our homepage or try searching with different keywords.</p>
          <div class="py-2">
              <?php get_search_form(); ?>
            </div>
      </div>  <!-- column end -->
    </div> <!-- clearfix end -->
  </div>
</section>
