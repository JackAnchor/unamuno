<?php
/*
* Template for displaying most recent petition
*/
?>


<?php

  // The Arguments
  $args = array(
    'post_type'      => 'unapetition',
    'posts_per_page' => 1
  );

  // The Query
  $parent = new WP_Query( $args ); ?>

  <?php
  // Test
  if ( $parent->have_posts() ) : ?>

<aside id="cta-petition" class="pt-4">
  <h6 class="tx-center tx-g2"><i class="material-icons md-24 tx-g2 tx-center">notifications_active</i></h6>
  <h5 class="tx-g2 tx-center brand-label pb-1">Action Alert</h5>
  <!-- Petition CTA Card (parent) -->
  <div class="container pb-4">
    <div class="clearfix">
      <div class="sm-col-10 md-col-12 lg-col-12 mx-auto">

        <?php
        // Start the loop
        while ( $parent->have_posts() ) : $parent->the_post(); ?>

        <div class="clearfix card-petition-cta sm-mx-2">   <!-- nested row/card start -->
        <div class="sm-col sm-col-12 md-col-6 lg-col-6 overflow-hidden grayscale">
            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><amp-img src="<?php the_post_thumbnail_url(); ?>" height="314" width="600" layout="responsive"></amp-img></a>
          </div>

          <div class="sm-col sm-col-10 md-col-6 lg-col-6 md-pl-1">
            <div class="card-body">
              <h3 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
              <a class="btn-p5" href="<?php the_permalink(); ?>">TAKE ACTION &raquo;</a>

            </div>  <!-- .body -->
          </div> <!-- .col -->
        </div>  <!-- nested row/card end -->


      <?php endwhile; ?>

    </div>  <!-- parent col end -->
   </div> <!-- parent row end -->
 </div>   <!-- parent wrap end -->
</aside>
  <?php endif; wp_reset_postdata(); ?>
