<?php
/**
 * Template for displaying inline news cards (no query)
 *
 */
?>

<article class="clearfix card-inline mt-0">   <!-- nested row/card start -->
  <div class="sm-col sm-col-6 md-col-5 lg-col-5 overflow-hidden">
    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><amp-img src="<?php the_post_thumbnail_url(); ?>" height="628" width="1200" layout="responsive"></amp-img></a>
  </div>
  <div class="sm-col sm-col-6 md-col-7 lg-col-7">
    <div class="card-body">
      <h3 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
    </div>  <!-- body end -->
    <footer>
      <div class="footer-d">
        <a class="btn-p7 btn-md" role="button" href="<?php the_permalink(); ?>">MORE &raquo;</a>
    </div>
    </footer>
   </div> <!-- col end -->
 </article>  <!-- card end -->
