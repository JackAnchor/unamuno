<section class="page-w">
    <div class="clearfix">
       <div class="sm-col-11 md-col-8 lg-col-7 mx-auto page-c content">
         <?php the_content(); ?>
      </div>  <!-- column end -->
    </div> <!-- clearfix end -->
</section>
