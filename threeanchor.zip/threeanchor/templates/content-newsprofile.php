<?php
/**
 * Template for displaying profile index cards.
 *
 */
?>

<?php
// Include fields
$meta = get_post_meta( $post->ID, 'unaprofile_fields', true ); ?>

<article class="col-12 sm-col-10 md-col-6 sm-mx-auto xs-mx-auto">
<div class="card-profile">
    <div class="clearfix">
      <div class="left mr-1">
        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><amp-img src="<?php the_post_thumbnail_url(); ?>" width="80" height="80" sizes="(max-width: 39.99em) 25vw, (max-width: 52em) 20vw, (max-width: 64em) 15vw, 145px" alt="staff profile"></amp-img>
        </div>
        <div class="right body">
          <p class="link"><a href="<?php the_permalink(); ?>">&raquo;</a></p>
        </div>
        <div class="overflow-hidden body">
          <h3 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
          <?php if (!empty($meta['text'])) {
            echo '<div class="position">';
            echo esc_html($meta['text']);
            echo '</div>';
          }
          if (!empty($meta['text2'])) {
            echo '<a href="https://twitter.com/';
            echo esc_attr($meta['text2']);
            echo '"><p class="twitter">@';
            echo esc_html($meta['text2']);
            echo '</p></a>';
          } ?>
        </div>
      </div>
  </div>   <!-- .card -->
</article>   <!--  card wrap -->
