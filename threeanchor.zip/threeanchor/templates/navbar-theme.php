<?php
/*
* Responsive AMP navbar with single menu
*
* May 14
* aside is main container
* open is secondary container
* most of the details involve come-in from left or right.
* VALIDATION DETAILS:
* ---------------------------------------
* - Include amp-sidebar script in head
* - Higher Z index = higher layer
* - Default style navbar, menu-primary
* - Logo & icon filepath /img/logos/amp-logo.svg
* - Desktop navbar background style: .amp-sidebar-toolbar-target-hidden
* - Dark background link: #999
* - Dark background hover: #bbb
*/
?>


<header id="navbar" class="navbar navbar-theme">
  <div class="navbar-w flex items-center justify-between">
    <a class="nav-logo flex-item inline-block" href="<?php echo get_home_url(); ?>"><?php get_template_part( 'img/logos/logo-navbar'); ?></a>

  <div class="xs-hide sm-hide flex-item">
    <?php wp_nav_menu( array(
      'menu_class' => 'xs-hide sm-hide menu-t',
      'theme_location' => 'header-menu',
      'container' => '',
      'menu_id' => ''
    ) ); ?>
  </div>    <!-- desktop menu -->

  <div class="md-hide lg-hide">
    <button class="flex-item navbar-btn navbar-btn-fill toggle-overlay">
      ☰
     </button>
   </div>
</div>
</header>

  <nav class="md-hide lg-hide">
    <div class="outer-close toggle-overlay">
      <div class="close">✕</div>
    <div class="">
      <?php wp_nav_menu( array(
        'menu_class' => 'menu-t',
        'theme_location' => 'header-menu',
        'menu_id' => ''
      ) ); ?>
    </div>
    </div>
  </nav>
