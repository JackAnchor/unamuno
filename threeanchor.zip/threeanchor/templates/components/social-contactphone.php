<?php
/**
 *  The template for displaying 2 icon contact links (phone and email)
 *
 */
?>
<div class="contactphone">
  <a href="tel:<?php echo get_option( 'unamunophoneax' ); ?>"><?php get_template_part( 'img/svg/phone'); ?><span class="ml-05"> <?php echo get_option( 'unamunophoneax' ); ?></span></a><br>
   <a href="mailto:?subject=Website%20Contact" class="inline-block" target="_blank" aria-label="Link to email"><?php get_template_part( 'img/svg/mail'); ?><span class="">info@three-anchor.com</span></a>
</div>
