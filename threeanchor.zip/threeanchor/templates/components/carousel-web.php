<?php
/**
 * Carousel Web
* </div>  <!-- .col -->
* </div>  <!-- .row -->
*</div>  <!-- .wrap  -->
 *
 */
?>


<div class="lightbox-box">
  <amp-carousel width="435" height="585" controls loop layout="responsive" type="slides">

    <!-- 1  -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/app-hero-home-o.jpg" width="2100" height="1225" layout="responsive" alt="Political Advocacy Homepage"></amp-img>
      <div class="slide-caption">
        Home Page
      </div>
    </div>


    <!-- 2  -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/legislation-servicepg.png" width="2400" height="1400" layout="responsive" alt="Legislation Services Page"></amp-img>
      <div class="slide-caption pb-3">
        Legislation Page
      </div>
    </div>


    <!-- 3  -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/homehero-siblingsjpg.jpg" width="2100" height="1225" layout="responsive" alt="Public Policy Homepage"></amp-img>
      <div class="slide-caption pb-3">
        Home Page
      </div>
    </div>



    <!-- 4  -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/ballot-cards-d3.png" width="2400" height="1400" layout="responsive" alt="Ballot/Candidate Information Cards"></amp-img>
      <div class="slide-caption">
        Ballot Information Cards
      </div>
    </div>


    <!-- 5  -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/ballot-cards-d.png" width="2400" height="1400" layout="responsive" alt="Ballot/Candidate Information Cards"></amp-img>
      <div class="slide-caption">
        Ballot Information Cards
      </div>
    </div>


    <!-- 6 -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/comparison-cards-lg-8.png" width="2400" height="1400" layout="responsive" alt="Candidate comparison cards"></amp-img>
      <div class="slide-caption">
        Candidate Comparison Cards
      </div>
    </div>

    <!-- 7  -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/comparison-cards-lg.png" width="2100" height="1225" layout="responsive" alt="Candidate comparison cards desktop"></amp-img>
      <div class="slide-caption">
        Candidate Comparison Cards
      </div>
    </div>


    <!-- 8 -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/research-cardsappf.png" width="2100" height="1225" layout="responsive" alt="Public Policy Research Areas"></amp-img>
      <div class="slide-caption">
      Policy Research Areas
      </div>
    </div>

    <!-- 9  -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2019/01/klf-case-study12.png" width="2400" height="1400" layout="responsive" alt="Political fundraising website homepage"></amp-img>
      <div class="slide-caption pb-3">
      Home Page Hero
      </div>
    </div>


        <!-- 10 new   -->
        <div class="slide">
          <amp-img src="  https://threeanchorgroup.com/wp-content/uploads/2019/01/appf-case-study18.png" width="2400" height="1400" layout="responsive" alt="Political website homepage content"></amp-img>
          <div class="slide-caption pb-3">
          Home About Content
          </div>
        </div>

    <!-- 11 -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/ballot-blowout-car.png" width="2100" height="1225" layout="responsive" alt="Conservative political spending infographic"></amp-img>
      <div class="slide-caption">
        <p>Conservative vs. Liberal Spending Infographic</p>
      </div>
    </div>

    <!-- 12-->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/elect-educate-car.png" width="2100" height="1225" layout="responsive" alt="Conservative political spending infographic"></amp-img>
      <div class="slide-caption">
        <p>Conservative Spending Infographic</p>
      </div>
    </div>

    <!-- 13 -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/brand-icon-politics.png" width="2100" height="1225" layout="responsive" alt="brand icon politics"></amp-img>
      <div class="slide-caption">
        <p>Brand Icon (Politics)</p>
      </div>
    </div>

    <!-- 14 -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/brand-icon-nonprofit-2.png" width="2100" height="1225" layout="responsive" alt="Brand service icon Nonprofit"></amp-img>
      <div class="slide-caption">
        <p>Brand Icon (Nonprofit)</p>
      </div>
    </div>

    <!-- 15 -->
    <div class="slide">
      <amp-img src="https://2p4ejc2mjwg81dvl6v283h2y-wpengine.netdna-ssl.com/wp-content/uploads/2018/11/google-referee-graphic.png" width="2400" height="1252" layout="responsive" alt="ThreeAnchor social media brand graphic"></amp-img>
      <div class="slide-caption">
        <p>Social Media Brand Graphic</p>
      </div>
    </div>

  </amp-carousel>
</div>  <!-- .box -->
