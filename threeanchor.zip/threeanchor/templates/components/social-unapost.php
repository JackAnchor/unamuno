<?php
/*
 * The template for displaying FB, Twitter and email news article header links
 *
 *
 * Classes: .icon-social .mail .fb .twitter
 */
?>

<ul>
  <li>
    <a rel="nofollow" aria-label="Facebook Share" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="23.6" viewbox="0 0 53 49"><title>Facebook Share</title><path d="M47.5 43c0 1.2-.9 2.1-2.1 2.1h-10V30h5.1l.8-5.9h-5.9v-3.7c0-1.7.5-2.9 3-2.9h3.1v-5.3c-.6 0-2.4-.2-4.6-.2-4.5 0-7.5 2.7-7.5 7.8v4.3h-5.1V30h5.1v15.1H10.7c-1.2 0-2.2-.9-2.2-2.1V8.3c0-1.2 1-2.2 2.2-2.2h34.7c1.2 0 2.1 1 2.1 2.2V43" class="icon-social fb" style="fill-opacity:.9"></path></svg></a>
    </li>
    <li>
      <a rel="nofollow" target="_blank" aria-label="Twitter Share" href="https://twitter.com/intent/tweet?url=<?php the_permalink(); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="24.4" height="22.6" viewbox="0 0 53 49">
      <title>Twitter Share</title>
      <path d="M45 6.9c-1.6 1-3.3 1.6-5.2 2-1.5-1.6-3.6-2.6-5.9-2.6-4.5 0-8.2 3.7-8.2 8.3 0 .6.1 1.3.2 1.9-6.8-.4-12.8-3.7-16.8-8.7C8.4 9 8 10.5 8 12c0 2.8 1.4 5.4 3.6 6.9-1.3-.1-2.6-.5-3.7-1.1v.1c0 4 2.8 7.4 6.6 8.1-.7.2-1.5.3-2.2.3-.5 0-1 0-1.5-.1 1 3.3 4 5.7 7.6 5.7-2.8 2.2-6.3 3.6-10.2 3.6-.6 0-1.3-.1-1.9-.1 3.6 2.3 7.9 3.7 12.5 3.7 15.1 0 23.3-12.6 23.3-23.6 0-.3 0-.7-.1-1 1.6-1.2 3-2.7 4.1-4.3-1.4.6-3 1.1-4.7 1.3 1.7-1 3-2.7 3.6-4.6" class="icon-social twitter" style="fill-opacity:.9"></path></svg></a>
      </li>
    <li><a href="mailto:?subject=Interesting%20News%20Story&amp;body=I%20thought%20you%20might%20find%20this%20story%20interesting.%20<?php the_permalink(); ?>" target="_blank" aria-label="Email share">
      <svg xmlns="http://www.w3.org/2000/svg" width="25" height="19" viewbox="0 0 56 43">
        <title>Email Share</title>
        <path d="M10.5 6.4C9.1 6.4 8 7.5 8 8.9v21.3c0 1.3 1.1 2.5 2.5 2.5h34.9c1.4 0 2.5-1.2 2.5-2.5V8.9c0-1.4-1.1-2.5-2.5-2.5H10.5zm2.1 2.5h30.7L27.9 22.3 12.6 8.9zm-2.1 1.4l16.6 14.6c.5.4 1.2.4 1.7 0l16.6-14.6v19.9H10.5V10.3z" class="icon-social mail" style="fill-opacity:.9"></path></svg></a>
      </li>
    </ul>
