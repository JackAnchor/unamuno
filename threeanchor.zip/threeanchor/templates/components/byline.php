<?php
/**
 * Template for Author (Name, Avatar, Twitter) and Post Tags
 *
 */
?>

<div class="byline">
  <hr>
  <div class="clearfix mx-auto">
    <div class="md-col md-col-7 lg-col-6">
      <div class="clearfix">  <!-- media object -->
        <h5 class="label">Author:</h5>
        <div class="img"><?php echo get_avatar( get_the_author_meta( 'ID' ), 70 ); ?></div>
        <div class="author"><?php the_author(); ?></div>
        <a href="https://twitter.com/<?php echo the_author_meta('twitter_profile'); ?>" class="twitter ellipsis"><?php echo the_author_meta('twitter_profile'); ?></a>
      </div>
    </div>
    <div class="md-col md-col-7 lg-col-6">
      <div class="clearfix">  <!-- tag -->
          <div class="tags"><?php the_tags( '<h5 class="label">Tagged: </h5>', ' ', '' ); ?></div>
      </div>
    </div>
  </div>  <!--  .clear -->
</div>
