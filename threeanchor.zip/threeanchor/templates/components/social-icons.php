<?php
/*
 * List of all icons/garbage
 *
*/
?>

<?php get_template_part( 'img/svg/alarm'); ?>
<?php get_template_part( 'img/svg/factsheet'); ?>
<?php get_template_part( 'img/svg/policy'); ?>
<?php get_template_part( 'img/svg/profile'); ?>
<?php get_template_part( 'img/svg/contact'); ?>
<?php get_template_part( 'img/svg/news'); ?>
<?php get_template_part( 'img/svg/twitter'); ?>
<?php get_template_part( 'img/svg/facebook'); ?>
<?php get_template_part( 'img/svg/mail'); ?>
<?php get_template_part( 'img/svg/facebook'); ?>
<?php get_template_part( 'img/svg/news'); ?>

<amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/icon-unapetition.svg" width="24" height="24" class="mr-05" alt="cube icon"></amp-img>


<amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/icon-unapetition.svg" width="24" height="24" class="mr-05" alt="cube icon"></amp-img>


<amp-img src="<?php $custom_logo_id = get_theme_mod( 'custom_logo' );
$image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
echo $image[0]; ?>" width="190" height="80" alt="brand logo"></amp-img>

<?php
/*
* Draft social content
*
* Unordered list svg icons
* Need links and CSS
*
*/
?>


<ul class="list-reset">
    <li>
      hi
      hello
      <?php get_template_part( 'img/svg/phone'); ?>

        <a href="#" target="_blank" class="inline-block p1" aria-label="Link to Twitter"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="22.2" viewbox="0 0 53 49"><title>Twitter</title><path d="M45 6.9c-1.6 1-3.3 1.6-5.2 2-1.5-1.6-3.6-2.6-5.9-2.6-4.5 0-8.2 3.7-8.2 8.3 0 .6.1 1.3.2 1.9-6.8-.4-12.8-3.7-16.8-8.7C8.4 9 8 10.5 8 12c0 2.8 1.4 5.4 3.6 6.9-1.3-.1-2.6-.5-3.7-1.1v.1c0 4 2.8 7.4 6.6 8.1-.7.2-1.5.3-2.2.3-.5 0-1 0-1.5-.1 1 3.3 4 5.7 7.6 5.7-2.8 2.2-6.3 3.6-10.2 3.6-.6 0-1.3-.1-1.9-.1 3.6 2.3 7.9 3.7 12.5 3.7 15.1 0 23.3-12.6 23.3-23.6 0-.3 0-.7-.1-1 1.6-1.2 3-2.7 4.1-4.3-1.4.6-3 1.1-4.7 1.3 1.7-1 3-2.7 3.6-4.6" class="icon-style icon-twitter"></path></svg></a>
    </li>
    <li>
        <a href="#" target="_blank" class="inline-block p1" aria-label="Link to Facebook"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="23.6" viewbox="0 0 56 55"><title>Facebook</title><path d="M47.5 43c0 1.2-.9 2.1-2.1 2.1h-10V30h5.1l.8-5.9h-5.9v-3.7c0-1.7.5-2.9 3-2.9h3.1v-5.3c-.6 0-2.4-.2-4.6-.2-4.5 0-7.5 2.7-7.5 7.8v4.3h-5.1V30h5.1v15.1H10.7c-1.2 0-2.2-.9-2.2-2.1V8.3c0-1.2 1-2.2 2.2-2.2h34.7c1.2 0 2.1 1 2.1 2.2V43" class="icon-style icon-fb"></path></svg></a>
    </li>
    <li>
        <a href="#" target="_blank" class="inline-block p1" aria-label="Link to Instagram"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 54 54"><title>instagram</title><path d="M27.2 6.1c-5.1 0-5.8 0-7.8.1s-3.4.4-4.6.9c-1.2.5-2.3 1.1-3.3 2.2-1.1 1-1.7 2.1-2.2 3.3-.5 1.2-.8 2.6-.9 4.6-.1 2-.1 2.7-.1 7.8s0 5.8.1 7.8.4 3.4.9 4.6c.5 1.2 1.1 2.3 2.2 3.3 1 1.1 2.1 1.7 3.3 2.2 1.2.5 2.6.8 4.6.9 2 .1 2.7.1 7.8.1s5.8 0 7.8-.1 3.4-.4 4.6-.9c1.2-.5 2.3-1.1 3.3-2.2 1.1-1 1.7-2.1 2.2-3.3.5-1.2.8-2.6.9-4.6.1-2 .1-2.7.1-7.8s0-5.8-.1-7.8-.4-3.4-.9-4.6c-.5-1.2-1.1-2.3-2.2-3.3-1-1.1-2.1-1.7-3.3-2.2-1.2-.5-2.6-.8-4.6-.9-2-.1-2.7-.1-7.8-.1zm0 3.4c5 0 5.6 0 7.6.1 1.9.1 2.9.4 3.5.7.9.3 1.6.7 2.2 1.4.7.6 1.1 1.3 1.4 2.2.3.6.6 1.6.7 3.5.1 2 .1 2.6.1 7.6s0 5.6-.1 7.6c-.1 1.9-.4 2.9-.7 3.5-.3.9-.7 1.6-1.4 2.2-.7.7-1.3 1.1-2.2 1.4-.6.3-1.7.6-3.5.7-2 .1-2.6.1-7.6.1-5.1 0-5.7 0-7.7-.1-1.8-.1-2.9-.4-3.5-.7-.9-.3-1.5-.7-2.2-1.4-.7-.7-1.1-1.3-1.4-2.2-.3-.6-.6-1.7-.7-3.5 0-2-.1-2.6-.1-7.6 0-5.1.1-5.7.1-7.7.1-1.8.4-2.8.7-3.5.3-.9.7-1.5 1.4-2.2.7-.6 1.3-1.1 2.2-1.4.6-.3 1.6-.6 3.5-.7h7.7zm0 5.8c-5.4 0-9.7 4.3-9.7 9.7 0 5.4 4.3 9.7 9.7 9.7 5.4 0 9.7-4.3 9.7-9.7 0-5.4-4.3-9.7-9.7-9.7zm0 16c-3.5 0-6.3-2.8-6.3-6.3s2.8-6.3 6.3-6.3 6.3 2.8 6.3 6.3-2.8 6.3-6.3 6.3zm12.4-16.4c0 1.3-1.1 2.3-2.3 2.3-1.3 0-2.3-1-2.3-2.3 0-1.2 1-2.3 2.3-2.3 1.2 0 2.3 1.1 2.3 2.3z" class="icon-style icon-instagram"></path></svg></a>
    </li>
    <li>
        <a href="#" target="_blank" class="inline-block p1" aria-label="Link to E-mail"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="18.4" viewbox="0 0 56 43"><title>email</title><path d="M10.5 6.4C9.1 6.4 8 7.5 8 8.9v21.3c0 1.3 1.1 2.5 2.5 2.5h34.9c1.4 0 2.5-1.2 2.5-2.5V8.9c0-1.4-1.1-2.5-2.5-2.5H10.5zm2.1 2.5h30.7L27.9 22.3 12.6 8.9zm-2.1 1.4l16.6 14.6c.5.4 1.2.4 1.7 0l16.6-14.6v19.9H10.5V10.3z" class="ampstart-icon ampstart-icon-email"></path></svg></a>
    </li>
</ul>


<p>social 1</p>


<!--  email
      24 : 18.4
      36 : 27.6
-->

<!--  Twitter
      24 : 22.2
      36 : 33.3
-->

<!--  Facebook
      24 : 23.6
      36 : 35.4
-->


<!--  Social Inline List Large -->
<ul class="list-inline">
  <li class="mr-1">
    <a href="<?php echo get_option( 'unamunofacebook' ); ?>" target="_blank" class="inline-block" aria-label="Link to Facebook">
    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="35.4" viewbox="0 0 53 49">
    <title>Facebook</title><path d="M47.5 43c0 1.2-.9 2.1-2.1 2.1h-10V30h5.1l.8-5.9h-5.9v-3.7c0-1.7.5-2.9 3-2.9h3.1v-5.3c-.6 0-2.4-.2-4.6-.2-4.5 0-7.5 2.7-7.5 7.8v4.3h-5.1V30h5.1v15.1H10.7c-1.2 0-2.2-.9-2.2-2.1V8.3c0-1.2 1-2.2 2.2-2.2h34.7c1.2 0 2.1 1 2.1 2.2V43" class="icon-style icon-fb" style="fill:#222222;fill-opacity:.8">
    </path></svg></a>
  </li>
  <li class="mr-1">
    <a href="<?php echo get_option( 'unamunotwitter' ); ?>" target="_blank" class="inline-block" aria-label="Link to Twitter">
    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="33.3" viewbox="0 0 53 49">
    <title>Twitter</title>
    <path d="M45 6.9c-1.6 1-3.3 1.6-5.2 2-1.5-1.6-3.6-2.6-5.9-2.6-4.5 0-8.2 3.7-8.2 8.3 0 .6.1 1.3.2 1.9-6.8-.4-12.8-3.7-16.8-8.7C8.4 9 8 10.5 8 12c0 2.8 1.4 5.4 3.6 6.9-1.3-.1-2.6-.5-3.7-1.1v.1c0 4 2.8 7.4 6.6 8.1-.7.2-1.5.3-2.2.3-.5 0-1 0-1.5-.1 1 3.3 4 5.7 7.6 5.7-2.8 2.2-6.3 3.6-10.2 3.6-.6 0-1.3-.1-1.9-.1 3.6 2.3 7.9 3.7 12.5 3.7 15.1 0 23.3-12.6 23.3-23.6 0-.3 0-.7-.1-1 1.6-1.2 3-2.7 4.1-4.3-1.4.6-3 1.1-4.7 1.3 1.7-1 3-2.7 3.6-4.6" class="icon-style icon-twitter"  style="fill:#222222;fill-opacity:.8">
    </path></svg></a>
  </li>
  <li class="mr-1">
   <a href="mailto:?subject=Interesting%20News%20Story&amp;body=I%20thought%20you%20might%20find%20this%20interesting.%20<?php the_permalink(); ?>" class="inline-block" target="_blank" aria-label="Link to E mail">
      <svg xmlns="http://www.w3.org/2000/svg" width="36" height="27.6" viewbox="0 0 56 43">
        <title>email</title>
        <path d="M10.5 6.4C9.1 6.4 8 7.5 8 8.9v21.3c0 1.3 1.1 2.5 2.5 2.5h34.9c1.4 0 2.5-1.2 2.5-2.5V8.9c0-1.4-1.1-2.5-2.5-2.5H10.5zm2.1 2.5h30.7L27.9 22.3 12.6 8.9zm-2.1 1.4l16.6 14.6c.5.4 1.2.4 1.7 0l16.6-14.6v19.9H10.5V10.3z" class="icon-style icon-mail"  style="fill:#222222;fill-opacity:.8">
        </path></svg></a>
      </svg>
    </a>
  </li>
</ul>


<!--  Social Inline List -->
  <ul class="list-inline">
    <li class="mr-1">
      <a href="<?php echo get_option( 'unamunofacebook' ); ?>" target="_blank" class="inline-block" aria-label="Link to Facebook">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="23.6" viewbox="0 0 53 49">
      <title>Facebook</title><path d="M47.5 43c0 1.2-.9 2.1-2.1 2.1h-10V30h5.1l.8-5.9h-5.9v-3.7c0-1.7.5-2.9 3-2.9h3.1v-5.3c-.6 0-2.4-.2-4.6-.2-4.5 0-7.5 2.7-7.5 7.8v4.3h-5.1V30h5.1v15.1H10.7c-1.2 0-2.2-.9-2.2-2.1V8.3c0-1.2 1-2.2 2.2-2.2h34.7c1.2 0 2.1 1 2.1 2.2V43" class="icon-style icon-fb" style="fill:#222222;fill-opacity:.8">
      </path></svg></a>
    </li>
    <li class="mr-1">
      <a href="<?php echo get_option( 'unamunotwitter' ); ?>" target="_blank" class="inline-block" aria-label="Link to Twitter">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="22.2" viewbox="0 0 53 49">
      <title>Twitter</title>
      <path d="M45 6.9c-1.6 1-3.3 1.6-5.2 2-1.5-1.6-3.6-2.6-5.9-2.6-4.5 0-8.2 3.7-8.2 8.3 0 .6.1 1.3.2 1.9-6.8-.4-12.8-3.7-16.8-8.7C8.4 9 8 10.5 8 12c0 2.8 1.4 5.4 3.6 6.9-1.3-.1-2.6-.5-3.7-1.1v.1c0 4 2.8 7.4 6.6 8.1-.7.2-1.5.3-2.2.3-.5 0-1 0-1.5-.1 1 3.3 4 5.7 7.6 5.7-2.8 2.2-6.3 3.6-10.2 3.6-.6 0-1.3-.1-1.9-.1 3.6 2.3 7.9 3.7 12.5 3.7 15.1 0 23.3-12.6 23.3-23.6 0-.3 0-.7-.1-1 1.6-1.2 3-2.7 4.1-4.3-1.4.6-3 1.1-4.7 1.3 1.7-1 3-2.7 3.6-4.6" class="icon-style icon-twitter"  style="fill:#222222;fill-opacity:.8">
      </path></svg></a>
    </li>
    <li class="mr-1">
     <a href="mailto:?subject=Interesting%20News%20Story&amp;body=I%20thought%20you%20might%20find%20this%20interesting.%20<?php the_permalink(); ?>" class="inline-block" target="_blank" aria-label="Link to E mail">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="18.4" viewbox="0 0 56 43">
          <title>email</title>
          <path d="M10.5 6.4C9.1 6.4 8 7.5 8 8.9v21.3c0 1.3 1.1 2.5 2.5 2.5h34.9c1.4 0 2.5-1.2 2.5-2.5V8.9c0-1.4-1.1-2.5-2.5-2.5H10.5zm2.1 2.5h30.7L27.9 22.3 12.6 8.9zm-2.1 1.4l16.6 14.6c.5.4 1.2.4 1.7 0l16.6-14.6v19.9H10.5V10.3z" class="icon-style icon-mail"  style="fill:#222222;fill-opacity:.8">
        </path></svg></a></li>
  </ul>

<!--   Custom Logo Wordpress  -->


<amp-img src="<?php $custom_logo_id = get_theme_mod( 'custom_logo' );
$image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
echo $image[0]; ?>" width="190" height="80" alt="brand logo"></amp-img>


<p>social 1</p>


<!--  email
      24 : 18.4
      36 : 27.6
-->

<!--  Twitter
      24 : 22.2
      36 : 33.3
-->

<!--  Facebook
      24 : 23.6
      36 : 35.4
-->


<!--  Social Inline List Large -->
<ul class="list-inline">
  <li class="mr-1">
    <a href="<?php echo get_option( 'unamunofacebook' ); ?>" target="_blank" class="inline-block" aria-label="Link to Facebook">
    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="35.4" viewbox="0 0 53 49">
    <title>Facebook</title><path d="M47.5 43c0 1.2-.9 2.1-2.1 2.1h-10V30h5.1l.8-5.9h-5.9v-3.7c0-1.7.5-2.9 3-2.9h3.1v-5.3c-.6 0-2.4-.2-4.6-.2-4.5 0-7.5 2.7-7.5 7.8v4.3h-5.1V30h5.1v15.1H10.7c-1.2 0-2.2-.9-2.2-2.1V8.3c0-1.2 1-2.2 2.2-2.2h34.7c1.2 0 2.1 1 2.1 2.2V43" class="icon-style icon-fb" style="fill:#222222;fill-opacity:.8">
    </path></svg></a>
  </li>
  <li class="mr-1">
    <a href="<?php echo get_option( 'unamunotwitter' ); ?>" target="_blank" class="inline-block" aria-label="Link to Twitter">
    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="33.3" viewbox="0 0 53 49">
    <title>Twitter</title>
    <path d="M45 6.9c-1.6 1-3.3 1.6-5.2 2-1.5-1.6-3.6-2.6-5.9-2.6-4.5 0-8.2 3.7-8.2 8.3 0 .6.1 1.3.2 1.9-6.8-.4-12.8-3.7-16.8-8.7C8.4 9 8 10.5 8 12c0 2.8 1.4 5.4 3.6 6.9-1.3-.1-2.6-.5-3.7-1.1v.1c0 4 2.8 7.4 6.6 8.1-.7.2-1.5.3-2.2.3-.5 0-1 0-1.5-.1 1 3.3 4 5.7 7.6 5.7-2.8 2.2-6.3 3.6-10.2 3.6-.6 0-1.3-.1-1.9-.1 3.6 2.3 7.9 3.7 12.5 3.7 15.1 0 23.3-12.6 23.3-23.6 0-.3 0-.7-.1-1 1.6-1.2 3-2.7 4.1-4.3-1.4.6-3 1.1-4.7 1.3 1.7-1 3-2.7 3.6-4.6" class="icon-style icon-twitter"  style="fill:#222222;fill-opacity:.8">
    </path></svg></a>
  </li>
  <li class="mr-1">
   <a href="mailto:?subject=Interesting%20News%20Story&amp;body=I%20thought%20you%20might%20find%20this%20interesting.%20<?php the_permalink(); ?>" class="inline-block" target="_blank" aria-label="Link to E mail">
      <svg xmlns="http://www.w3.org/2000/svg" width="36" height="27.6" viewbox="0 0 56 43">
        <title>email</title>
        <path d="M10.5 6.4C9.1 6.4 8 7.5 8 8.9v21.3c0 1.3 1.1 2.5 2.5 2.5h34.9c1.4 0 2.5-1.2 2.5-2.5V8.9c0-1.4-1.1-2.5-2.5-2.5H10.5zm2.1 2.5h30.7L27.9 22.3 12.6 8.9zm-2.1 1.4l16.6 14.6c.5.4 1.2.4 1.7 0l16.6-14.6v19.9H10.5V10.3z" class="icon-style icon-mail"  style="fill:#222222;fill-opacity:.8">
        </path></svg></a>
      </svg>
    </a>
  </li>
</ul>



<!--   Custom Logo Wordpress  -->


<amp-img src="<?php $custom_logo_id = get_theme_mod( 'custom_logo' );
$image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
echo $image[0]; ?>" width="190" height="80" alt="brand logo"></amp-img>
