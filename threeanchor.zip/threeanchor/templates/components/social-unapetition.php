<?php
/*
 * The template for displaying FB and Twitter petition header links
 *
 *
 * Classes: .icon-social .mail .fb .twitter
 */
?>
<a rel="nofollow" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/icon-facebook-petition.svg" width="32" height="32" title="Facebook Share" alt="Facebook icon"></amp-img></a>
<a rel="nofollow" href="https://www.twitter.com/sharer.php?u=<?php the_permalink(); ?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/icon-twitter-petition.svg" width="32" height="32" title="Twitter Share" alt="Twitter icon"></amp-img></a>
