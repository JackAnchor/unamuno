<?php
/*
* Template for displaying ALL subpages, includes query
*/
?>

<?php

$args = array(
  'post_type'      => 'page',
  'posts_per_page' => -1,
  'post_parent'    => $post->ID,
  'order'          => 'ASC',
  'orderby'        => 'menu_order'
);


$parent = new WP_Query( $args );

if ( $parent->have_posts() ) : ?>

<!-- Nested inline cards  -->
<div id="parent-<?php the_ID(); ?>" class="parent-page pt-1 pb-3">
  <div class="clearfix">
    <div class="md-col-10 lg-col-8 mx-auto">
      <h5 class="mx-1 mb-0">Related Page Test</h5>

      <?php
      // Start the loop
      while ( $parent->have_posts() ) : $parent->the_post(); ?>

      <div class="clearfix card-inline">   <!-- nested row/card start -->
        <div class="sm-col md-col-5 lg-col-4">
          <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><amp-img src="<?php the_post_thumbnail_url(); ?>" height="314" width="600" layout="responsive"></amp-img></a>
        </div>
        <div class="sm-col md-col-7 lg-col-8 px-1 pb-2">
          <div class="card-body">
            <h4 class="index-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
          <?php the_excerpt(); ?>
          </div>  <!-- body end -->
        </div> <!-- col end -->
      </div>  <!-- nested row/card end -->


    <?php endwhile; ?>

  </div>  <!-- parent col end -->
 </div> <!-- parent clearfix row end -->
</div>   <!-- parent div end -->


<?php endif; wp_reset_postdata(); ?>
