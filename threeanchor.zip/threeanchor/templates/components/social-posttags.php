<?php
/**
 * The template for displaying social share links and posttags in article footer
 *
 *
*/
?>
  <div class="posttags">
    <div class="social">
      <h5 class="label">Share</h5>
      <a rel="nofollow" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><?php get_template_part( 'img/svg/facebook'); ?></a>
      <a rel="nofollow" href="https://twitter.com/intent/tweet?url=<?php the_permalink(); ?>"><?php get_template_part( 'img/svg/twitter'); ?></a>
      <a href="mailto:?subject=Political%20Update/Alert&amp;body=I%20thought%20you%20might%20find%20this%20interesting.%20<?php the_permalink(); ?>"><?php get_template_part( 'img/svg/mail'); ?></a> </div>
      <div class="tags"><?php the_tags( '<h5 class="label">Tagged </h5>', ' ', '' ); ?></div>
  </div>  <!-- .posttags -->
