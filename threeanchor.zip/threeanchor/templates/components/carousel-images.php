<?php
/**
 * Carousel Images
 *
 */
?>


   <div class="lightbox-box">
     <div class="caro-wrap">

     <amp-carousel width="520" height="400" controls loop layout="responsive" type="slides">


<!-- 1  -->
    <div class="slide">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/ballot-blowout-resized.png" width="2700" height="1725" layout="responsive" alt="2016 election spending liberal organizations versus social conservative organizations"></amp-img>
      <div class="slide-caption">Liberal vs. Conservative Spending Infographic
     </div>
    </div>




     <!-- 2  -->
     <div class="slide">
       <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/elect-educate-resized.png" width="2700" height="1725" layout="responsive" alt="2016 election spending breakdown conservative spending breakdown"></amp-img>
       <div class="slide-caption">
         Conservative Political Spending Infographic
      </div>
    </div>




         </amp-carousel>
       </div>
     </div>  <!-- .box -->
