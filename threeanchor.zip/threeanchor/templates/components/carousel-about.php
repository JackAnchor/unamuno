<?php
/**
 * Carousel About Page
 *
 */
?>

<div class="clearfix">
  <div class="md-col-9 lg-col-9 mx-auto pb-2">
    <div class="carousel-box">
   <amp-carousel width="420" height="302" controls loop layout="responsive" type="slides">

   <!-- 1  -->
   <div class="slide">
     <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/bio/boozman-firearms.jpg" width="1200" height="700" layout="responsive" alt="Senator John Boozman and Jack Sisson firearms photo"></amp-img>
     <div class="slide-caption">
       Senator John Boozman (R-Ark.) offers firearms advice
     </div>
   </div>

   <!-- 2  -->
   <div class="slide">
     <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/bio/pai-selfie.jpg" width="1200" height="700" layout="responsive" alt="Selfie with FCC Chairman and former Senate coworker Ajit Pai"></amp-img>
     <div class="slide-caption">
       FCC Chairman and former Senate coworker Ajit Pai
     </div>
   </div>

   <!-- 3  -->
   <div class="slide">
     <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/bio/amp-conference.jpg" width="1200" height="700" layout="responsive" alt="AMP conference photo, lanyard and presenter"></amp-img>
     <div class="slide-caption">
       California AMP Conference with Google engineering staff
     </div>
   </div>

   <!-- 4  -->
   <div class="slide">
     <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/bio/hill-team.jpg" width="1200" height="700" layout="responsive" alt="French Hill victory night staff photo"></amp-img>
     <div class="slide-caption">
       Election night with Congressman French Hill and family
     </div>
   </div>

     </amp-carousel>
   </div> <!--  .carousel-box -->
 </div>  <!-- .col -->
</div> <!-- .clearfix -->
