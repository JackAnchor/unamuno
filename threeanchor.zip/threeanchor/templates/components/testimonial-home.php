<?php
/*
*  Original Homepage Testimonial Content - Aug 15, 2019
*/
?>


.carousel1
.slide
.card-testimonials
.card-shadow-l
testi-img
.testi-title
.testi-position


.testi-img {
  border: solid 1px #c0c0c0;
  border-radius: 2px;
}

.testi-img {
  border: solid 1px #c0c0c0;
  border-radius: 2px;
}


  <!-- Testimonials
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <section class="bg-5 relative z4 mt-n10">  <!--  wrap  -->
    <div class="testimony">
      <div class="container">
        <div class="clearfix lg-pt-3">
          <div class="col-12 sm-col-8 md-col-8 lg-col-7 mx-auto px-1">
            <h6 class="tx-center tx-g6 pt-4">REPUTATION</h6>
            <h2 class="tx-g6 tx-center tx-h1 mb-2 subhead-c">Experience that generates <strong>results</strong></h2>
          </div>
        </div>   <!-- .row -->
        <div class="clearfix">
          <div class="col-11 sm-col-8 md-col-5 lg-col-6 mx-auto pl-1">
            <span class="left tx-g7 md-tx-center md-px-1 sm-px-1">Trusted by national political figures, non-profits, campaigns and advocacy groups to generate returns and deliver results.</span>
          </div>
        </div>   <!-- .row -->
      </div>

      <!-- Testimonials Body
      –––––––––––––––––––––––––––––––––––––––––––––––––– -->
      <div class="container lg-pt-2 pb-2">
        <div class="clearfix">
          <div class="sm-col-10 md-col-8 lg-col-7 mx-auto">
            <amp-carousel class="carousel1" layout="fixed-height" height="520" type="slides" controls loop autoplay delay="6000">
              <div class="slide">
                <div class="card-testimonials card-shadow-l">
                  <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/700/icon-quote-left-700.svg" width="28" height="28"  class="block mx-auto" alt="quote left icon"></amp-img>
                  <p class="pt-2 px-1">A slow website costs us search engine visibility, emails sign-ups and money. AMP was the best digital investment we’ve ever made.</p>
                  <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/700/icon-quote-right-700.svg" width="28" height="28"  class="block mx-auto" alt="quote right icon"></amp-img>
                  <div class="clearfix md-ml-3 lg-ml-4 pt-3 lg-pb-1"> <!-- media object -->
                    <div class="left pr-1">
                      <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/terry-schilling-headshot.jpg" width="74" height="74" sizes="(max-width: 500px) 17vw,(min-width: 550px) 95px,(min-width: 750px) 14vw, 110px" alt="terry schilling headshot" class="testi-img">
                      </amp-img>
                    </div>   <!-- .left object -->
                    <div>
                      <h3 class="testi-title">Terry Schilling</h3>
                      <h5 class="testi-position">Executive Director, APP</h5>
                    </div>
                  </div>  <!-- .media -->
                </div>  <!-- .card  -->
              </div>  <!-- .slide 1 -->
              <div class="slide">
                <div class="card-testimonials card-shadow-l">
                  <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/700/icon-quote-left-700.svg" width="28" height="28"  class="block mx-auto" alt="quote left icon"></amp-img>
                  <p class="pt-2 px-1">I trusted Jack to manage my first congressional race. He knows how to use data and digital technology to deliver real results.</p>
                  <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/700/icon-quote-right-700.svg" width="28" height="28"  class="block mx-auto" alt="quote right icon"></amp-img>
                  <div class="clearfix md-ml-3 lg-ml-4 pt-3 lg-pb-1"> <!-- media object -->
                    <div class="left pr-1">
                      <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/french-hill-headshot.jpg" width="74" height="74" sizes="(max-width: 500px) 17vw,(min-width: 550px) 95px,(min-width: 750px) 14vw, 110px" alt="french hill headshot" class="testi-img">
                      </amp-img>
                    </div>   <!-- .left -->
                    <div>
                      <h3 class="testi-title">French Hill</h3>
                      <h5 class="testi-position">Congressman</h5>
                    </div>
                  </div>  <!-- .media -->
                </div>  <!-- .card -->
              </div>  <!-- .slide 2 -->

              <div class="slide">
                <div class="card-testimonials card-shadow-l">
                  <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/700/icon-quote-left-700.svg" width="28" height="28"  class="block mx-auto" alt="quote left icon"></amp-img>
                  <p class="pt-2 px-1">Jack Sisson is incredibly smart, honest and hard-working. He truly knows what it takes to communicate in the 21st Century.</p>
                  <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons/700/icon-quote-right-700.svg" width="28" height="28"  class="block mx-auto" alt="quote right icon"></amp-img>
                  <div class="clearfix md-ml-3 lg-ml-4 pt-3 lg-pb-1">  <!-- media object -->
                    <div class="left pr-1">
                      <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/mike-huckabee-headshot.jpg" width="74" height="74" sizes="(max-width: 500px) 17vw,(min-width: 550px) 95px,(min-width: 750px) 14vw, 110px" alt="mike huckabee headshot" class="testi-img">
                      </amp-img>
                    </div>   <!-- .left object -->
                    <div>
                      <h3 class="testi-title">Mike Huckabee</h3>
                      <h5 class="testi-position">Governor</h5>
                    </div>
                  </div>  <!-- .media -->
                </div>  <!-- .card  -->
              </div>  <!-- .slide 3 -->
            </amp-carousel>
          </div>  <!-- .col  -->
        </div> <!-- .row -->
      </div> <!-- .container -->
    </div>
  </section>  <!-- .testimonials -->

  <section class="process">
    <div class="container">
      <div class="clearfix">
        <div class="sm-col sm-col-12 md-col-6 lg-col-6 px-1">
          <div class="card-index">
            <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/opengraph-default-image.png" alt="image description" width="600" height="314" layout="responsive"></amp-img>
            <div class="card-body">
              <a href="#"><h4>Card title</h4></a>
              <p> Prosciutto di Parma e parmigiano-reggiano.</p>
            </div>  <!-- .body -->
          </div>   <!--  .card -->
        </div>  <!-- .parent col  -->
      </div>  <!-- .parent col  -->
    </div>  <!-- .parent col  -->
  </section>
