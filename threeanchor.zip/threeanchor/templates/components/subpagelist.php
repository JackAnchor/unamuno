<?php
/*
* Template for displaying ALL subpages in list format
*/
?>

<?php

$args = array(
  'post_type'      => 'page',
  'posts_per_page' => -1,
  'post_parent'    => $post->ID,
  'order'          => 'ASC',
  'orderby'        => 'menu_order'
);


$parent = new WP_Query( $args );

if ( $parent->have_posts() ) : ?>

<!-- Nested inline cards  -->
<div id="parent-<?php the_ID(); ?>" class="parent-page pt-1 pb-3">
  <div class="clearfix">
    <div class="md-col-10 lg-col-6 mx-auto">
      <h5 class="mb-0">Related Pages</h5>

      <?php
      // Start the loop
      while ( $parent->have_posts() ) : $parent->the_post(); ?>

      <div class="clearfix">   <!-- nested row/card start -->
        <h4 class="index-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
      </div>  <!-- clearfix end -->
    <?php endwhile; ?>

  </div>  <!-- parent col end -->
 </div> <!-- parent clearfix row end -->
</div>   <!-- parent div end -->
<?php endif; wp_reset_postdata(); ?>
