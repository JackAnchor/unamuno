<?php
/**
 * Lightbox Work
 *
 */
?>


<section id="lightbox-work"> <!-- lightbox-work -->
  <div class="container pt-4">
    <div class="md-flex justify-around content-center">
     <div class="sm-col-10 md-col-4 lg-col-4 mx-auto pt-1 px-1 mb-0">
      <h6 class="">WEBSITE DEVELOPMENT</h6>
      <h4 class="mt-1">American Principles Project</h4>
        <div class="xs-hide sm-hide">
        <hr>
        </div>
     </div>   <!-- col 1  -->

     <div class="sm-col-10 md-col-8 lg-col-7 sm-px-1 mx-auto">
      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/11/app-hero-home-lg.png" width="2400" height="1256" layout="responsive" alt="app homepage hero"></amp-img>
      <button class="btn-open" on="tap:lightbox5" role="button" tabindex="0"><i class="material-icons md-18 pt-05">open_in_new</i></button>

      <amp-lightbox id="lightbox5" class="lightbox-cover" animate-in="fade-in" layout="nodisplay">
        <div class="sm-col-12 md-col-9 lg-col-7 mx-auto pt-3">
          <button class="close" on="tap:lightbox5.close">✕</button>

          <section class="container">

                    <?php get_template_part( 'templates/components/carousel-app'); ?>

                </section> <!-- section wrap  -->




        </div>
      </amp-lightbox>
    </div>  <!-- col 2  -->
  </div>
  </div>   <!-- container wrap 4 -->

  <div class="container">
    <div class="md-flex justify-around content-center">
     <div class="sm-col-10 md-col-4 lg-col-4 mx-auto pt-1 px-1 mb-0">
     </div>   <!-- col 1  -->

     <div class="sm-col-10 md-col-8 lg-col-7 sm-px-1 mx-auto">

      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/11/app-legislation-lg.png" width="2400" height="1256" layout="responsive" alt="APP legislation page"></amp-img>
      <button class="btn-open" on="tap:lightbox6" role="button" tabindex="0"><i class="material-icons md-18 pt-05">open_in_new</i></button>
      <amp-lightbox id="lightbox6" class="lightbox-cover" animate-in="fade-in" layout="nodisplay">
        <div class="sm-col-12 md-col-9 lg-col-7 mx-auto pt-3">
          <button class="close" on="tap:lightbox6.close">✕</button>
          <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/11/app-legislation-lg.png" width="2400" height="1256" layout="responsive" class="lightbox-shadow" alt="APP research page"></amp-img>
        </div>
      </amp-lightbox>  <!-- img end -->


      <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/11/app-elections-lg.png" width="2400" height="1256" layout="responsive" alt="APP elections page"></amp-img>
      <button class="btn-open" on="tap:lightbox9" role="button" tabindex="0"><i class="material-icons md-18 pt-05">open_in_new</i></button>

      <amp-lightbox id="lightbox9" class="lightbox-cover" animate-in="fade-in" layout="nodisplay">
        <div class="sm-col-12 md-col-9 lg-col-7 mx-auto pt-3">
          <button class="close" on="tap:lightbox9.close">✕</button>
          <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/11/app-elections-lg.png" width="2400" height="1256" layout="responsive" class="lightbox-shadow" alt="APP research page"></amp-img>
        </div>
      </amp-lightbox>  <!-- img end -->





    </div>  <!-- col 2  -->
  </div>
  </div>   <!-- container wrap 5/6 -->



  <div class="container pt-4 pb-4">
    <div class="md-flex justify-around content-center">
     <div class="sm-col-10 md-col-4 lg-col-4 mx-auto pt-1 px-1 mb-0">
      <h6 class="">INFOGRAPHIC</h6>
      <h4 class="mt-1">The Case for Politics</h4>

        <div class="xs-hide sm-hide">
        <hr>
        </div>
     </div>   <!-- col 1  -->

     <div class="sm-col-10 md-col-8 lg-col-7 sm-px-1 mx-auto">
      <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/work/ballot-blowout-recolor.png" alt="2016 election spending liberal organizations versus social conservative organizations" title="2016 election spending liberal organizations versus social conservative organizations" layout="responsive" width="810" height="585"></amp-img>
      <button class="btn-open" on="tap:lightbox1" role="button" tabindex="0"><i class="material-icons md-18 pt-05">open_in_new</i></button>

      <amp-lightbox id="lightbox1" class="lightbox-cover" animate-in="fade-in" layout="nodisplay">
        <div class="sm-col-12 md-col-9 lg-col-6 mx-auto pt-3">
          <button class="close" on="tap:lightbox1.close">✕</button>
          <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/work/ballot-blowout-recolor.png" alt="2016 election spending liberal organizations versus social conservative organizations" title="2016 election spending liberal organizations versus social conservative organizations" layout="responsive" width="810" height="585"></amp-img>
        </div>
      </amp-lightbox>
    </div>  <!-- col 2  -->
  </div>
</div>  </div>   <!-- container wrap 1 -->


  <div class="container pt-1 pb-4">
    <div class="md-flex justify-around content-center">
     <div class="sm-col-10 md-col-4 lg-col-4 mx-auto pt-1 px-1 mb-0">
     </div>   <!-- col 1  -->

     <div class="sm-col-10 md-col-8 lg-col-7 sm-px-1 mx-auto">
      <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/work/elect-educate-recolor.png" alt="social conservative organizations political spending priorities" title="social conservative organizations political spending prioritie" layout="responsive" width="810" height="585"></amp-img>
      <button class="btn-open" on="tap:lightbox2" role="button" tabindex="0"><i class="material-icons md-18 pt-05">open_in_new</i></button>

      <amp-lightbox id="lightbox2" class="lightbox-cover" animate-in="fade-in" layout="nodisplay">
        <div class="sm-col-12 md-col-9 lg-col-7 mx-auto pt-3">
          <button class="close" on="tap:lightbox2.close">✕</button>
          <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/work/elect-educate-recolor.png" alt="social conservative organizations political spending priorities" title="2016 election spending liberal organizations versus social conservative organizations" layout="responsive" width="810" height="585"></amp-img>
        </div>
      </amp-lightbox>
    </div>  <!-- col 2  -->
  </div>
</div>   <!-- container wrap 2 -->



<div class="container pt-4 pb-4">
  <div class="md-flex justify-around content-center">
   <div class="sm-col-10 md-col-4 lg-col-4 mx-auto pt-1 px-1 mb-0">
    <h6 class="">WEB APP DEVELOPMENT</h6>
    <h4 class="mt-1">Candidate Comparison Scorecards</h4>
      <div class="xs-hide sm-hide">
      <hr>
      </div>
   </div>   <!-- col 1  -->

   <div class="sm-col-10 md-col-8 lg-col-7 sm-px-1 mx-auto">
    <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/work/candidate-comparison-lg-o.png" width="2150" height="1225" layout="responsive" alt="Candidate comparison cards desktop"></amp-img>
    <button class="btn-open" on="tap:lightbox3" role="button" tabindex="0"><i class="material-icons md-18 pt-05">open_in_new</i></button>


    <amp-lightbox id="lightbox3" class="lightbox-cover" animate-in="fade-in" layout="nodisplay">
      <div class="sm-col-12 md-col-9 lg-col-7 mx-auto pt-3">
        <button class="close" on="tap:lightbox3.close">✕</button>
      <amp-img src="<?php echo get_stylesheet_directory_uri(); ?>/img/media/work/candidate-comparison-lg-o.png" width="2150" height="1225" layout="responsive" alt="Candidate comparison cards desktop" class="lightbox-shadow"></amp-img>
      </div>
    </amp-lightbox>



<hr>
     <amp-img src="http://threeanchorgroup.com/wp-content/uploads/2018/12/comparison-cards-lg-4-o.png" width="1525" height="1175" layout="responsive" alt="Candidate comparison cards desktop"></amp-img>


     <button class="btn-open" on="tap:lightbox4" role="button" tabindex="0"><i class="material-icons md-18 pt-05">open_in_new</i></button>

     <amp-lightbox id="lightbox4" class="lightbox-cover" animate-in="fade-in" layout="nodisplay">
         <div class="sm-col-12 md-col-9 lg-col-7 mx-auto pt-3">

         <button class="close" on="tap:lightbox4.close">✕</button>
       <amp-img src="http://threeanchorgroup.com/wp-content/uploads/2018/12/comparison-cards-lg-4-o.png" width="1525" height="1175" layout="responsive" alt="Candidate comparison cards desktop" class="lightbox-shadow"></amp-img>
     </div>

   </amp-lightbox>
   </div>  <!-- col 2  -->
   </div>
   </div>   <!-- container wrap 2 -->
