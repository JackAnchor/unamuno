<?php
/**
 * Primary Portfolio
 *
 */
?>

<div id="portfolio-wrap"> <!-- lightbox wrap  -->
<div class="portfolio-full-gal"> <!-- lightbox wrap
  <div class="clearfix">
   <div class="col col-6 sm-col-6 md-col-4 lg-col-3">
    <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/app-hero-home-o.jpg" width="2400" height="1400" layout="responsive" alt="app homepage hero" class=""></amp-img>
  </div>
<div class="col col-6 sm-col-6 md-col-4 lg-col-3">
    <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/homehero-siblingsjpg.jpg" width="2400" height="1400" layout="responsive" alt="Public Policy Homepage"></amp-img>
  </div>
  <div class="col col-6 sm-col-6 md-col-4 lg-col-3">
    <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/legislation-servicepg.png" width="2400" height="1400" layout="responsive" alt="Legislation Services Page"></amp-img>
  </div>
  <div class="col col-6 sm-col-6 md-col-4 lg-col-3">

    <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2019/01/staff-team1.jpg" width="2400" height="1400" layout="responsive" alt="staff photo collage"></amp-img>
  </div>
  <div class="col col-6 sm-col-6 md-col-4 lg-col-3">
    <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/ballot-cards-d3.png" width="2400" height="1400" layout="responsive" alt="Ballot/Candidate Information Cards"></amp-img>
  </div>
  <div class="col col-6 sm-col-6 md-col-4 lg-col-3">
    <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2019/01/klf-case-study12.png" width="2400" height="1400" layout="responsive" alt="Political fundraising website home hero" class=""></amp-img>
  </div>
  <div class="col col-6 sm-col-6 md-col-4 lg-col-3">
    <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2019/01/appf-case-study18.png" width="2400" height="1400" layout="responsive" alt="APPF vision and values" class=""></amp-img>
  </div>
  <div class="col col-6 sm-col-6 md-col-4 lg-col-3">
  <amp-img src="https://threeanchorgroup.com/wp-content/uploads/2018/12/service-icon-h.png" width="2400" height="1400" layout="responsive" alt="Political brand service icons"></amp-img>
  </div>
</div>  .row  -->
</div>  <!-- .gallery   -->

   <?php
   /**
    * Lightbox modal -->
    *
    */
   ?>

 <amp-lightbox id="lightbox1" class="lightbox-cover" animate-in="fade-in" layout="nodisplay">
   <div class="container">
   <div class="sm-col-12 md-col-9 lg-col-9 mx-auto pt-2">
     <div class="caro-wrap pt-1">
     <div class="clearfix">
     <button class="close pr-1" on="tap:lightbox1.close">✕</button>
      </div>  <!-- . caro-wrap -->
     <?php get_template_part( 'templates/components/carousel-web'); ?>
    </div>
   </div>
 </div>
 </amp-lightbox>
</div> <!-- lightbox wrap   -->
