<?php
/**
 * Template for displaying two recent news stories (includes query)
 *
 */
?>

<?php

  $postid = get_the_ID();

  // The Arguments
    $args = array(
      'post__not_in'=> array($postid),
    	'post_type' => array( 'post' ),
      'posts_per_page' => 2,
    );

    $title = get_the_title();
    // The Query
    $parent = new WP_Query( $args ); ?>

    <?php
    // Test
    if ( $parent->have_posts() ) : ?>


    <div class="container clearfix px-w"> <!-- flex container -->
      <div class="flex flex-wrap justify-center md-justify-between card-shadow"> <!-- flex row -->

      <?php
      // Start the loop
      while ( $parent->have_posts() ) : $parent->the_post(); ?>

  <article class="col-12 sm-col-11 md-col-6 lg-col-6 card-index clearfix pb-4">
      <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><amp-img src="<?php the_post_thumbnail_url(); ?>" height="628" width="1200" layout="responsive"></amp-img></a>

      <div class="body">
        <h5 class="cat"><?php the_category(' | ') ?></h5>
        <div class="date"><?php the_date(); ?></div>
        <h3 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <?php the_excerpt(); ?>
      </div>  <!-- body end -->
        <footer>
          <div class="footer-d">
          <a class="btn-p7 btn-md" role="button" href="<?php the_permalink(); ?>">READ MORE &raquo;</a>
         </div>
       </footer> <!-- footer end -->
    </article>   <!--  card end -->

  <?php endwhile; ?>

</div>  <!-- flex row end -->
</div> <!--  flex container end-->

  <?php endif; wp_reset_postdata(); ?>
