<?php
  /*
  * Responsive Toolbar navigation
  *
  * May 14
  *
  * VALIDATION DETAILS:
  * ---------------------------------------
  * - Include amp-sidebar script in head
  * - Default style menu-primary or nav-menu
  *
  * - Wrapper required for mobile/tablet background color (validation error)
  * - Clearfix class enabled to prevent button overflow/clear float
  * - Logo & icon filepath /img/logos/amp-logo.svg
  * - Desktop navbar background style: .amp-sidebar-toolbar-target-hidden
  * - Dark background link: #d6d6d6
  * - Dark background hover: #f8f8f8
  *
  *
  */
  ?>
  <header id="navbar" class="navbar navbar-primary">


  <?php if ( is_singular( 'unafactsheet' ) ) : ?>

    <div class="navbar-w flex items-center justify-between overflow-hidden">
      <a class="nav-logo flex-item inline-block" href="<?php echo get_home_url(); ?>"><?php get_template_part( 'img/logos/logo-navbar'); ?></a>

    <?php elseif ( is_singular( 'unapetition' ) ) : ?>

  <div class="navbar-w flex items-center justify-between overflow-hidden">
    <a class="nav-logo flex-item inline-block" href="<?php echo get_home_url(); ?>"><?php get_template_part( 'img/logos/logo-navbar'); ?></a>

  <?php else : ?>

        <div class="navbar-w flex items-center justify-between overflow-hidden">
          <a class="nav-logo flex-item inline-block" href="<?php echo get_home_url(); ?>"><?php get_template_part( 'img/logos/logo-navbar'); ?></a>

  <?php endif; ?>

  <button aria-label="open sidebar" on="tap:navbar-sidebar.toggle" tabindex="0" class="navbar-btn navbar-btn-fill md-hide lg-hide flex-item">☰
    </button> <!-- .button -->

    <div id="target-element-right" class="toolbar-target-shown">
    </div> <!-- .lg menu-primary -->

  </div> <!-- .fx-wrap -->
</header>

    <!-- Responsive sidebar menu  -->
    <amp-sidebar id="navbar-sidebar" layout="nodisplay" class="md-hide lg-hide" side="left">
      <div class="">    <!-- menu content -->
        <div role="button" aria-label="close sidebar" on="tap:navbar-sidebar.toggle" tabindex="0" class="navbar-x">✕</div>
      </div>

      <nav toolbar="(min-width:52em)" toolbar-target="target-element-right">
         <?php wp_nav_menu( array(
         'menu_class' => 'menu-p',
         'theme_location' => 'header-menu',
         'container' => '',
         'menu_id' => ''
       ) ); ?>
       </nav>
   </amp-sidebar> <!-- .sidebar -->
