<?php
/**
 * Template for displaying posts
 *
 * (Not currently used)
 */
?>
  <div class="sm-col md-col-6 lg-col-6 card-flex clearfix">
    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><amp-img src="<?php the_post_thumbnail_url(); ?>" height="628" width="1200" layout="responsive"></amp-img></a>
    <div class="card-body">
      <p class="index-cat"><?php the_category(' | ') ?> </p><p class="index-date"><?php the_date(); ?></p>
      <h4 class="index-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
      <?php the_excerpt(); ?>
    </div>  <!-- .body -->
    <div class="card-footer">
      <a href="<?php the_permalink(); ?>">MORE &raquo;</a>
    </div> <!-- .footer -->

  </div> <!-- .card -->
