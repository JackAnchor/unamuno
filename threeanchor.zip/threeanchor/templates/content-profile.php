<section class="post-w profile-w">
  <div class="container">
    <div class="clearfix">
       <div class="col-11 sm-col-11 md-col-8 lg-col-7 mx-auto post-c content profile-c">
         <?php the_content(); ?>
      </div>  <!-- .col -->
    </div> <!-- .clearfix -->
      <?php get_template_part( 'templates/components/carousel-about'); ?>
   </div> <!-- .container -->
</section>
