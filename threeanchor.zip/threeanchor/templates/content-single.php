<?php
/**
 * The template for displaying all single posts and attachments
 *
 *  social-header
 *  author-byline
 *
* AMP VALIDATION DETAILS:
* ---------------------------------------
* Action Items:
* - Modify schema and link="rel" in document <head>
* - Double check FB, Twitter and Email Functionality
*
* Commment Form:
* - Remove custom style "display:none" from 'cancel comment reply'
* - Address 'action' Link appearance is href="title-post-url-here/#respond"
* - Modify <form> to <amp-form> to amp form.
* - Include the <amp-form> script in document <head>
* - byline-img (via functions)
* - byline-author (text)
* <div class="author-flex-tx">
* <h5><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php the_author(); ?></a></h5>
* <h6 class="mt-1"><?php echo get_the_author_meta( 'twitter_profile' ); ?><h6>
* </div>  <!--  flex text end -->
* </div>   <!--  author flex end -->
* </div>   <!-- col end  -->
* </section>   <!-- author clearfix end  -->
*
* Left alignment text is preferable for mobile. Avoid jerkey back and forth.
* Image breaks the flow of the text content.
*
*/
?>

 <main id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  <div class="container"> <!-- page wrap  -->
    <header class="clearfix post-h">
      <div class="sm-col-12 md-col-12 lg-col-12">
         <?php the_title( '<h1 class="title">', '</h1>' ); ?>
        <?php if (has_post_thumbnail( $post->ID ) ): ?>
          <amp-img src="<?php the_post_thumbnail_url(); ?>" title="<?php the_title_attribute(); ?>" height="942" width="1800" class="h-img" layout="responsive"></amp-img>
          <div class="caption md-tx-r"><?php the_post_thumbnail_caption(); ?></div>
        <?php endif; ?>
       </div>
    </header>


    <div class="unapost-layout container">
      <div class="unapost-wrap">
        <div class="sm-col-10 xs-mx-auto sm-mx-auto md-col md-col-3 lg-col-25 unapost-side">
          <div class="dateline-t xs-tx-c sm-tx-c">
            <h5 class="cat"><?php $category = get_the_category(); echo $category[0]->cat_name; ?></h5>
            <h6 class="date mb-0"><?php the_date(); ?></h6>
          </div>
          <div class="unapost-stick">
            <div class="xs-tx-c sm-tx-c dateline-s lg-pt-1">
              <div class="social">
              <?php get_template_part( 'templates/components/social-unapost' ); ?>
            </div>
            </div>  <!-- .dateline -->
          </div>
        </div> <!-- .col1 -->

        <div class="sm-col-10 xs-mx-auto sm-mx-auto md-mx-auto md-col-8 lg-col-7 pb-4 post-c unapost-c content">
          <?php the_content(); ?>
          <?php if ( ! is_singular( 'attachment' ) ) : ?>
          <?php get_template_part( 'templates/components/byline' ); ?>
        	<?php endif; ?>
        </div> <!-- .col2 -->
      </div>
    </div>
  </div>


    <!-- News Start
    –––––––––––––––––––––––––––––––––––––––––––––––––– -->
    <section class="bg-w2 pt-4 pb-2">
         <div class="container">
           <div class="clearfix lg-pt-2 px-w">
            <div class="col-12 sm-col-10 md-col-12 lg-col-12 mx-auto">
            <h3 class="tx-g8">Related news</h3>
            <hr>
          </div>
        </div>
      <?php get_template_part( 'templates/content', 'homenews' ); ?>
       </div>
  </section>


</main>
