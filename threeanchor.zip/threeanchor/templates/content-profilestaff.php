<?php
/**
 * Aside template for displaying staff profiles (includes query)
 *
 *
 */
?>


<?php

  // The Arguments
  $args = array(
    'post_type'      => 'unaprofile',
    'tag' => 'staff',
    'posts_per_page' => 20,
    'orderby' => 'menu_order',
    'order' => 'ASC'
  );

  // The Query
  $parent = new WP_Query( $args ); ?>


<aside class="container clearfix"> <!-- container wrap -->
  <div class="col-12 sm-col-11 md-col-9 lg-col-7 mx-auto"> <!-- lg wrap/mx -->
   <div class="flex flex-wrap card-shadow"> <!-- fx-wrap-->

     <h4 class="px-1"> Our Team</h4>


<?php
// Start the loop
if ( $parent->have_posts() ) : while ( $parent->have_posts() ) : $parent->the_post();

   // Get staff template
   get_template_part( 'templates/content', 'newsprofile' ); ?>


<?php endwhile; endif; wp_reset_postdata(); ?>

  </div>  <!-- .row -->
</div> <!--  .fx-col -->
</aside>  <!-- .bg -->
