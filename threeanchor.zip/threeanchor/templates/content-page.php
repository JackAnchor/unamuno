<?php
/**
 * Template for displaying page content
 *
 * CSS REFERENCE: .content-page, .content
 * @since 1.5.4
 */
?>
<section class="page-w">
  <div class="container">
    <div class="clearfix">
       <div class="col-11 sm-col-10 md-col-8 lg-col-7 mx-auto page-c content">
         <?php the_content(); ?>
      </div>  <!-- column end -->
    </div> <!-- clearfix end -->
  </div>
</section>
