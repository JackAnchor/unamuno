<?php
/*
* Template for displaying recent factsheet posts, excluding current post (includes query)
*/
?>

<?php

  $postid = get_the_ID();

  // The Arguments
    $args = array(
      'post__not_in'=> array($postid),
    	'post_type' => array( 'unafactsheet' ),
      'posts_per_page' => 3,
    );
 $title = get_the_title();
    // The Query
    $factsheetlist = new WP_Query( $args ); ?>

    <?php
    // Test
    if ( $factsheetlist->have_posts() ) : ?>

    <!-- Loop content  -->

    <section class="related tx-a3">
     <div class="container pb-3">
      <div class="clearfix px-1">
        <div class="sm-col-9 md-col-8 lg-col-7 mx-auto">
          <h5 class="label">RELATED NEWS</h5>

          <?php
          // Start the loop
          while ( $factsheetlist->have_posts() ) : $factsheetlist->the_post(); ?>

          <article class="clearfix pb-04 related-ul">
            <a href="<?php the_permalink(); ?>"><div class="left pr-1">&raquo;</div>
            <div class="overflow-hidden"><h5><strong><?php the_title(); ?></strong></h5></div>
            </a>
          </article>

            <?php endwhile; ?>
            </div>  <!-- .col -->
          </div> <!-- .row -->
        </div>   <!-- .con -->
      </section> <!-- .wrap -->


  <?php endif; wp_reset_postdata(); ?>
