<?php
/**
* One button widget
*/
?>
<?php	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>
	<aside id="cta-1">
		<div class="container">
			<div class="col-12 sm-col-11 md-col-9 lg-col-7 mx-auto">
			 <div class="cta-h flex flex-wrap content-center px-w">
				 <?php dynamic_sidebar('sidebar-1'); ?>
				 <?php
				 	if ( is_page_template( 'page-faq.php' )) {?>
				 		<a class="btn-p5 btn-lg" href="<?php echo get_home_url(); ?>/about/contact">PROJECT ESTIMATE &raquo;</a>
				 	<?php }

		 	else {?>
				 		<a class="btn-p5 btn-lg mr-05" href="<?php echo get_home_url(); ?>/about/">OUR PROCESS &raquo;</a>
				 	<?php }
				 	?>
			</div>
			</div>
		</div>
	</aside>
