<svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 690 551" overflow="visible"><path fill="#aaaaaa60" d="M345.048 0l-.032.051-.033-.051L0 550.606h690.031z"></path></svg>
