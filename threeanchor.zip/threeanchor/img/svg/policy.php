<svg xmlns="http://www.w3.org/2000/svg" height="24" width="24"  viewBox="0 0 48 48">
<path d="m0 0h48v48h-48z" fill="none"/>
<path style="fill:;" class="icon-admin" d="m8 20v14h6v-14h-6zm12 0v14h6v-14h-6zm-16 24h38v-6h-38v6zm28-24v14h6v-14h-6zm-9-18l-19 10v4h38v-4l-19-10z"/>
</svg>
