<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><title>Red triangle down</title>
    <polygon fill="" points="0,0 100,0 50,100"/>
  </svg>
