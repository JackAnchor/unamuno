<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000" preserveAspectRatio="xMinYMid">
<polygon points="0,0 1000,0 1000,1000"/>
  </svg>
