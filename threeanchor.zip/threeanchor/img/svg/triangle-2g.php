<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000" preserveAspectRatio="none">
  <linearGradient id="grad2" x1="0%" y1="0%" x2="100%" y2="0%">
    <stop offset="15%" style="stop-color:#00286c;stop-opacity:1" />
    <stop offset="100%" style="stop-color:#1f58ab;stop-opacity:1" />
  </linearGradient>
</defs>
  <polygon fill="url(#grad2)" points="0,1000 1000,1000 0,0"/>
</svg>
