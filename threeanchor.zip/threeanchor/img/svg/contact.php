<svg xmlns="http://www.w3.org/2000/svg" height="26" width="26" version="1.1"  viewBox="0 0 24 24">
<g transform="matrix(.916667 0 0 .916667 -35.6666 -12)">
<path style="fill:;fill-opacity:.8" d="m2 3c-1.1 0-2 0.9-2 2v14c0 1.1 0.9 2 2 2h20c1.1 0 1.99023-0.9 1.99023-2l0.0098-14c0-1.1-0.9-2-2-2h-20zm6 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm6 0h8v6h-8v-6zm1 1v1l3 2 3-2v-1l-3 2-3-2zm-7 6.9004c2 0 6 1.0996 6 3.0996v1h-12v-1c0-2 4-3.09961 6-3.09961z" fill-rule="evenodd" transform="translate(39.9999 15)"/>
</g>
</svg>
