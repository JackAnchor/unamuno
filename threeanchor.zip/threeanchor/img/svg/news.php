<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" version="1.1" viewBox="0 0 18 18">
<path style="fill:;" d="m14 4v-2h-14v11c0 0.552 0.448 1 1 1h13.5c0.828 0 1.5-0.672 1.5-1.5v-8.5h-2zm-1 9h-12v-10h12v10zm-11-8h10v1h-10zm6 2h4v1h-4zm0 2h4v1h-4zm0 2h3v1h-3zm-6-4h5v5h-5z"/>
</svg>
