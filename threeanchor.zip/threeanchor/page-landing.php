<?php
/**
 * Template Name: Landing
 *
 */
?>

<?php get_header('amp'); ?>

  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

<main id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  <header class="about-h">
    <div class="hero-box">
      <div class="clearfix">
        <div class="sm-col-12 md-col-10 lg-col-7 mx-auto">
          <?php the_title( '<h1 class="title">', '</h1>' ); ?>
          </div>  <!-- col end -->
        </div>  <!-- row -->
    </div> <!-- hero box -->
  </header> <!-- background -->


      <?php get_template_part( 'templates/content', 'page' ); ?>


</main>     <!-- page end -->

   <?php endwhile; endif; ?>


   <?php get_sidebar( '1' ); ?>


<?php get_footer(); ?>
